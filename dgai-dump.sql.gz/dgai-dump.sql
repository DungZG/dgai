--
-- PostgreSQL database dump
--

\restrict paPbvHrd4s5uEPHeCHHhxhZ3AHmbwRbKQ0XT7dDRCabD56hJD9k2yDUSeJN7fk5

-- Dumped from database version 15.19
-- Dumped by pg_dump version 15.19

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX public.ux_user_provider;
DROP INDEX public.ux_provider_userid;
DROP INDEX public.uk_vendor_name_delete_at;
DROP INDEX public.uk_task_plugin_key_version;
DROP INDEX public.uk_prefill_name;
DROP INDEX public.uk_model_name_delete_at;
DROP INDEX public.index_username_model_name;
DROP INDEX public.idx_vendors_deleted_at;
DROP INDEX public.idx_users_we_chat_id;
DROP INDEX public.idx_users_username;
DROP INDEX public.idx_users_telegram_id;
DROP INDEX public.idx_users_stripe_customer;
DROP INDEX public.idx_users_oidc_id;
DROP INDEX public.idx_users_linux_do_id;
DROP INDEX public.idx_users_inviter_id;
DROP INDEX public.idx_users_git_hub_id;
DROP INDEX public.idx_users_email;
DROP INDEX public.idx_users_display_name;
DROP INDEX public.idx_users_discord_id;
DROP INDEX public.idx_users_deleted_at;
DROP INDEX public.idx_users_aff_code;
DROP INDEX public.idx_users_access_token;
DROP INDEX public.idx_user_subscriptions_user_id;
DROP INDEX public.idx_user_subscriptions_status;
DROP INDEX public.idx_user_subscriptions_plan_id;
DROP INDEX public.idx_user_subscriptions_next_reset_time;
DROP INDEX public.idx_user_subscriptions_end_time;
DROP INDEX public.idx_user_sub_active;
DROP INDEX public.idx_user_sessions_user_status_expiry;
DROP INDEX public.idx_user_sessions_user_created;
DROP INDEX public.idx_user_sessions_status_revoked;
DROP INDEX public.idx_user_sessions_expires_at;
DROP INDEX public.idx_user_id_id;
DROP INDEX public.idx_user_checkin_date;
DROP INDEX public.idx_user_access_tokens_user_id;
DROP INDEX public.idx_user_access_tokens_token_hash;
DROP INDEX public.idx_user_access_tokens_expires_at;
DROP INDEX public.idx_two_fas_user_id;
DROP INDEX public.idx_two_fas_deleted_at;
DROP INDEX public.idx_two_fa_backup_codes_user_id;
DROP INDEX public.idx_two_fa_backup_codes_deleted_at;
DROP INDEX public.idx_top_ups_user_id;
DROP INDEX public.idx_top_ups_trade_no;
DROP INDEX public.idx_tokens_user_id;
DROP INDEX public.idx_tokens_name;
DROP INDEX public.idx_tokens_key;
DROP INDEX public.idx_tokens_deleted_at;
DROP INDEX public.idx_tasks_user_id;
DROP INDEX public.idx_tasks_task_id;
DROP INDEX public.idx_tasks_submit_time;
DROP INDEX public.idx_tasks_status;
DROP INDEX public.idx_tasks_start_time;
DROP INDEX public.idx_tasks_progress;
DROP INDEX public.idx_tasks_platform;
DROP INDEX public.idx_tasks_finish_time;
DROP INDEX public.idx_tasks_created_at;
DROP INDEX public.idx_tasks_channel_id;
DROP INDEX public.idx_tasks_action;
DROP INDEX public.idx_task_plugins_active;
DROP INDEX public.idx_system_tasks_updated_at;
DROP INDEX public.idx_system_tasks_type;
DROP INDEX public.idx_system_tasks_task_id;
DROP INDEX public.idx_system_tasks_status;
DROP INDEX public.idx_system_tasks_locked_by;
DROP INDEX public.idx_system_tasks_created_at;
DROP INDEX public.idx_system_tasks_active_key;
DROP INDEX public.idx_system_task_locks_updated_at;
DROP INDEX public.idx_system_task_locks_task_id;
DROP INDEX public.idx_system_task_locks_locked_until;
DROP INDEX public.idx_system_task_locks_locked_by;
DROP INDEX public.idx_system_instances_updated_at;
DROP INDEX public.idx_system_instances_started_at;
DROP INDEX public.idx_system_instances_last_seen_at;
DROP INDEX public.idx_system_instances_created_at;
DROP INDEX public.idx_subscription_pre_consume_records_user_subscription_id;
DROP INDEX public.idx_subscription_pre_consume_records_user_id;
DROP INDEX public.idx_subscription_pre_consume_records_updated_at;
DROP INDEX public.idx_subscription_pre_consume_records_status;
DROP INDEX public.idx_subscription_pre_consume_records_request_id;
DROP INDEX public.idx_subscription_orders_user_id;
DROP INDEX public.idx_subscription_orders_trade_no;
DROP INDEX public.idx_subscription_orders_plan_id;
DROP INDEX public.idx_redemptions_name;
DROP INDEX public.idx_redemptions_key;
DROP INDEX public.idx_redemptions_deleted_at;
DROP INDEX public.idx_quota_data_user_id;
DROP INDEX public.idx_quota_data_use_group;
DROP INDEX public.idx_quota_data_token_id;
DROP INDEX public.idx_quota_data_node_name;
DROP INDEX public.idx_quota_data_channel_id;
DROP INDEX public.idx_qdt_model_user_name;
DROP INDEX public.idx_qdt_created_at;
DROP INDEX public.idx_prefill_groups_type;
DROP INDEX public.idx_prefill_groups_deleted_at;
DROP INDEX public.idx_perf_model_group_bucket;
DROP INDEX public.idx_perf_bucket_ts;
DROP INDEX public.idx_passkey_credentials_user_id;
DROP INDEX public.idx_passkey_credentials_deleted_at;
DROP INDEX public.idx_passkey_credentials_credential_id;
DROP INDEX public.idx_models_vendor_id;
DROP INDEX public.idx_models_deleted_at;
DROP INDEX public.idx_midjourneys_user_id;
DROP INDEX public.idx_midjourneys_submit_time;
DROP INDEX public.idx_midjourneys_status;
DROP INDEX public.idx_midjourneys_start_time;
DROP INDEX public.idx_midjourneys_progress;
DROP INDEX public.idx_midjourneys_mj_id;
DROP INDEX public.idx_midjourneys_finish_time;
DROP INDEX public.idx_midjourneys_action;
DROP INDEX public.idx_logs_username;
DROP INDEX public.idx_logs_user_id;
DROP INDEX public.idx_logs_upstream_request_id;
DROP INDEX public.idx_logs_token_name;
DROP INDEX public.idx_logs_token_id;
DROP INDEX public.idx_logs_request_id;
DROP INDEX public.idx_logs_model_name;
DROP INDEX public.idx_logs_ip;
DROP INDEX public.idx_logs_group;
DROP INDEX public.idx_logs_channel_id;
DROP INDEX public.idx_login_encryption_keys_slot;
DROP INDEX public.idx_external_identity_user;
DROP INDEX public.idx_external_identity_subject;
DROP INDEX public.idx_external_identity_claims_user_id;
DROP INDEX public.idx_custom_oauth_providers_slug;
DROP INDEX public.idx_created_at_type;
DROP INDEX public.idx_created_at_id;
DROP INDEX public.idx_channels_tag;
DROP INDEX public.idx_channels_name;
DROP INDEX public.idx_casbin_rule_unique;
DROP INDEX public.idx_casbin_rule;
DROP INDEX public.idx_authz_roles_key;
DROP INDEX public.idx_auth_flows_user_id;
DROP INDEX public.idx_auth_flows_token_hash;
DROP INDEX public.idx_auth_flows_session_id;
DROP INDEX public.idx_auth_flows_consumed_at;
DROP INDEX public.idx_auth_flow_purpose_expiry;
DROP INDEX public.idx_audit_user_time;
DROP INDEX public.idx_audit_token_time;
DROP INDEX public.idx_audit_time_event;
DROP INDEX public.idx_audit_logs_username;
DROP INDEX public.idx_audit_logs_request_id;
DROP INDEX public.idx_audit_logs_event_id;
DROP INDEX public.idx_audit_logs_created_at;
DROP INDEX public.idx_audit_logs_category;
DROP INDEX public.idx_abilities_weight;
DROP INDEX public.idx_abilities_tag;
DROP INDEX public.idx_abilities_priority;
DROP INDEX public.idx_abilities_channel_id;
ALTER TABLE ONLY public.vendors DROP CONSTRAINT vendors_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.user_subscriptions DROP CONSTRAINT user_subscriptions_pkey;
ALTER TABLE ONLY public.user_sessions DROP CONSTRAINT user_sessions_pkey;
ALTER TABLE ONLY public.user_oauth_bindings DROP CONSTRAINT user_oauth_bindings_pkey;
ALTER TABLE ONLY public.user_access_tokens DROP CONSTRAINT user_access_tokens_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT uni_users_username;
ALTER TABLE ONLY public.two_fas DROP CONSTRAINT uni_two_fas_user_id;
ALTER TABLE ONLY public.top_ups DROP CONSTRAINT uni_top_ups_trade_no;
ALTER TABLE ONLY public.subscription_orders DROP CONSTRAINT uni_subscription_orders_trade_no;
ALTER TABLE ONLY public.two_fas DROP CONSTRAINT two_fas_pkey;
ALTER TABLE ONLY public.two_fa_backup_codes DROP CONSTRAINT two_fa_backup_codes_pkey;
ALTER TABLE ONLY public.top_ups DROP CONSTRAINT top_ups_pkey;
ALTER TABLE ONLY public.tokens DROP CONSTRAINT tokens_pkey;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT tasks_pkey;
ALTER TABLE ONLY public.task_plugins DROP CONSTRAINT task_plugins_pkey;
ALTER TABLE ONLY public.system_tasks DROP CONSTRAINT system_tasks_pkey;
ALTER TABLE ONLY public.system_task_locks DROP CONSTRAINT system_task_locks_pkey;
ALTER TABLE ONLY public.system_instances DROP CONSTRAINT system_instances_pkey;
ALTER TABLE ONLY public.subscription_pre_consume_records DROP CONSTRAINT subscription_pre_consume_records_pkey;
ALTER TABLE ONLY public.subscription_plans DROP CONSTRAINT subscription_plans_pkey;
ALTER TABLE ONLY public.subscription_orders DROP CONSTRAINT subscription_orders_pkey;
ALTER TABLE ONLY public.setups DROP CONSTRAINT setups_pkey;
ALTER TABLE ONLY public.redemptions DROP CONSTRAINT redemptions_pkey;
ALTER TABLE ONLY public.quota_data DROP CONSTRAINT quota_data_pkey;
ALTER TABLE ONLY public.prefill_groups DROP CONSTRAINT prefill_groups_pkey;
ALTER TABLE ONLY public.perf_metrics DROP CONSTRAINT perf_metrics_pkey;
ALTER TABLE ONLY public.passkey_credentials DROP CONSTRAINT passkey_credentials_pkey;
ALTER TABLE ONLY public.options DROP CONSTRAINT options_pkey;
ALTER TABLE ONLY public.models DROP CONSTRAINT models_pkey;
ALTER TABLE ONLY public.midjourneys DROP CONSTRAINT midjourneys_pkey;
ALTER TABLE ONLY public.logs DROP CONSTRAINT logs_pkey;
ALTER TABLE ONLY public.login_encryption_keys DROP CONSTRAINT login_encryption_keys_pkey;
ALTER TABLE ONLY public.external_identity_claims DROP CONSTRAINT external_identity_claims_pkey;
ALTER TABLE ONLY public.custom_oauth_providers DROP CONSTRAINT custom_oauth_providers_pkey;
ALTER TABLE ONLY public.checkins DROP CONSTRAINT checkins_pkey;
ALTER TABLE ONLY public.channels DROP CONSTRAINT channels_pkey;
ALTER TABLE ONLY public.casbin_rule DROP CONSTRAINT casbin_rule_pkey;
ALTER TABLE ONLY public.authz_roles DROP CONSTRAINT authz_roles_pkey;
ALTER TABLE ONLY public.auth_flows DROP CONSTRAINT auth_flows_pkey;
ALTER TABLE ONLY public.audit_logs DROP CONSTRAINT audit_logs_pkey;
ALTER TABLE ONLY public.abilities DROP CONSTRAINT abilities_pkey;
ALTER TABLE public.vendors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_subscriptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_oauth_bindings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_access_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.two_fas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.two_fa_backup_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.top_ups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.task_plugins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.system_tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.subscription_pre_consume_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.subscription_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.subscription_orders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.setups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.redemptions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.quota_data ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.prefill_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.perf_metrics ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.passkey_credentials ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.midjourneys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.login_encryption_keys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.external_identity_claims ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.custom_oauth_providers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.checkins ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.channels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.casbin_rule ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.authz_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_flows ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.audit_logs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.vendors_id_seq;
DROP TABLE public.vendors;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP SEQUENCE public.user_subscriptions_id_seq;
DROP TABLE public.user_subscriptions;
DROP TABLE public.user_sessions;
DROP SEQUENCE public.user_oauth_bindings_id_seq;
DROP TABLE public.user_oauth_bindings;
DROP SEQUENCE public.user_access_tokens_id_seq;
DROP TABLE public.user_access_tokens;
DROP SEQUENCE public.two_fas_id_seq;
DROP TABLE public.two_fas;
DROP SEQUENCE public.two_fa_backup_codes_id_seq;
DROP TABLE public.two_fa_backup_codes;
DROP SEQUENCE public.top_ups_id_seq;
DROP TABLE public.top_ups;
DROP SEQUENCE public.tokens_id_seq;
DROP TABLE public.tokens;
DROP SEQUENCE public.tasks_id_seq;
DROP TABLE public.tasks;
DROP SEQUENCE public.task_plugins_id_seq;
DROP TABLE public.task_plugins;
DROP SEQUENCE public.system_tasks_id_seq;
DROP TABLE public.system_tasks;
DROP TABLE public.system_task_locks;
DROP TABLE public.system_instances;
DROP SEQUENCE public.subscription_pre_consume_records_id_seq;
DROP TABLE public.subscription_pre_consume_records;
DROP SEQUENCE public.subscription_plans_id_seq;
DROP TABLE public.subscription_plans;
DROP SEQUENCE public.subscription_orders_id_seq;
DROP TABLE public.subscription_orders;
DROP SEQUENCE public.setups_id_seq;
DROP TABLE public.setups;
DROP SEQUENCE public.redemptions_id_seq;
DROP TABLE public.redemptions;
DROP SEQUENCE public.quota_data_id_seq;
DROP TABLE public.quota_data;
DROP SEQUENCE public.prefill_groups_id_seq;
DROP TABLE public.prefill_groups;
DROP SEQUENCE public.perf_metrics_id_seq;
DROP TABLE public.perf_metrics;
DROP SEQUENCE public.passkey_credentials_id_seq;
DROP TABLE public.passkey_credentials;
DROP TABLE public.options;
DROP SEQUENCE public.models_id_seq;
DROP TABLE public.models;
DROP SEQUENCE public.midjourneys_id_seq;
DROP TABLE public.midjourneys;
DROP SEQUENCE public.logs_id_seq;
DROP TABLE public.logs;
DROP SEQUENCE public.login_encryption_keys_id_seq;
DROP TABLE public.login_encryption_keys;
DROP SEQUENCE public.external_identity_claims_id_seq;
DROP TABLE public.external_identity_claims;
DROP SEQUENCE public.custom_oauth_providers_id_seq;
DROP TABLE public.custom_oauth_providers;
DROP SEQUENCE public.checkins_id_seq;
DROP TABLE public.checkins;
DROP SEQUENCE public.channels_id_seq;
DROP TABLE public.channels;
DROP SEQUENCE public.casbin_rule_id_seq;
DROP TABLE public.casbin_rule;
DROP SEQUENCE public.authz_roles_id_seq;
DROP TABLE public.authz_roles;
DROP SEQUENCE public.auth_flows_id_seq;
DROP TABLE public.auth_flows;
DROP SEQUENCE public.audit_logs_id_seq;
DROP TABLE public.audit_logs;
DROP TABLE public.abilities;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: abilities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.abilities (
    "group" character varying(64) NOT NULL,
    model character varying(255) NOT NULL,
    channel_id bigint NOT NULL,
    enabled boolean,
    priority bigint DEFAULT 0,
    weight bigint DEFAULT 0,
    tag text
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    event_id character varying(64),
    user_id bigint,
    username character varying(64),
    actor_role bigint,
    created_at bigint,
    category character varying(24),
    action character varying(128),
    token_ref character varying(64),
    auth_method character varying(24),
    ip character varying(64),
    user_agent character varying(512),
    method character varying(16),
    route character varying(255),
    status bigint,
    success boolean,
    request_id character varying(64),
    content text,
    other json
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: auth_flows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_flows (
    id bigint NOT NULL,
    token_hash character(64) NOT NULL,
    purpose character varying(32) NOT NULL,
    provider character varying(64),
    intent character varying(16),
    user_id bigint,
    session_id character varying(64),
    payload text,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone
);


--
-- Name: auth_flows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_flows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_flows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_flows_id_seq OWNED BY public.auth_flows.id;


--
-- Name: authz_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authz_roles (
    id bigint NOT NULL,
    key character varying(64) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    built_in boolean,
    enabled boolean,
    sort bigint,
    created_at bigint,
    updated_at bigint
);


--
-- Name: authz_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.authz_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: authz_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.authz_roles_id_seq OWNED BY public.authz_roles.id;


--
-- Name: casbin_rule; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.casbin_rule (
    id bigint NOT NULL,
    ptype character varying(100),
    v0 character varying(100),
    v1 character varying(100),
    v2 character varying(100),
    v3 character varying(100),
    v4 character varying(100),
    v5 character varying(100)
);


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.casbin_rule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.casbin_rule_id_seq OWNED BY public.casbin_rule.id;


--
-- Name: channels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channels (
    id bigint NOT NULL,
    type bigint DEFAULT 0,
    key text NOT NULL,
    open_ai_organization text,
    test_model text,
    status bigint DEFAULT 1,
    name text,
    weight bigint DEFAULT 0,
    created_time bigint,
    test_time bigint,
    response_time bigint,
    base_url text DEFAULT ''::text,
    other text,
    balance numeric,
    balance_updated_time bigint,
    models text,
    "group" character varying(64) DEFAULT 'default'::character varying,
    used_quota bigint DEFAULT 0,
    model_mapping text,
    status_code_mapping character varying(1024) DEFAULT ''::character varying,
    priority bigint DEFAULT 0,
    auto_ban bigint DEFAULT 1,
    other_info text,
    tag text,
    setting text,
    param_override text,
    header_override text,
    remark character varying(255),
    channel_info json,
    settings text
);


--
-- Name: channels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.channels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.channels_id_seq OWNED BY public.channels.id;


--
-- Name: checkins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checkins (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    checkin_date character varying(10) NOT NULL,
    quota_awarded bigint NOT NULL,
    created_at bigint
);


--
-- Name: checkins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.checkins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: checkins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.checkins_id_seq OWNED BY public.checkins.id;


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_oauth_providers (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    slug character varying(64) NOT NULL,
    icon character varying(128) DEFAULT ''::character varying,
    enabled boolean DEFAULT false,
    client_id character varying(256),
    client_secret character varying(512),
    authorization_endpoint character varying(512),
    token_endpoint character varying(512),
    user_info_endpoint character varying(512),
    scopes character varying(256) DEFAULT 'openid profile email'::character varying,
    user_id_field character varying(128) DEFAULT 'sub'::character varying,
    username_field character varying(128) DEFAULT 'preferred_username'::character varying,
    display_name_field character varying(128) DEFAULT 'name'::character varying,
    email_field character varying(128) DEFAULT 'email'::character varying,
    well_known character varying(512),
    auth_style bigint DEFAULT 0,
    access_policy text,
    access_denied_message character varying(512),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: custom_oauth_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_oauth_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_oauth_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_oauth_providers_id_seq OWNED BY public.custom_oauth_providers.id;


--
-- Name: external_identity_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_identity_claims (
    id bigint NOT NULL,
    provider character varying(32) NOT NULL,
    subject character varying(128) NOT NULL,
    user_id bigint NOT NULL,
    created_at timestamp with time zone
);


--
-- Name: external_identity_claims_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.external_identity_claims_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: external_identity_claims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.external_identity_claims_id_seq OWNED BY public.external_identity_claims.id;


--
-- Name: login_encryption_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.login_encryption_keys (
    id bigint NOT NULL,
    slot character varying(32) NOT NULL,
    private_key_pem text NOT NULL
);


--
-- Name: login_encryption_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.login_encryption_keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: login_encryption_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.login_encryption_keys_id_seq OWNED BY public.login_encryption_keys.id;


--
-- Name: logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.logs (
    id bigint NOT NULL,
    user_id bigint,
    created_at bigint,
    type bigint,
    content text,
    username text DEFAULT ''::text,
    token_name text DEFAULT ''::text,
    model_name text DEFAULT ''::text,
    quota bigint DEFAULT 0,
    prompt_tokens bigint DEFAULT 0,
    completion_tokens bigint DEFAULT 0,
    use_time bigint DEFAULT 0,
    is_stream boolean,
    channel_id bigint,
    channel_name text,
    token_id bigint DEFAULT 0,
    "group" text,
    ip text DEFAULT ''::text,
    request_id character varying(64) DEFAULT ''::character varying,
    upstream_request_id character varying(128) DEFAULT ''::character varying,
    other text
);


--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.logs_id_seq OWNED BY public.logs.id;


--
-- Name: midjourneys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.midjourneys (
    id bigint NOT NULL,
    code bigint,
    user_id bigint,
    action character varying(40),
    mj_id text,
    prompt text,
    prompt_en text,
    description text,
    state text,
    submit_time bigint,
    start_time bigint,
    finish_time bigint,
    image_url text,
    video_url text,
    video_urls text,
    status character varying(20),
    progress character varying(30),
    fail_reason text,
    channel_id bigint,
    quota bigint,
    buttons text,
    properties text,
    token_id bigint DEFAULT 0,
    billing_channel_id bigint DEFAULT 0
);


--
-- Name: midjourneys_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.midjourneys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: midjourneys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.midjourneys_id_seq OWNED BY public.midjourneys.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.models (
    id bigint NOT NULL,
    model_name character varying(128) NOT NULL,
    description text,
    icon character varying(128),
    tags character varying(255),
    vendor_id bigint,
    endpoints text,
    status bigint DEFAULT 1,
    sync_official bigint DEFAULT 1,
    created_time bigint,
    updated_time bigint,
    deleted_at timestamp with time zone,
    name_rule bigint DEFAULT 0
);


--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.options (
    key text NOT NULL,
    value text
);


--
-- Name: passkey_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.passkey_credentials (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    rp_id character varying(253),
    credential_id character varying(512) NOT NULL,
    public_key text NOT NULL,
    attestation_type character varying(255),
    aa_guid character varying(512),
    sign_count bigint DEFAULT 0,
    clone_warning boolean,
    user_present boolean,
    user_verified boolean,
    backup_eligible boolean,
    backup_state boolean,
    transports text,
    attachment character varying(32),
    last_used_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: passkey_credentials_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.passkey_credentials_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: passkey_credentials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.passkey_credentials_id_seq OWNED BY public.passkey_credentials.id;


--
-- Name: perf_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.perf_metrics (
    id bigint NOT NULL,
    model_name character varying(128),
    "group" character varying(64),
    bucket_ts bigint,
    request_count bigint DEFAULT 0,
    success_count bigint DEFAULT 0,
    total_latency_ms bigint DEFAULT 0,
    ttft_sum_ms bigint DEFAULT 0,
    ttft_count bigint DEFAULT 0,
    output_tokens bigint DEFAULT 0,
    generation_ms bigint DEFAULT 0
);


--
-- Name: perf_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.perf_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: perf_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.perf_metrics_id_seq OWNED BY public.perf_metrics.id;


--
-- Name: prefill_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prefill_groups (
    id bigint NOT NULL,
    name character varying(64) NOT NULL,
    type character varying(32) NOT NULL,
    items json,
    description character varying(255),
    created_time bigint,
    updated_time bigint,
    deleted_at timestamp with time zone
);


--
-- Name: prefill_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prefill_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prefill_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prefill_groups_id_seq OWNED BY public.prefill_groups.id;


--
-- Name: quota_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quota_data (
    id bigint NOT NULL,
    user_id bigint,
    username character varying(64) DEFAULT ''::character varying,
    model_name character varying(64) DEFAULT ''::character varying,
    created_at bigint,
    use_group character varying(64) DEFAULT ''::character varying,
    token_id bigint DEFAULT 0,
    channel_id bigint DEFAULT 0,
    node_name character varying(64) DEFAULT ''::character varying,
    token_used bigint DEFAULT 0,
    count bigint DEFAULT 0,
    quota bigint DEFAULT 0,
    cache_read_tokens bigint DEFAULT 0,
    cache_creation_tokens bigint DEFAULT 0
);


--
-- Name: quota_data_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.quota_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: quota_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.quota_data_id_seq OWNED BY public.quota_data.id;


--
-- Name: redemptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redemptions (
    id bigint NOT NULL,
    user_id bigint,
    key character(32),
    status bigint DEFAULT 1,
    name text,
    quota bigint DEFAULT 100,
    created_time bigint,
    redeemed_time bigint,
    used_user_id bigint,
    deleted_at timestamp with time zone,
    expired_time bigint
);


--
-- Name: redemptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.redemptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: redemptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.redemptions_id_seq OWNED BY public.redemptions.id;


--
-- Name: setups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.setups (
    id bigint NOT NULL,
    version character varying(50) NOT NULL,
    initialized_at bigint NOT NULL
);


--
-- Name: setups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.setups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: setups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.setups_id_seq OWNED BY public.setups.id;


--
-- Name: subscription_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_orders (
    id bigint NOT NULL,
    user_id bigint,
    plan_id bigint,
    money numeric,
    trade_no character varying(255),
    payment_method character varying(50),
    payment_provider character varying(50) DEFAULT ''::character varying,
    status text,
    create_time bigint,
    complete_time bigint,
    provider_payload text
);


--
-- Name: subscription_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_orders_id_seq OWNED BY public.subscription_orders.id;


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id bigint NOT NULL,
    title character varying(128) NOT NULL,
    subtitle character varying(255) DEFAULT ''::character varying,
    price_amount numeric(10,6) DEFAULT 0 NOT NULL,
    currency character varying(8) DEFAULT 'USD'::character varying NOT NULL,
    duration_unit character varying(16) DEFAULT 'month'::character varying NOT NULL,
    duration_value bigint DEFAULT 1 NOT NULL,
    custom_seconds bigint DEFAULT 0 NOT NULL,
    enabled boolean DEFAULT true,
    sort_order bigint DEFAULT 0,
    allow_balance_pay boolean,
    allow_wallet_overflow boolean,
    stripe_price_id character varying(128) DEFAULT ''::character varying,
    creem_product_id character varying(128) DEFAULT ''::character varying,
    waffo_pancake_product_id character varying(128) DEFAULT ''::character varying,
    max_purchase_per_user bigint DEFAULT 0,
    upgrade_group character varying(64) DEFAULT ''::character varying,
    downgrade_group character varying(64) DEFAULT ''::character varying,
    total_amount bigint DEFAULT 0 NOT NULL,
    quota_reset_period character varying(16) DEFAULT 'never'::character varying,
    quota_reset_custom_seconds bigint DEFAULT 0,
    created_at bigint,
    updated_at bigint
);


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_plans_id_seq OWNED BY public.subscription_plans.id;


--
-- Name: subscription_pre_consume_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_pre_consume_records (
    id bigint NOT NULL,
    request_id character varying(64),
    user_id bigint,
    user_subscription_id bigint,
    pre_consumed bigint DEFAULT 0 NOT NULL,
    status character varying(32),
    created_at bigint,
    updated_at bigint
);


--
-- Name: subscription_pre_consume_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subscription_pre_consume_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subscription_pre_consume_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subscription_pre_consume_records_id_seq OWNED BY public.subscription_pre_consume_records.id;


--
-- Name: system_instances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_instances (
    node_name character varying(128) NOT NULL,
    info text,
    started_at bigint,
    last_seen_at bigint,
    created_at bigint,
    updated_at bigint
);


--
-- Name: system_task_locks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_task_locks (
    type character varying(64) NOT NULL,
    task_id character varying(64),
    locked_by character varying(128),
    locked_until bigint,
    updated_at bigint
);


--
-- Name: system_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_tasks (
    id bigint NOT NULL,
    task_id character varying(64),
    type character varying(64),
    status character varying(32),
    active_key character varying(64),
    payload text,
    state text,
    result text,
    error text,
    locked_by character varying(128),
    created_at bigint,
    updated_at bigint
);


--
-- Name: system_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_tasks_id_seq OWNED BY public.system_tasks.id;


--
-- Name: task_plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_plugins (
    id bigint NOT NULL,
    key character varying(128) NOT NULL,
    api_version bigint NOT NULL,
    version character varying(64) NOT NULL,
    source text NOT NULL,
    source_hash character varying(64) NOT NULL,
    icon text,
    enabled boolean NOT NULL,
    active boolean NOT NULL,
    created_at bigint NOT NULL,
    remark text
);


--
-- Name: task_plugins_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_plugins_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_plugins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_plugins_id_seq OWNED BY public.task_plugins.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    created_at bigint,
    updated_at bigint,
    task_id character varying(191),
    platform character varying(30),
    user_id bigint,
    "group" character varying(50),
    channel_id bigint,
    quota bigint,
    action character varying(40),
    status character varying(20),
    fail_reason text,
    submit_time bigint,
    start_time bigint,
    finish_time bigint,
    progress character varying(20),
    properties json,
    private_data json,
    data json
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id bigint NOT NULL,
    user_id bigint,
    key character varying(128),
    status bigint DEFAULT 1,
    name text,
    created_time bigint,
    accessed_time bigint,
    expired_time bigint DEFAULT '-1'::integer,
    remain_quota bigint DEFAULT 0,
    unlimited_quota boolean,
    model_limits_enabled boolean,
    model_limits text,
    allow_ips text DEFAULT ''::text,
    used_quota bigint DEFAULT 0,
    "group" text DEFAULT ''::text,
    cross_group_retry boolean,
    auto_groups text,
    deleted_at timestamp with time zone,
    allow_user_quota_query boolean
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: top_ups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.top_ups (
    id bigint NOT NULL,
    user_id bigint,
    amount bigint,
    money numeric,
    trade_no character varying(255),
    payment_method character varying(50),
    payment_provider character varying(50) DEFAULT ''::character varying,
    create_time bigint,
    complete_time bigint,
    status text
);


--
-- Name: top_ups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.top_ups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: top_ups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.top_ups_id_seq OWNED BY public.top_ups.id;


--
-- Name: two_fa_backup_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_fa_backup_codes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    code_hash character varying(255) NOT NULL,
    is_used boolean,
    used_at timestamp with time zone,
    created_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: two_fa_backup_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.two_fa_backup_codes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_fa_backup_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.two_fa_backup_codes_id_seq OWNED BY public.two_fa_backup_codes.id;


--
-- Name: two_fas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_fas (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    secret character varying(255) NOT NULL,
    is_enabled boolean,
    failed_attempts bigint DEFAULT 0,
    locked_until timestamp with time zone,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone
);


--
-- Name: two_fas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.two_fas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_fas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.two_fas_id_seq OWNED BY public.two_fas.id;


--
-- Name: user_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_access_tokens (
    id bigint NOT NULL,
    user_id bigint,
    name character varying(64),
    token_hash character varying(64),
    token_hint character varying(8),
    scopes character varying(2048),
    expires_at bigint,
    last_used_at bigint,
    last_used_ip character varying(64),
    created_at bigint
);


--
-- Name: user_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_access_tokens_id_seq OWNED BY public.user_access_tokens.id;


--
-- Name: user_oauth_bindings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_oauth_bindings (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    provider_id bigint NOT NULL,
    provider_user_id character varying(256) NOT NULL,
    created_at timestamp with time zone
);


--
-- Name: user_oauth_bindings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_oauth_bindings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_oauth_bindings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_oauth_bindings_id_seq OWNED BY public.user_oauth_bindings.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_sessions (
    sid character varying(64) NOT NULL,
    user_id bigint NOT NULL,
    version bigint DEFAULT 1 NOT NULL,
    user_auth_version bigint NOT NULL,
    status character varying(16) NOT NULL,
    refresh_hash character(64) NOT NULL,
    previous_refresh_hash character varying(64),
    previous_valid_until bigint DEFAULT 0 NOT NULL,
    login_method character varying(32) NOT NULL,
    ip character varying(64),
    user_agent text,
    created_at bigint,
    last_active_at bigint NOT NULL,
    expires_at bigint NOT NULL,
    revoked_at bigint DEFAULT 0 NOT NULL,
    revoked_reason character varying(64)
);


--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_subscriptions (
    id bigint NOT NULL,
    user_id bigint,
    plan_id bigint,
    amount_total bigint DEFAULT 0 NOT NULL,
    amount_used bigint DEFAULT 0 NOT NULL,
    start_time bigint,
    end_time bigint,
    status character varying(32),
    source character varying(32) DEFAULT 'order'::character varying,
    last_reset_time bigint DEFAULT 0,
    next_reset_time bigint DEFAULT 0,
    upgrade_group character varying(64) DEFAULT ''::character varying,
    prev_user_group character varying(64) DEFAULT ''::character varying,
    downgrade_group character varying(64) DEFAULT ''::character varying,
    allow_wallet_overflow boolean,
    created_at bigint,
    updated_at bigint
);


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_subscriptions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_subscriptions_id_seq OWNED BY public.user_subscriptions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username text,
    password text NOT NULL,
    display_name text,
    role bigint DEFAULT 1,
    status bigint DEFAULT 1,
    email text,
    github_id text,
    discord_id text,
    oidc_id text,
    wechat_id text,
    telegram_id text,
    access_token character(32),
    access_token_created_at bigint,
    quota bigint DEFAULT 0,
    used_quota bigint DEFAULT 0,
    request_count bigint DEFAULT 0,
    "group" character varying(64) DEFAULT 'default'::character varying,
    aff_code character varying(32),
    aff_count bigint DEFAULT 0,
    aff_quota bigint DEFAULT 0,
    aff_history bigint DEFAULT 0,
    inviter_id bigint,
    deleted_at timestamp with time zone,
    linux_do_id text,
    setting text,
    remark character varying(255),
    stripe_customer character varying(64),
    created_at bigint,
    last_login_at bigint DEFAULT 0,
    auth_version bigint DEFAULT 1 NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vendors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vendors (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    description text,
    icon character varying(128),
    status bigint DEFAULT 1,
    created_time bigint,
    updated_time bigint,
    deleted_at timestamp with time zone
);


--
-- Name: vendors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vendors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vendors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vendors_id_seq OWNED BY public.vendors.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: auth_flows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_flows ALTER COLUMN id SET DEFAULT nextval('public.auth_flows_id_seq'::regclass);


--
-- Name: authz_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authz_roles ALTER COLUMN id SET DEFAULT nextval('public.authz_roles_id_seq'::regclass);


--
-- Name: casbin_rule id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.casbin_rule ALTER COLUMN id SET DEFAULT nextval('public.casbin_rule_id_seq'::regclass);


--
-- Name: channels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels ALTER COLUMN id SET DEFAULT nextval('public.channels_id_seq'::regclass);


--
-- Name: checkins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkins ALTER COLUMN id SET DEFAULT nextval('public.checkins_id_seq'::regclass);


--
-- Name: custom_oauth_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_oauth_providers ALTER COLUMN id SET DEFAULT nextval('public.custom_oauth_providers_id_seq'::regclass);


--
-- Name: external_identity_claims id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identity_claims ALTER COLUMN id SET DEFAULT nextval('public.external_identity_claims_id_seq'::regclass);


--
-- Name: login_encryption_keys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_encryption_keys ALTER COLUMN id SET DEFAULT nextval('public.login_encryption_keys_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs ALTER COLUMN id SET DEFAULT nextval('public.logs_id_seq'::regclass);


--
-- Name: midjourneys id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.midjourneys ALTER COLUMN id SET DEFAULT nextval('public.midjourneys_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: passkey_credentials id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_credentials ALTER COLUMN id SET DEFAULT nextval('public.passkey_credentials_id_seq'::regclass);


--
-- Name: perf_metrics id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perf_metrics ALTER COLUMN id SET DEFAULT nextval('public.perf_metrics_id_seq'::regclass);


--
-- Name: prefill_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prefill_groups ALTER COLUMN id SET DEFAULT nextval('public.prefill_groups_id_seq'::regclass);


--
-- Name: quota_data id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quota_data ALTER COLUMN id SET DEFAULT nextval('public.quota_data_id_seq'::regclass);


--
-- Name: redemptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redemptions ALTER COLUMN id SET DEFAULT nextval('public.redemptions_id_seq'::regclass);


--
-- Name: setups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setups ALTER COLUMN id SET DEFAULT nextval('public.setups_id_seq'::regclass);


--
-- Name: subscription_orders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_orders ALTER COLUMN id SET DEFAULT nextval('public.subscription_orders_id_seq'::regclass);


--
-- Name: subscription_plans id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans ALTER COLUMN id SET DEFAULT nextval('public.subscription_plans_id_seq'::regclass);


--
-- Name: subscription_pre_consume_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_pre_consume_records ALTER COLUMN id SET DEFAULT nextval('public.subscription_pre_consume_records_id_seq'::regclass);


--
-- Name: system_tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_tasks ALTER COLUMN id SET DEFAULT nextval('public.system_tasks_id_seq'::regclass);


--
-- Name: task_plugins id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_plugins ALTER COLUMN id SET DEFAULT nextval('public.task_plugins_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: top_ups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.top_ups ALTER COLUMN id SET DEFAULT nextval('public.top_ups_id_seq'::regclass);


--
-- Name: two_fa_backup_codes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_fa_backup_codes ALTER COLUMN id SET DEFAULT nextval('public.two_fa_backup_codes_id_seq'::regclass);


--
-- Name: two_fas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_fas ALTER COLUMN id SET DEFAULT nextval('public.two_fas_id_seq'::regclass);


--
-- Name: user_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.user_access_tokens_id_seq'::regclass);


--
-- Name: user_oauth_bindings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oauth_bindings ALTER COLUMN id SET DEFAULT nextval('public.user_oauth_bindings_id_seq'::regclass);


--
-- Name: user_subscriptions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.user_subscriptions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vendors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors ALTER COLUMN id SET DEFAULT nextval('public.vendors_id_seq'::regclass);


--
-- Data for Name: abilities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.abilities ("group", model, channel_id, enabled, priority, weight, tag) FROM stdin;
default	claude-opus-5-5	2	t	0	1	\N
default	claude-opus-5.5	2	t	0	1	\N
default	claude-opus-4-8	2	t	0	1	\N
default	claude-fable-5.1-req	2	t	0	1	\N
default	gpt-6.1-sol	3	t	0	1	\N
default	cx/gpt-6-luna	3	t	0	1	\N
default	slow/agy/gemini-3.8-flash-medium	4	t	0	1	\N
default	deepseek-v4.1-flash-1017	1	t	0	1	\N
default	cnb/deepseek-pro-v4	1	t	0	1	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, event_id, user_id, username, actor_role, created_at, category, action, token_ref, auth_method, ip, user_agent, method, route, status, success, request_id, content, other) FROM stdin;
1	202611071503584710653628268d9d6xpl8Fapl	1	admin	100	1794063838	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071503584310871608268d9d6l91A8weG	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
2	202611071504026170859738268d9d6ayov8AUU	1	admin	100	1794063842	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071504025761101588268d9d6IRbOMEVw	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
3	202611071504026361393068268d9d6Lh0XTKw8	1	admin	100	1794063842	operation	channel.create		session	172.22.0.1	curl/8.21.0	POST	/api/channel/	200	t	202611071504026329792278268d9d6RWzZnwpX	Created channel Vilao-DeepSeek (type 1, count 1)	{"op":{"action":"channel.create","params":{"count":1,"name":"Vilao-DeepSeek","type":1}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
4	202611071504248678972538268d9d6gEYY2LIL	1	admin	100	1794063864	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071504248580651858268d9d6xvJguXIx	Updated system setting ModelRatio	{"op":{"action":"option.update","params":{"key":"ModelRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
5	202611071504248771781448268d9d6Ly8a3jCb	1	admin	100	1794063864	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071504248721188438268d9d6gvQB7yEa	Updated system setting CompletionRatio	{"op":{"action":"option.update","params":{"key":"CompletionRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
6	202611071504248825199888268d9d6iAFIVXLO	1	admin	100	1794063864	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071504248800188228268d9d62bqc6tw9	Updated system setting SystemName	{"op":{"action":"option.update","params":{"key":"SystemName"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
7	202611071504248873964488268d9d6NV0mYRbR	1	admin	100	1794063864	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071504248849266948268d9d6qEGt89FC	Updated system setting Footer	{"op":{"action":"option.update","params":{"key":"Footer"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
8	202611071504427655682378268d9d68O1c7qEi	1	admin	100	1794063882	security	token.create		session	172.22.0.1	curl/8.21.0	POST	/api/token/	200	t	202611071504427623592868268d9d6FxUxJtRc	API token creation	{"op":{"action":"token.create","params":{"id":1,"name":"dgai-test"}}}
9	202611071504427795402198268d9d6k9ZLT2uf	1	admin	100	1794063882	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071504427779961998268d9d6DwaY2Vo6	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
10	202611071505363714914978268d9d69rn6A5ec	1	admin	100	1794063936	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071505363402655268268d9d6bBEJKc2F	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
11	202611071550016956858758268d9d6vRSEWchD	1	admin	100	1794066601	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071550016538060668268d9d6xgK2OoDh	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
12	202611071550203912586418268d9d6SYFLnrQe	1	admin	100	1794066620	security	user.security_verify		session	172.22.0.1	curl/8.21.0	POST	/api/verify	200	t	202611071550203576892188268d9d6y2YQK6Fo	Completed security verification	{"op":{"action":"user.security_verify","params":{"method":"password","scope":"account.password.change"}}}
13	202611071550248304483838268d9d6E14x3xhi	1	admin	100	1794066624	security	user.security_verify		session	172.22.0.1	curl/8.21.0	POST	/api/verify	200	t	202611071550247951635068268d9d6LmC3uCTQ	Completed security verification	{"op":{"action":"user.security_verify","params":{"method":"password","scope":"account.password.change"}}}
14	202611071550249006746618268d9d6Mg9h9kNj	1	admin	100	1794066624	security	user.password_change		session	172.22.0.1	curl/8.21.0	PUT	/api/user/self	200	t	202611071550248449564158268d9d6fd0dMIEj	Account password change	{"op":{"action":"user.password_change","params":{"notification_failed":false,"success":true}},"audit_info":{"method":"PUT","route":"/api/user/self","path":"/api/user/self","status":200,"success":true}}
15	202611071550344680302038268d9d6GNvZPpeI	1	admin	100	1794066634	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071550344458124828268d9d6BF3NegEd	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
16	202611071552096305102668268d9d6ncudOekB	1	admin	100	1794066729	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071552095926374328268d9d65zomadKj	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
17	202611071552097056660048268d9d6SXGZW4GR	1	admin	100	1794066729	operation	option.payment_compliance		session	172.22.0.1	curl/8.21.0	POST	/api/option/payment_compliance	200	t	202611071552096927288358268d9d6eC9kuMEL	POST /api/option/payment_compliance	{"op":{"action":"option.payment_compliance"},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"POST","route":"/api/option/payment_compliance","path":"/api/option/payment_compliance","status":200,"success":true}}
18	202611071552188560764688268d9d6jZrcYonP	1	admin	100	1794066738	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071552188526639058268d9d6IoWRdiey	Updated system setting MinTopUp	{"op":{"action":"option.update","params":{"key":"MinTopUp"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
19	202611071552189071933828268d9d6fvh4iTZX	1	admin	100	1794066738	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071552189046589288268d9d6vrZaYiCe	Updated system setting Price	{"op":{"action":"option.update","params":{"key":"Price"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
20	202611071552189552883248268d9d6dMBGaTxa	1	admin	100	1794066738	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071552189526046238268d9d6eHnjQSPv	Updated system setting USDExchangeRate	{"op":{"action":"option.update","params":{"key":"USDExchangeRate"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
21	202611071552190118261678268d9d6giyrWldP	1	admin	100	1794066739	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071552190087729528268d9d6Qm3WiTSZ	Updated system setting PayMethods	{"op":{"action":"option.update","params":{"key":"PayMethods"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
22	202611071552190603899028268d9d6upgLdWSj	1	admin	100	1794066739	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071552190571025158268d9d6hzgG3U86	Updated system setting TopUpLink	{"op":{"action":"option.update","params":{"key":"TopUpLink"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
23	202611071553058216902808268d9d6Es7sRLzs	1	admin	100	1794066785	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071553058176232358268d9d6cn3kn9R2	Updated system setting payment_setting.amount_options	{"op":{"action":"option.update","params":{"key":"payment_setting.amount_options"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
24	202611071553058762499308268d9d6ybKNnkxv	1	admin	100	1794066785	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071553058736912628268d9d640rPYK1s	Updated system setting payment_setting.amount_discount	{"op":{"action":"option.update","params":{"key":"payment_setting.amount_discount"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
25	202611071553201934899958268d9d66AJ4AKBI	1	admin	100	1794066800	operation	redemption.create		session	172.22.0.1	curl/8.21.0	POST	/api/redemption/	200	t	202611071553201898326318268d9d6n3ql9nfo	Created 1 redemption codes named nap-1usd (＄1.000000 each)	{"op":{"action":"redemption.create","params":{"count":1,"name":"nap-1usd","quota":"＄1.000000"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
26	202611071553326981903658268d9d6pqVxvTtX	1	admin	100	1794066812	operation	user.topup_complete		session	172.22.0.1	curl/8.21.0	POST	/api/user/topup/complete	200	f	202611071553326962400308268d9d60KBc9qAa	POST /api/user/topup/complete	{"op":{"action":"user.topup_complete"},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"POST","route":"/api/user/topup/complete","path":"/api/user/topup/complete","status":200,"success":false}}
27	202611071553517470772158268d9d6DcJN99UH	1	admin	100	1794066831	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071553517438412658268d9d6h4NNdKSC	Updated system setting QuotaDisplayType	{"op":{"action":"option.update","params":{"key":"QuotaDisplayType"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
28	202611071553517980435198268d9d6WhpuV7nD	1	admin	100	1794066831	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071553517959072338268d9d68pFrX9W8	Updated system setting TopUpLink	{"op":{"action":"option.update","params":{"key":"TopUpLink"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
29	202611071556299576708968268d9d6qVu2ImGs	1	admin	100	1794066989	login	login		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/user/login	200	t	202611071556298902678168268d9d6gFDFncp1	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36"}
30	202611071556544420434488268d9d6hzFafzJr	1	admin	100	1794067014	security	token.key_view		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/token/:id/key	200	t	202611071556544404209628268d9d6Um5CxBGL	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
31	202611071616234187175008268d9d6WOznULw9	1	admin	100	1794068183	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071616233808752328268d9d6bXGA48eu	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
32	202611071616235419171158268d9d6kWEi41b1	1	admin	100	1794068183	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071616235368522758268d9d6qEiacEUA	Updated system setting general_setting.docs_link	{"op":{"action":"option.update","params":{"key":"general_setting.docs_link"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
33	202611071648051888188148268d9d6O3IzNenY	1	admin	100	1794070085	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071648051571136888268d9d6w1S7GVaM	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
34	202611071648128860129918268d9d6vyLchll5	1	admin	100	1794070092	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071648128793996458268d9d6BpWtTiZ4	Updated system setting CacheRatio	{"op":{"action":"option.update","params":{"key":"CacheRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
35	202611071649171334540458268d9d6UGHrgGkG	1	admin	100	1794070157	security	token.create		session	172.22.0.1	curl/8.21.0	POST	/api/token/	200	t	202611071649171256016608268d9d69CV8iLPK	API token creation	{"op":{"action":"token.create","params":{"id":2,"name":"cache-test"}}}
36	202611071649372173651518268d9d6gDmUBMoQ	1	admin	100	1794070177	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071649372162442368268d9d65vMizzr2	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
37	202611071655149774482918268d9d6yh4HCIPJ	1	admin	100	1794070514	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071655149744240818268d9d6YkFu1FBc	Updated system setting channel_affinity_setting.rules	{"op":{"action":"option.update","params":{"key":"channel_affinity_setting.rules"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
38	202611071702201206188698268d9d6MqpxgT5T	1	admin	100	1794070940	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071702200799156778268d9d6rHVox19Y	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
39	202611071705309611954548268d9d67ofk5HOk	1	admin	100	1794071130	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071705309157916208268d9d6dc5KaMXv	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
40	202611071705310320887038268d9d6MRr8cuaJ	1	admin	100	1794071131	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071705310300876638268d9d6StbVQcLT	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
41	202611071706101897115168268d9d6dKLrvNyL	1	admin	100	1794071170	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071706101606375738268d9d68XKEP6zI	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
42	202611071716262917126238268d9d6LJ3btGbI	1	admin	100	1794071786	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071716262522500048268d9d6D2pNHEkW	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
43	202611071716263592669848268d9d6fbyszT3v	1	admin	100	1794071786	operation	channel.create		session	172.22.0.1	curl/8.21.0	POST	/api/channel/	200	t	202611071716263557636118268d9d6LYMsZtES	Created channel Vilao-Opus (type 1, count 1)	{"op":{"action":"channel.create","params":{"count":1,"name":"Vilao-Opus","type":1}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
44	202611071718310970514788268d9d6HKyC6cgv	1	admin	100	1794071911	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071718310708990478268d9d6Bq2IjcFY	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
45	202611071718311612685868268d9d6HJq30Z4g	1	admin	100	1794071911	operation	channel.create		session	172.22.0.1	curl/8.21.0	POST	/api/channel/	200	t	202611071718311588397778268d9d6AhPdMkM9	Created channel Vilao-GPT (type 1, count 1)	{"op":{"action":"channel.create","params":{"count":1,"name":"Vilao-GPT","type":1}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
46	202611071719277561609798268d9d6qlhiGhae	1	admin	100	1794071967	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071719277474530098268d9d61xXikABi	Updated system setting ModelRatio	{"op":{"action":"option.update","params":{"key":"ModelRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
47	202611071719278151888638268d9d63xWRtrDQ	1	admin	100	1794071967	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071719278074741398268d9d6DgrLe7qa	Updated system setting CompletionRatio	{"op":{"action":"option.update","params":{"key":"CompletionRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
48	202611071719278687717378268d9d6BTjm8Y3P	1	admin	100	1794071967	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071719278634781308268d9d6t91d7zDJ	Updated system setting CacheRatio	{"op":{"action":"option.update","params":{"key":"CacheRatio"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
49	202611071719279205288058268d9d6R4NpELUW	1	admin	100	1794071967	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071719279155456408268d9d624BiKxjK	Updated system setting ModelPrice	{"op":{"action":"option.update","params":{"key":"ModelPrice"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
50	202611071720490908411198268d9d61B0kuhGk	1	admin	100	1794072049	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071720490889060568268d9d6B3NtXiYH	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
51	202611071727525704982268268d9d659shFE3Y	1	admin	100	1794072472	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071727525303362488268d9d6noyXhe0U	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
52	202611071736087751823798268d9d6YroXkBnY	1	admin	100	1794072968	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071736087360411558268d9d6xkoxyT2O	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
53	202611071736232070832858268d9d60PAaSjIq	1	admin	100	1794072983	operation	generic		session	172.22.0.1	Python-urllib/3.14	PUT	/api/channel/	200	f	202611071736232063674888268d9d6csY8Caup	PUT /api/channel/	{"op":{"action":"generic","params":{"method":"PUT","route":"/api/channel/"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"PUT","route":"/api/channel/","path":"/api/channel/","status":200,"success":false}}
54	202611071736414371792718268d9d6fDqrAwxr	1	admin	100	1794073001	operation	channel.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/channel/	200	t	202611071736414296412088268d9d6ySNxXHhK	Updated channel Vilao-DeepSeek (ID: 1)	{"op":{"action":"channel.update","params":{"changed_fields":["models"],"id":1,"name":"Vilao-DeepSeek"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
55	202611071736513107877368268d9d6CuHh9H15	1	admin	100	1794073011	operation	channel.create		session	172.22.0.1	curl/8.21.0	POST	/api/channel/	200	t	202611071736513053737538268d9d6DsLlogON	Created channel Vilao-Gemini (type 1, count 1)	{"op":{"action":"channel.create","params":{"count":1,"name":"Vilao-Gemini","type":1}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
56	202611071737034731926648268d9d65JKcpcim	1	admin	100	1794073023	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611071737034637199978268d9d6pHqm2B4z	Updated system setting ModelPrice	{"op":{"action":"option.update","params":{"key":"ModelPrice"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
57	202611071737259510198888268d9d6nRbBtUBN	1	admin	100	1794073045	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071737259492533458268d9d6ZWUyYbmz	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
58	202611071740001137964738268d9d6knURzvKT	1	admin	100	1794073200	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071740000739738898268d9d6wrpSI6v7	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
59	202611071747466530089448268d9d6PLNe6X05	1	admin	100	1794073666	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071747466058030238268d9d6jkDGOcyW	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
60	202611071747467215301178268d9d6HpxL0wfa	1	admin	100	1794073666	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071747467198508988268d9d6oh785qGn	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
61	202611071757329646352988268d9d6NhqJ2GX4	1	admin	100	1794074252	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071757329178370128268d9d6OvMYJJQR	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
62	202611071757330385318178268d9d6fvFEYlPK	1	admin	100	1794074253	security	token.create		session	172.22.0.1	curl/8.21.0	POST	/api/token/	200	t	202611071757330332102358268d9d6cnk1NhTO	API token creation	{"op":{"action":"token.create","params":{"id":3,"name":"harness2"}}}
63	202611071757412124081878268d9d6WQPgH3W0	1	admin	100	1794074261	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071757411851143428268d9d6yLHJYIso	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
64	202611071757412742843228268d9d6vLWMI7pc	1	admin	100	1794074261	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071757412732848388268d9d6ZzTjyCUt	API token key access	{"op":{"action":"token.key_view","params":{"id":3,"name":"harness2"}}}
65	202611071757546883543878268d9d6IkItOQJh	1	admin	100	1794074274	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071757546451514478268d9d6m0lbcE5i	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
66	202611071757547547359928268d9d6CEUbSlyX	1	admin	100	1794074274	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611071757547531247768268d9d67AmjvEkq	API token key access	{"op":{"action":"token.key_view","params":{"id":3,"name":"harness2"}}}
67	202611071814022100463078268d9d6pfnDQnPf	1	admin	100	1794075242	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071814021713708908268d9d6QmeUf9FP	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
68	202611071815339869721628268d9d6sMScDXNb	1	admin	100	1794075333	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071815339465353348268d9d6FAHltv2E	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
69	202611071825283132715258268d9d6cc5caPJJ	1	admin	100	1794075928	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071825282854033528268d9d6mNdYM4Ih	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
70	202611071825531033300828268d9d6xTnZVt8p	1	admin	100	1794075953	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071825530686449838268d9d6JTG6jkC2	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
71	202611071828458148968408268d9d69xIUS3bP	1	admin	100	1794076125	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071828457730594458268d9d6bvsCsWTr	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
72	202611071829367506229778268d9d67PqAzHfJ	1	admin	100	1794076176	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071829367096335108268d9d6q9skDkEy	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
73	202611071836183783079978268d9d6ptgkoeus	1	admin	100	1794076578	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071836183348804878268d9d6GY8WTkkZ	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
74	202611071843509603576398268d9d6W1B4klE6	1	admin	100	1794077030	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071843509210964228268d9d6uXXWqE4L	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
75	202611071845186743665298268d9d62eP1Gw7f	1	admin	100	1794077118	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071845186492626848268d9d61ixPhB89	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
76	202611071846550121631448268d9d6WLJkNoHz	1	admin	100	1794077215	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071846549806431878268d9d6JZCOVsdn	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
77	202611071849089258136758268d9d6PKwSIM0S	1	admin	100	1794077348	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071849088857003208268d9d6YhqyPkdF	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
78	202611071854589634936378268d9d68M93nZA6	1	admin	100	1794077698	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071854589211799158268d9d6Qko8O7iC	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
79	202611071858116189154908268d9d6crgr3Frf	1	admin	100	1794077891	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071858115789118378268d9d6XbRNKYN7	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
80	202611071903266113271858268d9d6TrrKqAqH	1	admin	100	1794078206	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611071903265732082178268d9d6fvlA3kjF	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
81	202611071956459797632658268d9d6wT7XJ3m2	1	admin	100	1794081405	operation	generic		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/option/model_pricing/preview	200	t	202611071956459385440638268d9d6YcyWtDBF	POST /api/option/model_pricing/preview	{"op":{"action":"generic","params":{"method":"POST","route":"/api/option/model_pricing/preview"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"POST","route":"/api/option/model_pricing/preview","path":"/api/option/model_pricing/preview","status":200,"success":true}}
82	202611071957152513174438268d9d6f3oNTaMV	1	admin	100	1794081435	operation	model.create		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/models/	200	t	202611071957152009069148268d9d6FP51uaoL	POST /api/models/	{"op":{"action":"model.create"},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"POST","route":"/api/models/","path":"/api/models/","status":200,"success":true}}
83	202611071957301129397408268d9d6J5snfFtN	1	admin	100	1794081450	operation	model.delete		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	DELETE	/api/models/:id	200	t	202611071957301044318058268d9d6E96Cqmhb	model.delete	{"op":{"action":"model.delete","params":{"model_ids":[1],"remove_from_channels":true,"remove_pricing":false,"updated_channels":1}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
84	202611081157016557969138268d9d6JvHPDi4w	1	admin	100	1794139021	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611081157016167700018268d9d6eIl4UA3Q	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
85	202611081157018431973758268d9d61jWix7WN	1	admin	100	1794139021	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157018400506298268d9d6nTSQlsog	Updated system setting VietQREnabled	{"op":{"action":"option.update","params":{"key":"VietQREnabled"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
86	202611081157018989774908268d9d6RTr71iU1	1	admin	100	1794139021	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157018959527378268d9d6RNmj5ZnW	Updated system setting VietQRBankCode	{"op":{"action":"option.update","params":{"key":"VietQRBankCode"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
87	202611081157019512192838268d9d66sj70Cnj	1	admin	100	1794139021	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157019480565108268d9d63SMhAVEf	Updated system setting VietQRBankAccount	{"op":{"action":"option.update","params":{"key":"VietQRBankAccount"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
88	202611081157019987488288268d9d6PTMoLlVC	1	admin	100	1794139021	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157019960759638268d9d6ikmK8bmV	Updated system setting VietQRAccountName	{"op":{"action":"option.update","params":{"key":"VietQRAccountName"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
89	202611081157020466305488268d9d6QkWcedwM	1	admin	100	1794139022	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157020439809488268d9d6EIEyCPGi	Updated system setting VietQRMinTopUp	{"op":{"action":"option.update","params":{"key":"VietQRMinTopUp"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
90	202611081157020947375008268d9d66SqWNJwO	1	admin	100	1794139022	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157020921327018268d9d6Ab5juXfy	Updated system setting VietQRSyncUsername	{"op":{"action":"option.update","params":{"key":"VietQRSyncUsername"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
91	202611081157021425414978268d9d6WOI186kM	1	admin	100	1794139022	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157021400276398268d9d6vGqvMSFC	Updated system setting VietQRSyncPassword	{"op":{"action":"option.update","params":{"key":"VietQRSyncPassword"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
92	202611081157021906737298268d9d6ywEW8ozJ	1	admin	100	1794139022	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081157021881226938268d9d6dcGpqf5N	Updated system setting VietQRSyncSecretKey	{"op":{"action":"option.update","params":{"key":"VietQRSyncSecretKey"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
93	202611081159036031161158268d9d6XUWVz0s4	1	admin	100	1794139143	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611081159035616608188268d9d66OflgN8G	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
94	202611081200151520216068268d9d6BPt6ONEF	1	admin	100	1794139215	login	login		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/user/login	200	t	202611081200151126701328268d9d6T4Uak6c9	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36"}
95	202611081222304317049878268d9d6HW2ZWetb	1	admin	100	1794140550	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611081222303908495798268d9d6O2LrKGjd	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
96	202611081224374231250638268d9d6ZOdf98eT	1	admin	100	1794140677	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081224374198207538268d9d6S9frVkzG	Updated system setting VietQRSyncUsername	{"op":{"action":"option.update","params":{"key":"VietQRSyncUsername"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
97	202611081224374776991468268d9d6Nfk56tj6	1	admin	100	1794140677	operation	option.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611081224374757398378268d9d6lVsjgYTi	Updated system setting VietQRSyncPassword	{"op":{"action":"option.update","params":{"key":"VietQRSyncPassword"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
98	202611091345188917190768268d9d6Tvo9crKb	1	admin	100	1794231918	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611091345188463428608268d9d61wnpv5ur	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
99	202611091345189759002808268d9d6VwhbV5xS	1	admin	100	1794231918	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611091345189742573538268d9d6Iu6JgWyF	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
100	202611091349328326671808268d9d6Ns9Bfhfs	1	admin	100	1794232172	security	token.key_view		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/token/:id/key	200	t	202611091349328300963888268d9d6qVbLZ5D4	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
101	202611091349486727116388268d9d68nAOfyw6	1	admin	100	1794232188	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611091349486319045428268d9d63VueVWzC	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
102	202611091349488661325098268d9d64rOwS8W9	1	admin	100	1794232188	operation	option.passkey_domains		session	172.22.0.1	Python-urllib/3.14	PUT	/api/option/	200	t	202611091349488599181188268d9d6dptK7cGR	Updated Passkey domains: removed ; affected 0; unknown 0	{"op":{"action":"option.passkey_domains","params":{"confirmed":false,"domains":"","effective_rp_id":"localhost","known":0,"previous_rp_id":"localhost","removed_rp_ids":[],"success":true,"unknown":0}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"},"audit_info":{"method":"PUT","route":"/api/option/","path":"/api/option/","status":200,"success":true}}
103	202611091350001530731648268d9d6qoA1gIns	1	admin	100	1794232200	security	token.key_view		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/token/:id/key	200	t	202611091350001508474758268d9d6RrWDNhOa	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
104	202611091358210831695118268d9d61ZGDVuB4	1	admin	100	1794232701	security	token.key_view		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/token/:id/key	200	t	202611091358210819318938268d9d6WIMbxp6K	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
105	202611091402158881049378268d9d6iFjQ6ZUr	1	admin	100	1794232935	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611091402158540213108268d9d60PadcTQT	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
106	202611091402159623940388268d9d6onBw2kdq	1	admin	100	1794232935	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611091402159608800228268d9d6VfclDoD7	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
107	202611091415215778760448268d9d6CvhAtFJd	1	admin	100	1794233721	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611091415215486397208268d9d6B47RTzYY	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
108	202611091417140251117838268d9d6pHDxeRNz	1	admin	100	1794233834	security	token.key_view		session	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	POST	/api/token/:id/key	200	t	202611091417140239743558268d9d6P8lyuWz1	API token key access	{"op":{"action":"token.key_view","params":{"id":1,"name":"dgai-test"}}}
109	202611091450420476842928268d9d6vOFLvL8s	1	admin	100	1794235842	login	login		session	172.22.0.1	curl/8.21.0	POST	/api/user/login	200	t	202611091450419981712918268d9d6ZkWhcMAO	Logged in successfully via password	{"op":{"action":"login","params":{"method":"password"}},"login_method":"password","user_agent":"curl/8.21.0"}
110	202611091450421320568338268d9d60P2jd3UL	1	admin	100	1794235842	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611091450421302702768268d9d6Zf3kvg50	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
111	202611091450574558587978268d9d6Rqi2lg4D	1	admin	100	1794235857	operation	channel.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/channel/	200	t	202611091450574462495068268d9d6n1MMWUaq	Updated channel Vilao-DeepSeek (ID: 1)	{"op":{"action":"channel.update","params":{"changed_fields":["models"],"id":1,"name":"Vilao-DeepSeek"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
112	202611091451083358076938268d9d6E4XVxmlJ	1	admin	100	1794235868	security	token.key_view		session	172.22.0.1	curl/8.21.0	POST	/api/token/:id/key	200	t	202611091451083329944178268d9d6ie1pd0GD	API token key access	{"op":{"action":"token.key_view","params":{"id":2,"name":"cache-test"}}}
113	202611091451363890967478268d9d6vqf7al5f	1	admin	100	1794235896	operation	channel.update		session	172.22.0.1	Python-urllib/3.14	PUT	/api/channel/	200	t	202611091451363794100428268d9d6dCpzllbu	Updated channel Vilao-DeepSeek (ID: 1)	{"op":{"action":"channel.update","params":{"changed_fields":["models"],"id":1,"name":"Vilao-DeepSeek"}},"admin_info":{"admin_id":1,"admin_username":"admin","admin_role":100,"auth_method":"session"}}
\.


--
-- Data for Name: auth_flows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_flows (id, token_hash, purpose, provider, intent, user_id, session_id, payload, created_at, expires_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: authz_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authz_roles (id, key, name, description, built_in, enabled, sort, created_at, updated_at) FROM stdin;
1	root	Root	Built-in root authorization role	t	t	0	1794063802	1794063802
2	admin	Admin	Built-in admin authorization role	t	t	10	1794063802	1794063802
\.


--
-- Data for Name: casbin_rule; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.casbin_rule (id, ptype, v0, v1, v2, v3, v4, v5) FROM stdin;
103	p	role:admin	channel	read	allow		
104	p	role:admin	channel	operate	allow		
105	p	role:admin	channel	write	allow		
\.


--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channels (id, type, key, open_ai_organization, test_model, status, name, weight, created_time, test_time, response_time, base_url, other, balance, balance_updated_time, models, "group", used_quota, model_mapping, status_code_mapping, priority, auto_ban, other_info, tag, setting, param_override, header_override, remark, channel_info, settings) FROM stdin;
4	1	sk-2e4efb08babad554d748629a40a754bacc98abe02ddf69d48afdd75e28cd6fbc	\N	\N	1	Vilao-Gemini	1	1794073011	1794073036	3334	https://api.vilao.ai		0	0	slow/agy/gemini-3.8-flash-medium	default	1000	\N		0	1		\N	\N	\N	\N	\N	{"is_multi_key":false,"multi_key_size":0,"multi_key_status_list":null,"multi_key_polling_index":0,"multi_key_mode":""}	
1	1	sk-117aee619fd4a1ba95202fbaeba68784650ff070d2177263c70e9e1c5c74ad30	\N	\N	1	Vilao-DeepSeek	1	1794063842	1794235977	1764	https://api.vilao.ai		0	0	deepseek-v4.1-flash-1017,cnb/deepseek-pro-v4	default	129802	\N		0	1		\N	\N	\N	\N	\N	{"is_multi_key":false,"multi_key_size":0,"multi_key_status_list":null,"multi_key_polling_index":0,"multi_key_mode":""}	
2	1	sk-cf74bebacea834991f4c37776828f0ddfc8bb2fce1f8068f9286d875c77b70fa	\N	\N	1	Vilao-Opus	1	1794071786	1794235981	3238	https://api.vilao.ai		0	0	claude-opus-5-5,claude-opus-5.5,claude-opus-4-8,claude-fable-5.1-req	default	29616	\N		0	1		\N	\N	\N	\N	\N	{"is_multi_key":false,"multi_key_size":0,"multi_key_status_list":null,"multi_key_polling_index":0,"multi_key_mode":""}	
3	1	sk-c1d5515cb07f767fd0a2481ed9eb39ca63247dc356d3d5dab2c552e41d514a5e	\N	\N	1	Vilao-GPT	1	1794071911	1794235983	2451	https://api.vilao.ai		0	0	gpt-6.1-sol,cx/gpt-6-luna	default	1217	\N		0	1		\N	\N	\N	\N	\N	{"is_multi_key":false,"multi_key_size":0,"multi_key_status_list":null,"multi_key_polling_index":0,"multi_key_mode":""}	
\.


--
-- Data for Name: checkins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checkins (id, user_id, checkin_date, quota_awarded, created_at) FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_oauth_providers (id, name, slug, icon, enabled, client_id, client_secret, authorization_endpoint, token_endpoint, user_info_endpoint, scopes, user_id_field, username_field, display_name_field, email_field, well_known, auth_style, access_policy, access_denied_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: external_identity_claims; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_identity_claims (id, provider, subject, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: login_encryption_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.login_encryption_keys (id, slot, private_key_pem) FROM stdin;
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.logs (id, user_id, created_at, type, content, username, token_name, model_name, quota, prompt_tokens, completion_tokens, use_time, is_stream, channel_id, channel_name, token_id, "group", ip, request_id, upstream_request_id, other) FROM stdin;
1	1	1794063882	2	Model test	admin	Model test	deepseek-v4.1-flash	3	31	16	6	f	1	\N	0	default		202611071504427475068268268d9d6VYJYY60B		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":1,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":1,"cache_tokens":0,"completion_ratio":3.5,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
2	1	1794063892	2		admin	dgai-test	deepseek-v4.1-flash	3	31	16	5	f	1	\N	1	default		202611071504471284106168268d9d63W4PeIV1		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":4920,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":1,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
3	1	1794063893	2		admin	dgai-test	deepseek-v4.1-flash-1017	2	31	8	1	f	1	\N	1	default		202611071504520676056778268d9d6uwivxFta	202611071504526356980978268d9d68OGkLhBW	{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1096,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":1,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"ali/deepseek-v4.1-flash"},"user_group_ratio":-1}
4	1	1794066807	1	Topped up ＄1.000000 with a redemption code, code ID 1	admin			0	0	0	0	f	0	\N	0			202611071553275600692668268d9d6vnr86cHo		{"content_parts":[{"key":"Topped up {{quota}} with a redemption code, code ID {{id}}","params":{"id":1,"quota":"＄1.000000"}}]}
5	1	1794070260	2		admin	cache-test	deepseek-v4.1-flash	66	1592	16	3	f	1	\N	2	default		202611071650577155178908268d9d6B5C0bp2w		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":2803,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
6	1	1794070264	2		admin	cache-test	deepseek-v4.1-flash	27	1592	16	3	f	1	\N	2	default		202611071651015714072248268d9d6b0iElbnD		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":2577,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1024,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
7	1	1794070267	2		admin	cache-test	deepseek-v4.1-flash	8	1592	16	2	f	1	\N	2	default		202611071651051954623868268d9d6jBN4ZHL3		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":2074,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
8	1	1794070546	2		admin	cache-test	deepseek-v4.1-flash	27	1592	16	6	f	1	\N	2	default		202611071655406569669108268d9d6pw90DBnh		{"admin_info":{"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5893,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1024,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
14	1	1794072036	2	Model test	admin	Model test	claude-opus-5-5	11	1	14	1	f	2	\N	0	default		202611071720362655368028268d9d6iUGsOvGX		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":2,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
9	1	1794070551	2		admin	cache-test	deepseek-v4.1-flash	8	1592	16	4	f	1	\N	2	default		202611071655476249480678268d9d6uRoQmjbp		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4200,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
10	1	1794070556	2		admin	cache-test	deepseek-v4.1-flash	8	1592	16	4	f	1	\N	2	default		202611071655528888870468268d9d6X4XRikwF		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3852,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
11	1	1794071157	2		admin	cache-test	deepseek-v4.1-flash-1017	86	2122	8	1	t	1	\N	2	default		202611071705564922609238268d9d6wOajmBEp	202611071705570678278458268d9d6JKgFPFUg	{"admin_info":{"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1441,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.4,"cache_tokens":0,"completion_ratio":3.5,"frt":1411,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"cbcn/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
12	1	1794071159	2		admin	cache-test	deepseek-v4.1-flash-1017	37	2122	8	1	t	1	\N	2	default		202611071705589927274558268d9d6SuSpU6f7	202611071705591953390058268d9d6dEBLLTxD	{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash-1017","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1003,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.4,"cache_tokens":2047,"completion_ratio":3.5,"frt":980,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"cbcn/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
13	1	1794071163	2		admin	cache-test	deepseek-v4.1-flash-1017	37	2122	8	2	t	1	\N	2	default		202611071706010448318138268d9d698ut6Hy2	202611071706012250925308268d9d6Rh4WnrZJ	{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash-1017","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2912,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.4,"cache_tokens":2047,"completion_ratio":3.5,"frt":2909,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"cbcn/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
15	1	1794072038	2	Model test	admin	Model test	gpt-6.1-sol	119	1504	13	2	f	3	\N	0	default		202611071720384120528588268d9d6Ekk7XnIw		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":3,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.1,"cache_tokens":0,"completion_ratio":6,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
16	1	1794072070	2		admin	cache-test	claude-opus-5-5	1	3	1	2	f	2	\N	2	default		202611071721085981986448268d9d6PDwNcFa1		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1909,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
17	1	1794072072	2		admin	cache-test	gpt-6.1-sol	29	1505	5	2	f	3	\N	2	default		202611071721105742503458268d9d6vmfBUr61		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":13,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":2261,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["3"]},"billing_source":"wallet","cache_ratio":0.1,"cache_tokens":1280,"completion_ratio":6,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
18	1	1794072074	2		admin	cache-test	cx/gpt-6-luna	37	2487	5	2	f	3	\N	2	default		202611071721128982229638268d9d6D0qbiFFs		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":1840,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["3"]},"billing_source":"wallet","cache_ratio":0.75,"cache_tokens":0,"completion_ratio":2,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.015,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"cx/gpt-6-luna","upstream_model":"cx/gpt-6-luna","returned_model":"gpt-6-luna"},"user_group_ratio":-1}
19	1	1794072077	2		admin	cache-test	claude-opus-5.5	10000	66	2	3	f	2	\N	2	default		202611071721148023370378268d9d6id2SWP29		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":2391,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":44,"completion_ratio":0,"frt":-1000,"group_ratio":1,"model_price":0.02,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
20	1	1794072078	2		admin	cache-test	claude-opus-4-8	4000	258	16	1	f	2	\N	2	default		202611071721172662817778268d9d6I0aPm9Zg	202611071721177131326658268d9d6ocMErMIz	{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1504,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"frt":-1000,"group_ratio":1,"input_tokens_total":258,"model_price":0.008,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
21	1	1794072147	2		admin	cache-test	claude-fable-5.1-req	10000	1	3	69	f	2	\N	2	default		202611071721188302126518268d9d61wr1ANLv		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":68544,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"frt":-1000,"group_ratio":1,"model_price":0.02,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
22	1	1794073032	2	Model test	admin	Model test	deepseek-v4.1-flash	3	31	16	3	f	1	\N	0	default		202611071737127033731248268d9d6DEKgev43		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":1,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
23	1	1794073036	2	Model test	admin	Model test	slow/agy/gemini-3.8-flash-medium	1000	647	92	3	f	4	\N	0	default		202611071737160971484678268d9d66pFAUnKN		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":4,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":0.002,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"slow/agy/gemini-3.8-flash-medium","upstream_model":"slow/agy/gemini-3.8-flash-medium","returned_model":"gemini-3.8-flash-medium"},"user_group_ratio":-1}
24	1	1794073047	2		admin	cache-test	cnb/deepseek-pro-v4	1500	69	16	1	f	1	\N	2	default		202611071737260132081718268d9d6fAdWKJ0Q		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1423,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"frt":-1000,"group_ratio":1,"model_price":0.003,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"cnb/deepseek-pro-v4","upstream_model":"cnb/deepseek-pro-v4","returned_model":"deepseek-pro-v4"},"user_group_ratio":-1}
25	1	1794073050	2		admin	cache-test	slow/agy/gemini-3.8-flash-medium	1000	647	9	3	f	4	\N	2	default		202611071737274971942198268d9d6k0Es3cxz		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":4,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":4,"group":"default","elapsed_ms":3470,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["4"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"frt":-1000,"group_ratio":1,"model_price":0.002,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"slow/agy/gemini-3.8-flash-medium","upstream_model":"slow/agy/gemini-3.8-flash-medium","returned_model":"gemini-3.8-flash-medium"},"user_group_ratio":-1}
26	1	1794073669	2		admin	cache-test	deepseek-v4.1-flash	4	32	16	3	f	1	\N	2	default		202611071747467838099638268d9d6yb6R7zak		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/responses","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2428,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Responses"],"request_path":"/v1/responses","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
27	1	1794075250	2		admin	harness2	deepseek-v4.1-flash	423	10776	85	3	t	1	\N	3	default		202611071814076791609858268d9d6dgtGwcUL		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2818,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":2298,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
28	1	1794075253	2		admin	harness2	deepseek-v4.1-flash	84	11317	288	3	t	1	\N	3	default		202611071814105934913948268d9d6B4ejFoC9		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3332,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10752,"completion_ratio":3.5,"frt":2388,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
309	1	1794139178	1	Administrator completed the order, amount added: ＄2.000000, payment amount: 2.000000	admin			0	0	0	0	f	0	\N	0		172.22.0.1	202611081159387947271868268d9d66aZ0gpDc		{"admin_info":{"callback_payment_method":"admin","caller_ip":"172.22.0.1","node_name":"dgai-node-1","payment_method":"vietqr","server_ip":"172.22.0.2","version":"v1.0.0-dgai"},"content_parts":[{"key":"Administrator completed the order, amount added: {{quota}}, payment amount: {{amount}}","params":{"amount":"2.000000","quota":"＄2.000000"}}]}
310	1	1794139185	1	Administrator completed the order, amount added: ＄3.000000, payment amount: 3.000000	admin			0	0	0	0	f	0	\N	0		172.22.0.1	202611081159459155646328268d9d6ehs7m0Ap		{"admin_info":{"callback_payment_method":"admin","caller_ip":"172.22.0.1","node_name":"dgai-node-1","payment_method":"vietqr","server_ip":"172.22.0.2","version":"v1.0.0-dgai"},"content_parts":[{"key":"Administrator completed the order, amount added: {{quota}}, payment amount: {{amount}}","params":{"amount":"3.000000","quota":"＄3.000000"}}]}
29	1	1794075265	2		admin	harness2	deepseek-v4.1-flash	381	16974	996	11	t	1	\N	3	default		202611071814145453404068268d9d6WG68bOB3		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11177,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":11520,"completion_ratio":3.5,"frt":4030,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
30	1	1794075269	2		admin	harness2	deepseek-v4.1-flash	73	18253	173	3	t	1	\N	3	default		202611071814261871023368268d9d6dCkEKjYI		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3256,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":17920,"completion_ratio":3.5,"frt":2731,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
31	1	1794075273	2		admin	harness2	deepseek-v4.1-flash	82	18838	171	3	t	1	\N	3	default		202611071814302629699768268d9d6al48nE85		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3251,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":18304,"completion_ratio":3.5,"frt":3048,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
32	1	1794075354	2		admin	harness2	deepseek-v4.1-flash	2088	22172	13723	80	t	1	\N	3	default		202611071814347341960778268d9d6fxuYOx2b		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":79748,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":18944,"completion_ratio":3.5,"frt":3298,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
33	1	1794075399	2		admin	harness2	deepseek-v4.1-flash	1440	36122	9692	45	t	1	\N	3	default		202611071815545083768528268d9d61XCmYYrt		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":44955,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":35840,"completion_ratio":3.5,"frt":4124,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
34	1	1794075557	2		admin	harness2	deepseek-v4.1-flash	1195	45830	7847	158	t	1	\N	3	default		202611071816395005730378268d9d63TnbAbvx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":157835,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45696,"completion_ratio":3.5,"frt":5094,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
35	1	1794075610	2		admin	harness2	deepseek-v4.1-flash	2984	53693	6389	53	t	1	\N	3	default		202611071819173696343598268d9d6hlh74ayk		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":53139,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":8144,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
36	1	1794075631	2		admin	harness2	deepseek-v4.1-flash	388	60097	1863	21	t	1	\N	3	default		202611071820105664065808268d9d6HSrJfKbx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":21425,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59904,"completion_ratio":3.5,"frt":20489,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
37	1	1794075638	2		admin	harness2	deepseek-v4.1-flash	162	61975	262	6	t	1	\N	3	default		202611071820320437686848268d9d6XAZgJ9Ar		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6782,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":61952,"completion_ratio":3.5,"frt":6188,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
38	1	1794075645	2		admin	harness2	deepseek-v4.1-flash	158	62463	98	7	t	1	\N	3	default		202611071820389393028138268d9d6J7RCjRDD		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6498,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":61952,"completion_ratio":3.5,"frt":6080,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
39	1	1794075652	2		admin	harness2	deepseek-v4.1-flash	412	68767	247	7	t	1	\N	3	default		202611071820456417734138268d9d6IPoOppZL		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6745,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":62464,"completion_ratio":3.5,"frt":5881,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
40	1	1794075657	2		admin	harness2	deepseek-v4.1-flash	194	69028	283	5	t	1	\N	3	default		202611071820524329150298268d9d61HqVERev		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4793,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":68608,"completion_ratio":3.5,"frt":3811,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
41	1	1794075662	2		admin	harness2	deepseek-v4.1-flash	231	69689	501	5	t	1	\N	3	default		202611071820572514919338268d9d6Izn95zUd		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5360,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":69120,"completion_ratio":3.5,"frt":4106,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
42	1	1794075669	2		admin	harness2	deepseek-v4.1-flash	229	70204	620	7	t	1	\N	3	default		202611071821026403618258268d9d6CVvnXXlW		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6610,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70144,"completion_ratio":3.5,"frt":4622,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
43	1	1794075673	2		admin	harness2	deepseek-v4.1-flash	172	70863	162	4	t	1	\N	3	default		202611071821093388727868268d9d6ONOw3HNG		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3894,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70656,"completion_ratio":3.5,"frt":2844,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
44	1	1794075678	2		admin	harness2	deepseek-v4.1-flash	210	71370	285	5	t	1	\N	3	default		202611071821132761605418268d9d6sl4Hiq1V		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5146,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70656,"completion_ratio":3.5,"frt":3516,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
45	1	1794075683	2		admin	harness2	deepseek-v4.1-flash	206	71669	309	5	t	1	\N	3	default		202611071821184578594188268d9d665vw4fxa		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4810,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":71168,"completion_ratio":3.5,"frt":4374,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
46	1	1794075691	2		admin	harness2	deepseek-v4.1-flash	268	72947	530	8	t	1	\N	3	default		202611071821232968232278268d9d6tOja9yWt		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8010,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":71680,"completion_ratio":3.5,"frt":6829,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
47	1	1794075698	2		admin	harness2	deepseek-v4.1-flash	270	74815	425	7	t	1	\N	3	default		202611071821313394764548268d9d64C23XKRU		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6869,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":73216,"completion_ratio":3.5,"frt":6549,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
48	1	1794075704	2		admin	harness2	deepseek-v4.1-flash	203	75253	236	6	t	1	\N	3	default		202611071821382381436918268d9d6dPGYElGs		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5905,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":74752,"completion_ratio":3.5,"frt":3702,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
49	1	1794075710	2		admin	harness2	deepseek-v4.1-flash	223	75503	446	6	t	1	\N	3	default		202611071821441852857098268d9d6dh5LTNgH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6617,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":75264,"completion_ratio":3.5,"frt":5593,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
50	1	1794075720	2		admin	harness2	deepseek-v4.1-flash	2370	59289	129	10	t	1	\N	3	default		202611071821508712333688268d9d6XN5qGaPP		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10010,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":9531,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
51	1	1794075734	2		admin	harness2	deepseek-v4.1-flash	305	76248	958	14	t	1	\N	3	default		202611071822009389767608268d9d6KwlvxraV		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13409,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":75776,"completion_ratio":3.5,"frt":10515,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
52	1	1794075750	2		admin	harness2	deepseek-v4.1-flash	209	60906	209	16	t	1	\N	3	default		202611071822143912475108268d9d67NOfJrMz		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15688,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59392,"completion_ratio":3.5,"frt":12834,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
53	1	1794075755	2		admin	harness2	deepseek-v4.1-flash	281	78871	319	5	t	1	\N	3	default		202611071822301192912848268d9d6qbGPliBT		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5878,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":76800,"completion_ratio":3.5,"frt":3537,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
54	1	1794075780	2		admin	harness2	deepseek-v4.1-flash	365	10384	54	2	t	1	\N	3	default		202611071822582967281188268d9d6CM0lemi7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2130,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":1903,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
55	1	1794075780	2		admin	harness2	deepseek-v4.1-flash	366	10384	62	2	t	1	\N	3	default		202611071822583004649138268d9d6uKLWSbqV		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2396,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2276,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
56	1	1794075780	2		admin	harness2	deepseek-v4.1-flash	35	580	82	2	t	1	\N	3	default		202611071822582739991268268d9d6MiP6MsKb		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2420,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":1784,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
57	1	1794075781	2		admin	harness2	deepseek-v4.1-flash	15	580	83	3	t	1	\N	3	default		202611071822582758226178268d9d6Ww47ypeH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2824,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":2194,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
58	1	1794075782	2		admin	harness2	deepseek-v4.1-flash	178	13879	88	2	t	1	\N	3	default		202611071823004745840948268d9d61pulHNFa		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2101,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10240,"completion_ratio":3.5,"frt":1882,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
59	1	1794075784	2		admin	harness2	deepseek-v4.1-flash	73	14554	116	2	t	1	\N	3	default		202611071823026937463418268d9d6L12z5vV6		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2047,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13824,"completion_ratio":3.5,"frt":1866,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
60	1	1794075787	2		admin	harness2	deepseek-v4.1-flash	557	14895	139	3	t	1	\N	3	default		202611071823047738207688268d9d66Oq4AJnu		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2569,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2127,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
61	1	1794075790	2		admin	harness2	deepseek-v4.1-flash	518	13882	151	10	t	1	\N	3	default		202611071823007427509498268d9d6lSFo6xSe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10141,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":9595,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
62	1	1794075791	2		admin	harness2	deepseek-v4.1-flash	79	15373	64	4	t	1	\N	3	default		202611071823073788453288268d9d6uQeYfLhb		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3638,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":14336,"completion_ratio":3.5,"frt":3319,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
63	1	1794075793	2		admin	harness2	deepseek-v4.1-flash	578	14954	272	2	t	1	\N	3	default		202611071823113707433268268d9d6TBndyADq		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2223,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":1312,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
64	1	1794075796	2		admin	harness2	deepseek-v4.1-flash	124	16361	242	3	t	1	\N	3	default		202611071823136841204448268d9d64V7vNFAS		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2528,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":14848,"completion_ratio":3.5,"frt":1495,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
65	1	1794075797	2		admin	harness2	deepseek-v4.1-flash	642	29691	271	6	t	1	\N	3	default		202611071823111847164998268d9d6ZF9FxJ0A		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6461,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":15360,"completion_ratio":3.5,"frt":6151,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
66	1	1794075798	2		admin	harness2	deepseek-v4.1-flash	791	20966	74	2	t	1	\N	3	default		202611071823163506164748268d9d6Qj5FxsVO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2029,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":1826,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
67	1	1794075800	2		admin	harness2	deepseek-v4.1-flash	230	33647	89	3	t	1	\N	3	default		202611071823177441438058268d9d62DoqYmSV		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2634,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":29696,"completion_ratio":3.5,"frt":2410,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
68	1	1794075801	2		admin	harness2	deepseek-v4.1-flash	874	37087	91	3	t	1	\N	3	default		202611071823184751636848268d9d6pB0zJdW7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3112,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":16384,"completion_ratio":3.5,"frt":2896,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
69	1	1794075805	2		admin	harness2	deepseek-v4.1-flash	1252	50266	279	4	t	1	\N	3	default		202611071823217105674098268d9d6JOvFl4XH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4098,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":20992,"completion_ratio":3.5,"frt":3539,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
70	1	1794075807	2		admin	harness2	deepseek-v4.1-flash	309	37961	394	7	t	1	\N	3	default		202611071823204060684178268d9d6au6V9zM4		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6700,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":33280,"completion_ratio":3.5,"frt":6458,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
71	1	1794075813	2		admin	harness2	deepseek-v4.1-flash	290	41850	400	6	t	1	\N	3	default		202611071823271552887038268d9d6HtDhRf4m		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6738,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":37888,"completion_ratio":3.5,"frt":6282,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
72	1	1794075829	2		admin	harness2	deepseek-v4.1-flash	1696	43575	116	16	t	1	\N	3	default		202611071823339201384918268d9d6ziFSFwip		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15208,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1664,"completion_ratio":3.5,"frt":13819,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
73	1	1794075834	2		admin	harness2	deepseek-v4.1-flash	241	45277	180	5	t	1	\N	3	default		202611071823491741909658268d9d6ZdMdS2vK		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5060,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":41984,"completion_ratio":3.5,"frt":4567,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
74	1	1794075841	2		admin	harness2	deepseek-v4.1-flash	2413	53649	2324	36	t	1	\N	3	default		202611071823258381592268268d9d6z2hoH9NI		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":35603,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":17627,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
75	1	1794075842	2		admin	harness2	deepseek-v4.1-flash	1818	45485	404	8	t	1	\N	3	default		202611071823542610314098268d9d6fZP3AOci		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7891,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":7255,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
76	1	1794075848	2		admin	harness2	deepseek-v4.1-flash	318	49150	458	6	t	1	\N	3	default		202611071824021858893648268d9d6xc7pBGyg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6720,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45056,"completion_ratio":3.5,"frt":4455,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
77	1	1794075855	2		admin	harness2	deepseek-v4.1-flash	302	49621	346	7	t	1	\N	3	default		202611071824089430584048268d9d6c7kIjtKC		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6296,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45568,"completion_ratio":3.5,"frt":6059,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
78	1	1794075865	2		admin	harness2	deepseek-v4.1-flash	200	50823	387	10	t	1	\N	3	default		202611071824152603734878268d9d68IlvkZV9		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9906,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49664,"completion_ratio":3.5,"frt":9439,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
79	1	1794075874	2		admin	harness2	deepseek-v4.1-flash	693	57618	2107	33	t	1	\N	3	default		202611071824014772555228268d9d6RfRv7wr8		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":33384,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":50176,"completion_ratio":3.5,"frt":10228,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
80	1	1794075882	2		admin	harness2	deepseek-v4.1-flash	273	51446	1148	17	t	1	\N	3	default		202611071824251924628848268d9d6ukSbsKlW		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":16963,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":51200,"completion_ratio":3.5,"frt":9842,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
81	1	1794075884	2		admin	harness2	deepseek-v4.1-flash	2241	56612	287	10	t	1	\N	3	default		202611071824348881476558268d9d6nF8FBEJa		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9595,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1664,"completion_ratio":3.5,"frt":8654,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
82	1	1794075890	2		admin	harness2	deepseek-v4.1-flash	407	50022	466	8	t	1	\N	3	default		202611071824421886580858268d9d6gK4BvhLy		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7929,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":43648,"completion_ratio":3.5,"frt":5764,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
83	1	1794075921	2		admin	harness2	deepseek-v4.1-flash	647	62674	2833	37	t	1	\N	3	default		202611071824445186004538268d9d6LojOw49M		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":36755,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59392,"completion_ratio":3.5,"frt":10053,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
84	1	1794075932	2		admin	harness2	deepseek-v4.1-flash	287	60770	113	11	t	1	\N	3	default		202611071825213068615138268d9d68w35NJpQ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11050,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":56832,"completion_ratio":3.5,"frt":9258,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
85	1	1794075941	2		admin	harness2	deepseek-v4.1-flash	143	60964	103	9	t	1	\N	3	default		202611071825323969705298268d9d6Tq1oFAhi		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9294,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":60800,"completion_ratio":3.5,"frt":8923,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
86	1	1794075965	2		admin	harness2	deepseek-v4.1-flash	354	61321	1583	24	t	1	\N	3	default		202611071825417238089378268d9d6ILoAwu6E		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":23337,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":61056,"completion_ratio":3.5,"frt":12725,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
87	1	1794075971	2		admin	harness2	deepseek-v4.1-flash	149	62944	101	6	t	1	\N	3	default		202611071826050922306118268d9d6JHgXgBEI		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6797,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":62720,"completion_ratio":3.5,"frt":6489,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
88	1	1794075992	2		admin	harness2	deepseek-v4.1-flash	512	63061	2699	21	t	1	\N	3	default		202611071826119279564518268d9d62TVfIeGS		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":20316,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":62848,"completion_ratio":3.5,"frt":5099,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
89	1	1794075999	2		admin	harness2	deepseek-v4.1-flash	261	65799	194	7	t	1	\N	3	default		202611071826322761479088268d9d6hzpxSTou		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7134,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63104,"completion_ratio":3.5,"frt":6293,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
90	1	1794076009	2		admin	harness2	deepseek-v4.1-flash	166	66008	187	10	t	1	\N	3	default		202611071826394464265188268d9d6t0QA6fcn		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9687,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":65792,"completion_ratio":3.5,"frt":8727,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
91	1	1794076018	2		admin	harness2	deepseek-v4.1-flash	165	66405	166	9	t	1	\N	3	default		202611071826491596034658268d9d6jtCV1bEk		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9610,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":66176,"completion_ratio":3.5,"frt":9091,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
92	1	1794076030	2		admin	harness2	deepseek-v4.1-flash	166	66605	187	12	t	1	\N	3	default		202611071826588667594278268d9d6BkH3i5xK		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11707,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":66432,"completion_ratio":3.5,"frt":10526,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
93	1	1794076043	2		admin	harness2	deepseek-v4.1-flash	175	66834	253	13	t	1	\N	3	default		202611071827106439799468268d9d6fwqqSz7k		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12897,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":66688,"completion_ratio":3.5,"frt":11781,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
94	1	1794076056	2		admin	harness2	deepseek-v4.1-flash	168	67102	198	13	t	1	\N	3	default		202611071827236017783178268d9d6ADZuNWkr		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12498,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":66944,"completion_ratio":3.5,"frt":11211,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
95	1	1794076066	2		admin	harness2	deepseek-v4.1-flash	171	67594	150	10	t	1	\N	3	default		202611071827361736987588268d9d6Wgd0bBAc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10250,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":67200,"completion_ratio":3.5,"frt":8699,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
96	1	1794076075	2		admin	harness2	deepseek-v4.1-flash	166	67766	168	9	t	1	\N	3	default		202611071827464778661918268d9d67w8atEPb		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8915,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":67584,"completion_ratio":3.5,"frt":8215,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
97	1	1794076088	2		admin	harness2	deepseek-v4.1-flash	153	67949	58	13	t	1	\N	3	default		202611071827554453359798268d9d6wun68jJ9		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12685,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":67712,"completion_ratio":3.5,"frt":12222,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
98	1	1794076097	2		admin	harness2	deepseek-v4.1-flash	164	68375	84	9	t	1	\N	3	default		202611071828081646771618268d9d6oJ8Le5j9		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9620,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":67968,"completion_ratio":3.5,"frt":9131,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
99	1	1794076122	2		admin	harness2	deepseek-v4.1-flash	423	68473	1975	25	t	1	\N	3	default		202611071828178350547448268d9d6G0immfWf		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":24274,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":68224,"completion_ratio":3.5,"frt":6559,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
100	1	1794076128	2		admin	harness2	deepseek-v4.1-flash	173	70464	174	6	t	1	\N	3	default		202611071828421470217198268d9d67SQxa3XJ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6557,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70272,"completion_ratio":3.5,"frt":5737,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
101	1	1794076139	2		admin	harness2	deepseek-v4.1-flash	334	70702	1329	11	t	1	\N	3	default		202611071828487651880448268d9d6dY91eUvq		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10370,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70528,"completion_ratio":3.5,"frt":5416,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
102	1	1794076161	2		admin	harness2	deepseek-v4.1-flash	455	12790	85	3	t	1	\N	3	default		202611071829182703002598268d9d6eWr0507z		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3005,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1792,"completion_ratio":3.5,"frt":2730,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
103	1	1794076166	2		admin	harness2	deepseek-v4.1-flash	58	13331	82	5	t	1	\N	3	default		202611071829213305960548268d9d64OeoAaOq		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4701,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":12800,"completion_ratio":3.5,"frt":4574,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
104	1	1794076172	2		admin	harness2	deepseek-v4.1-flash	80	13533	321	6	t	1	\N	3	default		202611071829260611522158268d9d6CGptL7OZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6353,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13312,"completion_ratio":3.5,"frt":3659,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
105	1	1794076175	2		admin	harness2	deepseek-v4.1-flash	384	10776	78	2	t	1	\N	3	default		202611071829333158031718268d9d6t2ywKBJ7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2065,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2023,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
106	1	1794076177	2		admin	harness2	deepseek-v4.1-flash	639	16225	347	5	t	1	\N	3	default		202611071829325498217638268d9d6d7YHxhf0		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5266,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2959,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
107	1	1794076177	2		admin	harness2	deepseek-v4.1-flash	95	11309	369	2	t	1	\N	3	default		202611071829354273940018268d9d6FL2xuIeg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2467,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10752,"completion_ratio":3.5,"frt":1174,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
108	1	1794076186	2		admin	harness2	deepseek-v4.1-flash	323	23135	147	9	t	1	\N	3	default		202611071829378424722518268d9d6ByAmJI7M		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9045,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":16384,"completion_ratio":3.5,"frt":8532,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
109	1	1794076193	2		admin	harness2	deepseek-v4.1-flash	438	17234	1261	16	t	1	\N	3	default		202611071829379230085288268d9d6SKUbfcTO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15610,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":11264,"completion_ratio":3.5,"frt":6917,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
110	1	1794076196	2		admin	harness2	deepseek-v4.1-flash	859	22592	99	2	t	1	\N	3	default		202611071829544294165708268d9d6sEqMUBTD		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2437,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2190,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
111	1	1794076201	2		admin	harness2	deepseek-v4.1-flash	92	23693	138	14	t	1	\N	3	default		202611071829477070451678268d9d6BuVF0njD		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13996,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":23040,"completion_ratio":3.5,"frt":13227,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
112	1	1794076244	2		admin	harness2	deepseek-v4.1-flash	884	26997	4992	42	t	1	\N	3	default		202611071830029169578728268d9d6lid0uhzN		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":41589,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":23552,"completion_ratio":3.5,"frt":5804,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
113	1	1794076271	2		admin	harness2	deepseek-v4.1-flash	2003	25841	7343	74	t	1	\N	3	default		202611071829573376407938268d9d6KfPlIgdU		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":74262,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":6174,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
114	1	1794076286	2		admin	harness2	deepseek-v4.1-flash	1130	32593	7374	42	t	1	\N	3	default		202611071830445771333908268d9d676hIywqv		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":41914,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":31744,"completion_ratio":3.5,"frt":1770,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
115	1	1794076331	2		admin	harness2	deepseek-v4.1-flash	766	39982	4885	45	t	1	\N	3	default		202611071831265201420038268d9d6KIPGifoW		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":45184,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":39936,"completion_ratio":3.5,"frt":9164,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
116	1	1794076341	2		admin	harness2	deepseek-v4.1-flash	1539	33287	7598	70	t	1	\N	3	default		202611071831116265471508268d9d6liezsrpD		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":69542,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":22528,"completion_ratio":3.5,"frt":6751,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
117	1	1794076366	2		admin	harness2	deepseek-v4.1-flash	587	44882	3462	35	t	1	\N	3	default		202611071832117354736158268d9d6812bV5Vj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":35038,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":44544,"completion_ratio":3.5,"frt":5114,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
118	1	1794076380	2		admin	harness2	deepseek-v4.1-flash	1801	42639	1168	14	t	1	\N	3	default		202611071832468062622468268d9d6cJiBpVCg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13496,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1792,"completion_ratio":3.5,"frt":7574,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
119	1	1794076394	2		admin	harness2	deepseek-v4.1-flash	160	43823	472	14	t	1	\N	3	default		202611071833003341184498268d9d6sM2sJPZe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13912,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":43648,"completion_ratio":3.5,"frt":11236,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
120	1	1794076396	2		admin	harness2	deepseek-v4.1-flash	1528	40900	10209	55	t	1	\N	3	default		202611071832212028353308268d9d6aomAlUjM		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":55411,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":40448,"completion_ratio":3.5,"frt":7029,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
121	1	1794076400	2		admin	harness2	deepseek-v4.1-flash	111	44310	122	6	t	1	\N	3	default		202611071833142910800258268d9d6iaO5PbBh		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6537,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":44160,"completion_ratio":3.5,"frt":6157,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
122	1	1794076413	2		admin	harness2	deepseek-v4.1-flash	214	50207	247	13	t	1	\N	3	default		202611071833209177678578268d9d6eLkaumuN		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12096,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":48128,"completion_ratio":3.5,"frt":11720,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
123	1	1794076420	2		admin	harness2	deepseek-v4.1-flash	133	44686	235	7	t	1	\N	3	default		202611071833330386183428268d9d6kcTEiZc2		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7050,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":44416,"completion_ratio":3.5,"frt":5985,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
124	1	1794076425	2		admin	harness2	deepseek-v4.1-flash	2207	41247	4465	29	t	1	\N	3	default		202611071833166413034718268d9d6yIMVU7JB		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":29020,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1792,"completion_ratio":3.5,"frt":5172,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
125	1	1794076426	2		admin	harness2	deepseek-v4.1-flash	137	45341	187	6	t	1	\N	3	default		202611071833402045495298268d9d6lzLHxM8L		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6449,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":44800,"completion_ratio":3.5,"frt":5160,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
126	1	1794076437	2		admin	harness2	deepseek-v4.1-flash	162	45700	433	11	t	1	\N	3	default		202611071833467131742518268d9d6YGsY2lJ4		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10355,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45440,"completion_ratio":3.5,"frt":7737,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
127	1	1794076450	2		admin	harness2	deepseek-v4.1-flash	602	55606	2173	25	t	1	\N	3	default		202611071833456967794968268d9d69DOtmv7i		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":24436,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":50688,"completion_ratio":3.5,"frt":10767,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
128	1	1794076476	2		admin	harness2	deepseek-v4.1-flash	428	57794	2106	26	t	1	\N	3	default		202611071834101623497598268d9d6c4iPCJ4Y		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":26779,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":57344,"completion_ratio":3.5,"frt":10968,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
129	1	1794076483	2		admin	harness2	deepseek-v4.1-flash	156	59963	103	7	t	1	\N	3	default		202611071834369707540098268d9d6V6gZyo5z		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6998,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59392,"completion_ratio":3.5,"frt":6153,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
130	1	1794076497	2		admin	harness2	deepseek-v4.1-flash	714	68440	1805	13	t	1	\N	3	default		202611071834440012563748268d9d6Y9y1moSf		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13079,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59904,"completion_ratio":3.5,"frt":3261,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
131	1	1794076503	2		admin	harness2	deepseek-v4.1-flash	609	58263	107	6	t	1	\N	3	default		202611071834571096145568268d9d6sYpvFaVY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6069,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45696,"completion_ratio":3.5,"frt":5734,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
132	1	1794076513	2		admin	harness2	deepseek-v4.1-flash	190	58918	367	10	t	1	\N	3	default		202611071835032213648328268d9d6907LFtsA		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10540,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":58368,"completion_ratio":3.5,"frt":9151,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
133	1	1794076520	2		admin	harness2	deepseek-v4.1-flash	141	59299	118	7	t	1	\N	3	default		202611071835138130128718268d9d65vuXi8jw		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6278,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59136,"completion_ratio":3.5,"frt":5750,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
134	1	1794076524	2		admin	harness2	deepseek-v4.1-flash	251	72301	171	4	t	1	\N	3	default		202611071835201365927558268d9d6PyYAewvY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4321,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":70144,"completion_ratio":3.5,"frt":4294,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
135	1	1794076530	2		admin	harness2	deepseek-v4.1-flash	174	72564	102	6	t	1	\N	3	default		202611071835245204993648268d9d6jZOYtjb2		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6045,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":72192,"completion_ratio":3.5,"frt":5295,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
136	1	1794076541	2		admin	harness2	deepseek-v4.1-flash	189	72688	174	11	t	1	\N	3	default		202611071835305950561518268d9d61BL7HACx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10905,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":72192,"completion_ratio":3.5,"frt":10267,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
137	1	1794076550	2		admin	harness2	deepseek-v4.1-flash	203	72876	363	9	t	1	\N	3	default		202611071835415454658558268d9d6tYmzDvu7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8860,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":72704,"completion_ratio":3.5,"frt":7449,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
138	1	1794076556	2		admin	harness2	deepseek-v4.1-flash	183	73253	250	6	t	1	\N	3	default		202611071835504363395968268d9d6hs3fUG6j		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5626,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":73216,"completion_ratio":3.5,"frt":4927,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
139	1	1794076561	2		admin	harness2	deepseek-v4.1-flash	193	73711	190	5	t	1	\N	3	default		202611071835560901809398268d9d6ErJ9QKPg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5383,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":73216,"completion_ratio":3.5,"frt":4769,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
140	1	1794076578	2		admin	harness2	deepseek-v4.1-flash	386	73994	1627	17	t	1	\N	3	default		202611071836015282945198268d9d6oVVOJ7Z7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":17380,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":73728,"completion_ratio":3.5,"frt":10243,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
141	1	1794076583	2		admin	harness2	deepseek-v4.1-flash	186	75634	150	5	t	1	\N	3	default		202611071836189758143208268d9d6EbIQaTr2		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4790,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":75264,"completion_ratio":3.5,"frt":4177,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
142	1	1794076592	2		admin	harness2	deepseek-v4.1-flash	211	76158	317	9	t	1	\N	3	default		202611071836237969911868268d9d6XJs4oLIo		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8774,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":75776,"completion_ratio":3.5,"frt":6269,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
143	1	1794076601	2		admin	harness2	deepseek-v4.1-flash	234	76489	524	9	t	1	\N	3	default		202611071836325978876248268d9d6p90c57nd		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9214,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":76288,"completion_ratio":3.5,"frt":8467,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
144	1	1794076616	2		admin	harness2	deepseek-v4.1-flash	191	77066	188	15	t	1	\N	3	default		202611071836418397441938268d9d6qU2L8xSy		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":14344,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":76800,"completion_ratio":3.5,"frt":13826,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
145	1	1794076629	2		admin	harness2	deepseek-v4.1-flash	370	77268	1409	13	t	1	\N	3	default		202611071836562112392198268d9d6iIWYFfyC		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13014,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":76800,"completion_ratio":3.5,"frt":6519,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
146	1	1794076635	2		admin	harness2	deepseek-v4.1-flash	209	78693	271	6	t	1	\N	3	default		202611071837093012459298268d9d66Qc4mVKj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5779,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":78336,"completion_ratio":3.5,"frt":4769,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
147	1	1794076643	2		admin	harness2	deepseek-v4.1-flash	200	78977	262	8	t	1	\N	3	default		202611071837151261742088268d9d6huBK15IQ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8544,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":78848,"completion_ratio":3.5,"frt":8058,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
148	1	1794076650	2		admin	harness2	deepseek-v4.1-flash	284	80800	343	7	t	1	\N	3	default		202611071837236990110788268d9d6iSuJ23yr		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6432,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":78848,"completion_ratio":3.5,"frt":6146,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
149	1	1794076658	2		admin	harness2	deepseek-v4.1-flash	295	81269	848	8	t	1	\N	3	default		202611071837301569182688268d9d6AVX9vXaA		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8832,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":80896,"completion_ratio":3.5,"frt":7099,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
150	1	1794076664	2		admin	harness2	deepseek-v4.1-flash	218	82186	308	5	t	1	\N	3	default		202611071837390268585588268d9d6xAHk5B8k		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5182,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":81920,"completion_ratio":3.5,"frt":3790,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
151	1	1794076671	2		admin	harness2	deepseek-v4.1-flash	206	82508	271	7	t	1	\N	3	default		202611071837442438520318268d9d6ztdCWw33		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7290,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":82432,"completion_ratio":3.5,"frt":6568,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
152	1	1794076677	2		admin	harness2	deepseek-v4.1-flash	233	82792	382	6	t	1	\N	3	default		202611071837515662721238268d9d6m9KDQSwW		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5796,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":82432,"completion_ratio":3.5,"frt":5341,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
153	1	1794076681	2		admin	harness2	deepseek-v4.1-flash	196	83236	132	4	t	1	\N	3	default		202611071837573998584768268d9d6aNGmdaK7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3964,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":82944,"completion_ratio":3.5,"frt":3450,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
154	1	1794076690	2		admin	harness2	deepseek-v4.1-flash	284	83382	720	9	t	1	\N	3	default		202611071838013974552678268d9d63fxM0mrJ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9017,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":82944,"completion_ratio":3.5,"frt":7999,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
155	1	1794076697	2		admin	harness2	deepseek-v4.1-flash	200	84135	181	7	t	1	\N	3	default		202611071838104435695188268d9d6a7JZXBUd		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7130,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":83968,"completion_ratio":3.5,"frt":5880,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
156	1	1794076701	2		admin	harness2	deepseek-v4.1-flash	211	84330	201	4	t	1	\N	3	default		202611071838176101887048268d9d6uYZTyXAN		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4122,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":83968,"completion_ratio":3.5,"frt":3720,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
157	1	1794076716	2		admin	harness2	deepseek-v4.1-flash	339	84656	1162	15	t	1	\N	3	default		202611071838217649268418268d9d6WmsKaruH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":14634,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":84480,"completion_ratio":3.5,"frt":9785,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
158	1	1794076726	2		admin	harness2	deepseek-v4.1-flash	436	91049	311	10	t	1	\N	3	default		202611071838364395043618268d9d6hO68VgM6		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10096,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":85504,"completion_ratio":3.5,"frt":9592,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
159	1	1794076735	2		admin	harness2	deepseek-v4.1-flash	578	99532	429	9	t	1	\N	3	default		202611071838465720840768268d9d697LCuqzw		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8735,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":91136,"completion_ratio":3.5,"frt":7016,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
160	1	1794076743	2		admin	harness2	deepseek-v4.1-flash	221	99975	111	8	t	1	\N	3	default		202611071838553449564288268d9d6jwW9uPMl		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7982,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":99840,"completion_ratio":3.5,"frt":7718,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
161	1	1794076755	2		admin	harness2	deepseek-v4.1-flash	398	102553	638	12	t	1	\N	3	default		202611071839033659317008268d9d6anN2mZC5		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12608,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":99840,"completion_ratio":3.5,"frt":9819,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
162	1	1794076762	2		admin	harness2	deepseek-v4.1-flash	286	103205	487	6	t	1	\N	3	default		202611071839160120327288268d9d6hseiVDZr		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6803,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":102912,"completion_ratio":3.5,"frt":5017,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
163	1	1794076769	2		admin	harness2	deepseek-v4.1-flash	250	103706	230	7	t	1	\N	3	default		202611071839228499509138268d9d6D5wgDKZp		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6755,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":103424,"completion_ratio":3.5,"frt":5823,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
164	1	1794076778	2		admin	harness2	deepseek-v4.1-flash	362	104147	904	9	t	1	\N	3	default		202611071839296355334378268d9d6kPft4Ms6		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8803,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":103424,"completion_ratio":3.5,"frt":6762,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
165	1	1794076790	2		admin	harness2	deepseek-v4.1-flash	293	105356	481	12	t	1	\N	3	default		202611071839384653147768268d9d6ibm268kc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11537,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":104960,"completion_ratio":3.5,"frt":9943,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
166	1	1794076812	2		admin	harness2	deepseek-v4.1-flash	366	10385	62	2	t	1	\N	3	default		202611071840103523188818268d9d6eBO94h6E		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2635,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2337,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
167	1	1794076815	5	status_code=503, Service is temporarily unavailable or overloaded.	admin	harness2	deepseek-v4.1-flash	0	0	0	4	t	1	\N	3	default		202611071840103325586858268d9d6Ymvc40VP		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":503,"error_code":"SERVICE_UNAVAILABLE","error_source":"upstream","elapsed_ms":4817,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":503,"error_code":"SERVICE_UNAVAILABLE","error_source":"upstream","elapsed_ms":4817,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"SERVICE_UNAVAILABLE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":503}
168	1	1794076820	2		admin	harness2	deepseek-v4.1-flash	491	13391	98	7	t	1	\N	3	default		202611071840130324723338268d9d67WJL2B0l		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6992,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":6785,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
169	1	1794076824	2		admin	harness2	deepseek-v4.1-flash	186	14009	108	4	t	1	\N	3	default		202611071840201480888748268d9d61BCaFDY4		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4128,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10240,"completion_ratio":3.5,"frt":3765,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
170	1	1794076828	2		admin	harness2	deepseek-v4.1-flash	105	14987	220	4	t	1	\N	3	default		202611071840243025546478268d9d6Mw2q10hi		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3942,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13824,"completion_ratio":3.5,"frt":2586,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
171	1	1794076830	5	status_code=502, Upstream service is temporarily having issues.	admin	harness2	deepseek-v4.1-flash	0	0	0	12	t	1	\N	3	default		202611071840171635601048268d9d6ZASbjAfg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":12982,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":12982,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"UPSTREAM_BAD_RESPONSE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":502}
172	1	1794076836	2		admin	harness2	deepseek-v4.1-flash	17	580	98	2	t	1	\N	3	default		202611071840341571691638268d9d676bX9kgc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1845,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":1173,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
173	1	1794076841	2		admin	harness2	deepseek-v4.1-flash	590	15587	215	13	t	1	\N	3	default		202611071840282706210298268d9d6HlLr1r7P		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13113,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1664,"completion_ratio":3.5,"frt":12454,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
174	1	1794076849	2		admin	harness2	deepseek-v4.1-flash	352	23226	152	8	t	1	\N	3	default		202611071840414162820218268d9d64gYuup4T		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8390,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":15744,"completion_ratio":3.5,"frt":7522,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
175	1	1794076856	2		admin	harness2	deepseek-v4.1-flash	102	24133	156	7	t	1	\N	3	default		202611071840498551360418268d9d61TekS20T		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6288,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":23296,"completion_ratio":3.5,"frt":5952,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
176	1	1794076862	2		admin	harness2	deepseek-v4.1-flash	117	25514	113	6	t	1	\N	3	default		202611071840561762403028268d9d61Okk8NUh		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6788,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":24192,"completion_ratio":3.5,"frt":6400,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
177	1	1794076870	2		admin	harness2	deepseek-v4.1-flash	87	25999	144	8	t	1	\N	3	default		202611071841029971192908268d9d67h0JV60j		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7884,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":25600,"completion_ratio":3.5,"frt":7804,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
178	1	1794076876	2		admin	harness2	deepseek-v4.1-flash	102	26891	133	6	t	1	\N	3	default		202611071841109177057548268d9d6CeyN0agK		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5106,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":26112,"completion_ratio":3.5,"frt":4608,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
179	1	1794076889	2		admin	harness2	deepseek-v4.1-flash	93	27038	232	13	t	1	\N	3	default		202611071841160594500948268d9d6lcNepRtD		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13178,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":26880,"completion_ratio":3.5,"frt":11824,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
180	1	1794076900	2		admin	harness2	deepseek-v4.1-flash	86	27567	141	11	t	1	\N	3	default		202611071841293004817408268d9d6dY8I14kJ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11426,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":27264,"completion_ratio":3.5,"frt":11162,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
181	1	1794076910	2		admin	harness2	deepseek-v4.1-flash	90	28061	132	10	t	1	\N	3	default		202611071841407650305408268d9d6rFzaENKP		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10036,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":27648,"completion_ratio":3.5,"frt":9514,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
182	1	1794076919	2		admin	harness2	deepseek-v4.1-flash	157	30216	132	9	t	1	\N	3	default		202611071841508311060838268d9d6M6Kwchoy		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8618,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":28160,"completion_ratio":3.5,"frt":8150,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
183	1	1794076925	2		admin	harness2	deepseek-v4.1-flash	104	31097	90	6	t	1	\N	3	default		202611071841594821546848268d9d6bjBAyMDo		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6204,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":30336,"completion_ratio":3.5,"frt":6179,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
184	1	1794076934	2		admin	harness2	deepseek-v4.1-flash	116	32046	115	9	t	1	\N	3	default		202611071842057151885948268d9d6TFgl4sTj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8545,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":31104,"completion_ratio":3.5,"frt":7954,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
185	1	1794076945	2		admin	harness2	deepseek-v4.1-flash	85	32321	92	11	t	1	\N	3	default		202611071842142924299318268d9d6KSSFkDQA		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11336,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":32128,"completion_ratio":3.5,"frt":10377,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
186	1	1794076958	5	status_code=502, Upstream service is temporarily having issues.	admin	harness2	deepseek-v4.1-flash	0	0	0	12	t	1	\N	3	default		202611071842256853276258268d9d6nrfWM9tf		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":12840,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":12840,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"UPSTREAM_BAD_RESPONSE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":502}
187	1	1794076971	5	status_code=502, Upstream service is temporarily having issues.	admin	harness2	deepseek-v4.1-flash	0	0	0	11	t	1	\N	3	default		202611071842405433128178268d9d6JtD2Onel		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":11080,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":11080,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"UPSTREAM_BAD_RESPONSE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":502}
188	1	1794076979	2		admin	harness2	deepseek-v4.1-flash	853	34748	193	4	t	1	\N	3	default		202611071842556371037348268d9d6tbwNRvMO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4162,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":14848,"completion_ratio":3.5,"frt":3790,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
189	1	1794076983	2		admin	harness2	deepseek-v4.1-flash	102	35298	93	4	t	1	\N	3	default		202611071842598304193148268d9d6cgVyRIfz		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3574,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":34816,"completion_ratio":3.5,"frt":3160,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
190	1	1794076992	2		admin	harness2	deepseek-v4.1-flash	1509	36632	728	9	t	1	\N	3	default		202611071843034329084738268d9d6edDbC0Iz		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8818,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":7770,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
191	1	1794076996	2		admin	harness2	deepseek-v4.1-flash	271	41293	141	4	t	1	\N	3	default		202611071843122781323988268d9d6LZdcHJCR		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4000,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":36864,"completion_ratio":3.5,"frt":3390,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
192	1	1794077001	2		admin	harness2	deepseek-v4.1-flash	177	42948	113	5	t	1	\N	3	default		202611071843163038724228268d9d6ZsdoZHSe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5575,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":40960,"completion_ratio":3.5,"frt":5406,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
193	1	1794077012	2		admin	harness2	deepseek-v4.1-flash	444	44145	148	11	t	1	\N	3	default		202611071843219039368228268d9d6sRto9a0A		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10111,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":35328,"completion_ratio":3.5,"frt":9868,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
194	1	1794077021	2		admin	harness2	deepseek-v4.1-flash	327	46298	778	9	t	1	\N	3	default		202611071843320448218878268d9d6r6j3f1eH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9172,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":43008,"completion_ratio":3.5,"frt":6077,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
195	1	1794077029	2		admin	harness2	deepseek-v4.1-flash	163	47324	293	8	t	1	\N	3	default		202611071843412853435038268d9d6WzVhN3m2		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8302,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":46592,"completion_ratio":3.5,"frt":6489,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
196	1	1794077035	2		admin	harness2	deepseek-v4.1-flash	164	47721	460	6	t	1	\N	3	default		202611071843496575917328268d9d6Xz3ytYIT		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5799,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":47616,"completion_ratio":3.5,"frt":5246,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
197	1	1794077039	2		admin	harness2	deepseek-v4.1-flash	138	48331	242	4	t	1	\N	3	default		202611071843555142174068268d9d6og0skQdj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3991,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":48128,"completion_ratio":3.5,"frt":2669,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
198	1	1794077044	2		admin	harness2	deepseek-v4.1-flash	350	48902	481	5	t	1	\N	3	default		202611071843595295662318268d9d6xfhi92DY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5250,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":44032,"completion_ratio":3.5,"frt":3252,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
199	1	1794077053	5	status_code=502, Upstream service is temporarily having issues.	admin	harness2	deepseek-v4.1-flash	0	0	0	8	t	1	\N	3	default		202611071844048365066068268d9d60dyi42ZK		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":8755,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":8755,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"UPSTREAM_BAD_RESPONSE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":502}
200	1	1794077061	2		admin	harness2	deepseek-v4.1-flash	144	49412	252	6	t	1	\N	3	default		202611071844156075545678268d9d6CaILYEqS		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5719,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49152,"completion_ratio":3.5,"frt":5323,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
201	1	1794077072	2		admin	harness2	deepseek-v4.1-flash	352	50514	1148	11	t	1	\N	3	default		202611071844213916815898268d9d6gZMpxWVe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11152,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":48128,"completion_ratio":3.5,"frt":7652,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
202	1	1794077078	2		admin	harness2	deepseek-v4.1-flash	761	49387	118	6	t	1	\N	3	default		202611071844325759265958268d9d65LjouTTp		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6197,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":32384,"completion_ratio":3.5,"frt":5780,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
203	1	1794077087	2		admin	harness2	deepseek-v4.1-flash	127	49654	133	9	t	1	\N	3	default		202611071844388088071368268d9d6jYKA3PiZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9190,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49408,"completion_ratio":3.5,"frt":8641,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
204	1	1794077094	5	status_code=502, Upstream service is temporarily having issues.	admin	harness2	deepseek-v4.1-flash	0	0	0	6	t	1	\N	3	default		202611071844480428946748268d9d66prih9rd		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":6424,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":502,"error_code":"UPSTREAM_BAD_RESPONSE","error_source":"upstream","elapsed_ms":6424,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"UPSTREAM_BAD_RESPONSE","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":502}
205	1	1794077105	2		admin	harness2	deepseek-v4.1-flash	168	51062	91	9	t	1	\N	3	default		202611071844564831981678268d9d6PuGPLSpo		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9275,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49664,"completion_ratio":3.5,"frt":8943,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
206	1	1794077113	2		admin	harness2	deepseek-v4.1-flash	158	52088	110	8	t	1	\N	3	default		202611071845058016728398268d9d6suLQ0O2c		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7412,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":51072,"completion_ratio":3.5,"frt":7035,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
207	1	1794077129	2		admin	harness2	deepseek-v4.1-flash	2271	56725	11	16	t	1	\N	3	default		202611071845132556141038268d9d6rBZeMceZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"local_count_tokens":true,"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":16293,"decision":{"action":"stop","reason":"stream_not_successful","source":"system"}}],"usage_billing_path":"local","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":15345,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_error":"context canceled","end_reason":"client_gone","status":"error"},"user_group_ratio":-1}
208	1	1794077232	2		admin	harness2	deepseek-v4.1-flash	355	10382	59	3	t	1	\N	3	default		202611071847099093049058268d9d6SRmhzhrS		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2521,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1792,"completion_ratio":3.5,"frt":2337,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
209	1	1794077232	2		admin	harness2	deepseek-v4.1-flash	37	580	239	3	t	1	\N	3	default		202611071847098893453228268d9d60V8cAAKU		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2993,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":1289,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
210	1	1794077235	2		admin	harness2	deepseek-v4.1-flash	159	13383	127	3	t	1	\N	3	default		202611071847124819420298268d9d6HQlfQ4ZZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3010,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10368,"completion_ratio":3.5,"frt":2701,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
211	1	1794077238	2		admin	harness2	deepseek-v4.1-flash	99	14309	267	3	t	1	\N	3	default		202611071847155253356718268d9d6iqiv8zrY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2906,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13440,"completion_ratio":3.5,"frt":2152,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
212	1	1794077241	2		admin	harness2	deepseek-v4.1-flash	167	16741	339	3	t	1	\N	3	default		202611071847184619595218268d9d6EVdNMVYm		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2960,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":14464,"completion_ratio":3.5,"frt":2005,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
213	1	1794077244	2		admin	harness2	deepseek-v4.1-flash	391	24732	348	3	t	1	\N	3	default		202611071847214506264688268d9d6SnUZ9dIg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3513,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":17024,"completion_ratio":3.5,"frt":2988,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
214	1	1794077254	2		admin	harness2	deepseek-v4.1-flash	120	25610	317	9	t	1	\N	3	default		202611071847250142901998268d9d6HBOY1rYc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9924,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":24960,"completion_ratio":3.5,"frt":8610,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
215	1	1794077258	2		admin	harness2	deepseek-v4.1-flash	136	26817	331	4	t	1	\N	3	default		202611071847349794326518268d9d62WwOYN4C		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3756,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":25856,"completion_ratio":3.5,"frt":2694,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
216	1	1794077268	2		admin	harness2	deepseek-v4.1-flash	228	30037	410	10	t	1	\N	3	default		202611071847387736288778268d9d6GVu7RYtg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9604,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":27136,"completion_ratio":3.5,"frt":8763,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
217	1	1794077274	2		admin	harness2	deepseek-v4.1-flash	308	35148	391	6	t	1	\N	3	default		202611071847484147988718268d9d6UFJzzba0		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5687,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":30336,"completion_ratio":3.5,"frt":5058,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
218	1	1794077281	2		admin	harness2	deepseek-v4.1-flash	620	45811	967	7	t	1	\N	3	default		202611071847541417331968268d9d6W3v54Ku9		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7682,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":35456,"completion_ratio":3.5,"frt":4195,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
219	1	1794077287	2		admin	harness2	deepseek-v4.1-flash	211	46930	778	6	t	1	\N	3	default		202611071848018861272318268d9d6bZpnGmtc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5994,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":46720,"completion_ratio":3.5,"frt":3204,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
220	1	1794077293	2		admin	harness2	deepseek-v4.1-flash	217	49301	390	6	t	1	\N	3	default		202611071848079338036558268d9d6agUIRBvy		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5232,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":47616,"completion_ratio":3.5,"frt":4465,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
221	1	1794077299	2		admin	harness2	deepseek-v4.1-flash	338	54769	247	6	t	1	\N	3	default		202611071848131997769498268d9d6Y1a2OIru		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5912,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49664,"completion_ratio":3.5,"frt":5660,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
222	1	1794077303	2		admin	harness2	deepseek-v4.1-flash	340	60307	102	4	t	1	\N	3	default		202611071848191455738958268d9d6YFeaeZyq		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4009,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":54912,"completion_ratio":3.5,"frt":3776,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
223	1	1794077306	2		admin	harness2	deepseek-v4.1-flash	373	66275	91	3	t	1	\N	3	default		202611071848231905544578268d9d6FnxwnleY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3329,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":60288,"completion_ratio":3.5,"frt":3057,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
224	1	1794077317	2		admin	harness2	deepseek-v4.1-flash	433	70734	882	11	t	1	\N	3	default		202611071848265487976298268d9d68qw0Y98V		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11042,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":66304,"completion_ratio":3.5,"frt":4556,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
225	1	1794077328	2		admin	harness2	deepseek-v4.1-flash	247	72028	603	11	t	1	\N	3	default		202611071848376327391028268d9d6WgV7OFBk		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10708,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":71552,"completion_ratio":3.5,"frt":8181,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
226	1	1794077344	2		admin	harness2	deepseek-v4.1-flash	486	75108	1711	16	t	1	\N	3	default		202611071848483771338418268d9d6BO3jvzYp		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15793,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":72576,"completion_ratio":3.5,"frt":5707,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
227	1	1794077368	2		admin	harness2	deepseek-v4.1-flash	723	80749	2940	24	t	1	\N	3	default		202611071849042069797108268d9d6wYxSllTv		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":24714,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":76800,"completion_ratio":3.5,"frt":6408,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
228	1	1794077398	2		admin	harness2	deepseek-v4.1-flash	880	88577	3665	30	t	1	\N	3	default		202611071849289796061998268d9d6yENfYGG7		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":29338,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":83584,"completion_ratio":3.5,"frt":6642,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
229	1	1794077414	2		admin	harness2	deepseek-v4.1-flash	534	94337	1876	16	t	1	\N	3	default		202611071849583554926268268d9d6CR86K5ZE		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15655,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":92160,"completion_ratio":3.5,"frt":6205,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
230	1	1794077427	2		admin	harness2	deepseek-v4.1-flash	535	99089	1604	13	t	1	\N	3	default		202611071850140441700748268d9d68L3tA0zV		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13026,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":96128,"completion_ratio":3.5,"frt":5361,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
231	1	1794077446	2		admin	harness2	deepseek-v4.1-flash	4385	100733	2959	19	t	1	\N	3	default		202611071850271010685128268d9d696NEApXF		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":19122,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":8557,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
232	1	1794077451	2		admin	harness2	deepseek-v4.1-flash	281	103731	440	5	t	1	\N	3	default		202611071850462546134938268d9d6uRVCIWK6		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5672,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":103424,"completion_ratio":3.5,"frt":5030,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
233	1	1794077472	2		admin	harness2	deepseek-v4.1-flash	520	104359	2110	21	t	1	\N	3	default		202611071850519833192968268d9d61I3EqzpB		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":20471,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":103936,"completion_ratio":3.5,"frt":7428,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
234	1	1794077485	2		admin	harness2	deepseek-v4.1-flash	399	106602	1159	13	t	1	\N	3	default		202611071851124868176968268d9d6iwPQLC01		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12528,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":105984,"completion_ratio":3.5,"frt":10042,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
235	1	1794077494	2		admin	harness2	deepseek-v4.1-flash	344	107815	839	9	t	1	\N	3	default		202611071851250483179278268d9d65BSfBJIT		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9565,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":107520,"completion_ratio":3.5,"frt":4615,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
236	1	1794077502	2		admin	harness2	deepseek-v4.1-flash	232	108669	74	8	t	1	\N	3	default		202611071851346436875908268d9d6IZjrfhKX		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7400,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":108544,"completion_ratio":3.5,"frt":7288,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
237	1	1794077512	2		admin	harness2	deepseek-v4.1-flash	370	109579	800	10	t	1	\N	3	default		202611071851420770417738268d9d6nYTQsBWI		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10612,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":108544,"completion_ratio":3.5,"frt":7052,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
238	1	1794077536	2		admin	harness2	deepseek-v4.1-flash	433	12023	78	2	t	1	\N	3	default		202611071852147737595608268d9d6Xij4g9Yr		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1836,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":1217,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
239	1	1794077539	2		admin	harness2	deepseek-v4.1-flash	83	12556	199	3	t	1	\N	3	default		202611071852169750958818268d9d6nl6VHkva		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2140,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":11776,"completion_ratio":3.5,"frt":1412,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
240	1	1794077543	2		admin	harness2	deepseek-v4.1-flash	536	13223	465	4	t	1	\N	3	default		202611071852192272072748268d9d6lUKyRvvX		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4360,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2660,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
241	1	1794077547	2		admin	harness2	deepseek-v4.1-flash	375	21580	129	4	t	1	\N	3	default		202611071852236130173198268d9d6z2DnDrTj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3456,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13312,"completion_ratio":3.5,"frt":2860,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
242	1	1794077549	2		admin	harness2	deepseek-v4.1-flash	852	22342	119	2	t	1	\N	3	default		202611071852270949693658268d9d6uuREs0Xu		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1946,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":1631,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
243	1	1794077552	2		admin	harness2	deepseek-v4.1-flash	117	22872	137	3	t	1	\N	3	default		202611071852299514155598268d9d6lQJ2J0kg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2582,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":21504,"completion_ratio":3.5,"frt":1918,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
244	1	1794077586	2		admin	harness2	deepseek-v4.1-flash	518	26175	2196	33	t	1	\N	3	default		202611071852337703651268268d9d6ja9VXHDt		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":32905,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":22016,"completion_ratio":3.5,"frt":9374,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
245	1	1794077641	2		admin	harness2	deepseek-v4.1-flash	2188	28593	7873	55	t	1	\N	3	default		202611071853067053412148268d9d65lVXEthH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":54858,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2816,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
246	1	1794077648	2		admin	harness2	deepseek-v4.1-flash	1419	36481	129	7	t	1	\N	3	default		202611071854015939591088268d9d6Yiv4dT0F		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7082,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":6608,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
247	1	1794077699	2		admin	harness2	deepseek-v4.1-flash	736	36640	4655	51	t	1	\N	3	default		202611071854087594354448268d9d6nNaCRWAF		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":50621,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":36352,"completion_ratio":3.5,"frt":9447,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
248	1	1794077738	2		admin	harness2	deepseek-v4.1-flash	676	41310	4143	39	t	1	\N	3	default		202611071854594107344588268d9d60yCXZNEg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":39340,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":40960,"completion_ratio":3.5,"frt":6120,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
249	1	1794077763	2		admin	harness2	deepseek-v4.1-flash	413	45468	2191	25	t	1	\N	3	default		202611071855387835395888268d9d6lQ7SiPRZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":24237,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45056,"completion_ratio":3.5,"frt":9513,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
250	1	1794077767	2		admin	harness2	deepseek-v4.1-flash	561	47674	256	4	t	1	\N	3	default		202611071856030522072318268d9d6suxZvZSo		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4902,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":36352,"completion_ratio":3.5,"frt":3487,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
251	1	1794077780	2		admin	harness2	deepseek-v4.1-flash	991	48822	776	12	t	1	\N	3	default		202611071856080196990718268d9d6y7XVBiM8		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11997,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":28160,"completion_ratio":3.5,"frt":9547,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
252	1	1794077785	2		admin	harness2	deepseek-v4.1-flash	215	49612	284	5	t	1	\N	3	default		202611071856200961933448268d9d6lle671jb		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5818,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":47616,"completion_ratio":3.5,"frt":3642,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
253	1	1794077798	2		admin	harness2	deepseek-v4.1-flash	2114	50675	1038	12	t	1	\N	3	default		202611071856260080266868268d9d6v6VKCtUw		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12644,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":8393,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
254	1	1794077806	2		admin	harness2	deepseek-v4.1-flash	2040	51726	213	8	t	1	\N	3	default		202611071856387367607688268d9d6DjehY1Od		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7569,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":7546,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
255	1	1794077811	2		admin	harness2	deepseek-v4.1-flash	258	52149	284	5	t	1	\N	3	default		202611071856464024549878268d9d6nMpX5842		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4664,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49152,"completion_ratio":3.5,"frt":3638,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
256	1	1794077822	2		admin	harness2	deepseek-v4.1-flash	268	52564	374	11	t	1	\N	3	default		202611071856511360239398268d9d6Fd2XUvm0		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11662,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49664,"completion_ratio":3.5,"frt":9204,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
257	1	1794077829	2		admin	harness2	deepseek-v4.1-flash	293	54940	433	7	t	1	\N	3	default		202611071857028273109468268d9d6u6p0ROZQ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6804,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":51712,"completion_ratio":3.5,"frt":6311,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
258	1	1794077837	2		admin	harness2	deepseek-v4.1-flash	249	55532	226	8	t	1	\N	3	default		202611071857096572644088268d9d66TOWSuyR		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7569,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":52736,"completion_ratio":3.5,"frt":5325,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
259	1	1794077842	2		admin	harness2	deepseek-v4.1-flash	170	55771	286	5	t	1	\N	3	default		202611071857173138569658268d9d6xBRZ1Rt3		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5516,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":55296,"completion_ratio":3.5,"frt":4140,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
260	1	1794077847	2		admin	harness2	deepseek-v4.1-flash	179	56284	207	5	t	1	\N	3	default		202611071857229163854938268d9d6mYjz6UtT		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4405,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":55296,"completion_ratio":3.5,"frt":3411,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
261	1	1794077853	2		admin	harness2	deepseek-v4.1-flash	185	56711	267	6	t	1	\N	3	default		202611071857273485006758268d9d6a24lShbQ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6147,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":55808,"completion_ratio":3.5,"frt":5122,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
262	1	1794077885	2		admin	harness2	deepseek-v4.1-flash	365	10382	60	4	t	1	\N	3	default		202611071858019646905158268d9d6Jv3z6HuI		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3133,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2432,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
263	1	1794077885	2		admin	harness2	deepseek-v4.1-flash	23	580	139	4	t	1	\N	3	default		202611071858019333867148268d9d661f5wAau		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3509,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":512,"completion_ratio":3.5,"frt":2520,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
264	1	1794077891	2		admin	harness2	deepseek-v4.1-flash	110	11870	173	6	t	1	\N	3	default		202611071858051385900108268d9d684MYr2qZ		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5950,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":10240,"completion_ratio":3.5,"frt":5266,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
265	1	1794077893	2		admin	harness2	deepseek-v4.1-flash	527	13960	192	2	t	1	\N	3	default		202611071858111183422348268d9d6gsuK6ZSj		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2867,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":2203,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
266	1	1794077899	2		admin	harness2	deepseek-v4.1-flash	457	23015	440	5	t	1	\N	3	default		202611071858140192140038268d9d6cKyiM5UN		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5467,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":13824,"completion_ratio":3.5,"frt":3775,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
267	1	1794077902	2		admin	harness2	deepseek-v4.1-flash	184	25629	246	3	t	1	\N	3	default		202611071858195195509218268d9d6cWWwQClf		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2689,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":23040,"completion_ratio":3.5,"frt":2044,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
268	1	1794077908	2		admin	harness2	deepseek-v4.1-flash	1041	26380	315	6	t	1	\N	3	default		202611071858222391862728268d9d6gcDruSNe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5932,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1536,"completion_ratio":3.5,"frt":4367,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
269	1	1794077924	2		admin	harness2	deepseek-v4.1-flash	349	28722	1236	16	t	1	\N	3	default		202611071858281998823588268d9d6ohBcPkEc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":16159,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":25600,"completion_ratio":3.5,"frt":11324,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
270	1	1794077930	2		admin	harness2	deepseek-v4.1-flash	1215	30987	279	6	t	1	\N	3	default		202611071858444064481018268d9d6fAkvlj9w		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6199,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":1664,"completion_ratio":3.5,"frt":5120,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
271	1	1794077940	2		admin	harness2	deepseek-v4.1-flash	220	34234	266	10	t	1	\N	3	default		202611071858506378922998268d9d6VC5kJHKl		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10063,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":31232,"completion_ratio":3.5,"frt":9125,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
272	1	1794077948	2		admin	harness2	deepseek-v4.1-flash	335	40150	266	8	t	1	\N	3	default		202611071859007376542468268d9d6LQoWfrsH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7356,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":34432,"completion_ratio":3.5,"frt":6430,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
273	1	1794077955	2		admin	harness2	deepseek-v4.1-flash	200	42926	106	7	t	1	\N	3	default		202611071859081364794288268d9d6MAiI1nA5		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7144,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":40320,"completion_ratio":3.5,"frt":6745,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
274	1	1794077962	2		admin	harness2	deepseek-v4.1-flash	202	44868	294	7	t	1	\N	3	default		202611071859153241884408268d9d6Q6w8h0nu		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7090,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":43008,"completion_ratio":3.5,"frt":5765,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
275	1	1794077968	2		admin	harness2	deepseek-v4.1-flash	210	47041	286	6	t	1	\N	3	default		202611071859224446999388268d9d6yhbpakYt		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6069,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":45056,"completion_ratio":3.5,"frt":4959,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
276	1	1794077974	2		admin	harness2	deepseek-v4.1-flash	162	48438	137	6	t	1	\N	3	default		202611071859285486904238268d9d6Ut1M3OhO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5923,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":47232,"completion_ratio":3.5,"frt":5350,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
277	1	1794077980	2		admin	harness2	deepseek-v4.1-flash	149	49507	85	6	t	1	\N	3	default		202611071859345137961238268d9d6nMvUNnaL		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5581,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":48512,"completion_ratio":3.5,"frt":5224,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
278	1	1794077986	2		admin	harness2	deepseek-v4.1-flash	148	50253	145	6	t	1	\N	3	default		202611071859401291176358268d9d61TGmBv1y		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6110,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":49536,"completion_ratio":3.5,"frt":5438,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
279	1	1794077997	2		admin	harness2	deepseek-v4.1-flash	200	52382	113	11	t	1	\N	3	default		202611071859462813583978268d9d6Gtx888X5		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10754,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":50304,"completion_ratio":3.5,"frt":9983,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
280	1	1794078004	2		admin	harness2	deepseek-v4.1-flash	265	55991	140	7	t	1	\N	3	default		202611071859570768779778268d9d6deSrybmN		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6926,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":52480,"completion_ratio":3.5,"frt":6230,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
281	1	1794078012	2		admin	harness2	deepseek-v4.1-flash	138	56161	121	8	t	1	\N	3	default		202611071900040424825868268d9d6nPkX3WJd		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8172,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":55936,"completion_ratio":3.5,"frt":7179,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
282	1	1794078021	2		admin	harness2	deepseek-v4.1-flash	183	57369	171	9	t	1	\N	3	default		202611071900122524246778268d9d6tQVImoeO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9012,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":56192,"completion_ratio":3.5,"frt":8198,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
283	1	1794078029	2		admin	harness2	deepseek-v4.1-flash	163	58138	150	8	t	1	\N	3	default		202611071900212991775898268d9d682iMufw3		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":8131,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":57472,"completion_ratio":3.5,"frt":7545,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
284	1	1794078039	2		admin	harness2	deepseek-v4.1-flash	174	59251	122	10	t	1	\N	3	default		202611071900294665759538268d9d6qIBda8Ba		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10387,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":58240,"completion_ratio":3.5,"frt":7566,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
285	1	1794078047	2		admin	harness2	deepseek-v4.1-flash	155	59856	91	8	t	1	\N	3	default		202611071900398782056278268d9d65JosDktE		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7506,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59264,"completion_ratio":3.5,"frt":6593,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
286	1	1794078053	2		admin	harness2	deepseek-v4.1-flash	148	60290	90	6	t	1	\N	3	default		202611071900474281338808268d9d6Wb7noJjx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6566,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":59904,"completion_ratio":3.5,"frt":6140,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
287	1	1794078063	2		admin	harness2	deepseek-v4.1-flash	234	62738	112	9	t	1	\N	3	default		202611071900540341017488268d9d685mXqSkx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9048,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":60288,"completion_ratio":3.5,"frt":5935,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
288	1	1794078069	2		admin	harness2	deepseek-v4.1-flash	153	63181	99	6	t	1	\N	3	default		202611071901031268044648268d9d6ZGv3Cny0		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6678,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":62848,"completion_ratio":3.5,"frt":5970,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
289	1	1794078076	2		admin	harness2	deepseek-v4.1-flash	147	63309	91	7	t	1	\N	3	default		202611071901098400841878268d9d6biCz50WH		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6909,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63104,"completion_ratio":3.5,"frt":6647,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
290	1	1794078087	2		admin	harness2	deepseek-v4.1-flash	146	63414	89	11	t	1	\N	3	default		202611071901167804473378268d9d6H9RRVyva		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":11026,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63232,"completion_ratio":3.5,"frt":10335,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
291	1	1794078098	2		admin	harness2	deepseek-v4.1-flash	158	63695	162	11	t	1	\N	3	default		202611071901278535423298268d9d6zfryBrUe		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10611,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63488,"completion_ratio":3.5,"frt":9830,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
292	1	1794078107	2		admin	harness2	deepseek-v4.1-flash	148	63896	100	9	t	1	\N	3	default		202611071901385050438658268d9d6GCrJFqqM		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9361,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63744,"completion_ratio":3.5,"frt":8827,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
293	1	1794078114	2		admin	harness2	deepseek-v4.1-flash	167	64306	159	7	t	1	\N	3	default		202611071901479068886988268d9d6ZN3o8NAx		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":6662,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":63872,"completion_ratio":3.5,"frt":5739,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
294	1	1794078122	2		admin	harness2	deepseek-v4.1-flash	173	64915	164	8	t	1	\N	3	default		202611071901546091213768268d9d64LGvE2DY		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7494,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":64384,"completion_ratio":3.5,"frt":6234,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
295	1	1794078132	2		admin	harness2	deepseek-v4.1-flash	160	65227	158	10	t	1	\N	3	default		202611071902021440097208268d9d6MDVpE7BX		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10240,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":65024,"completion_ratio":3.5,"frt":9041,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
296	1	1794078139	2		admin	harness2	deepseek-v4.1-flash	168	65743	138	7	t	1	\N	3	default		202611071902124324173018268d9d610WsjtiM		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7196,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":65280,"completion_ratio":3.5,"frt":6399,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
297	1	1794078167	2		admin	harness2	deepseek-v4.1-flash	549	67250	2564	28	t	1	\N	3	default		202611071902196690359678268d9d6SGZwVOQB		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":27478,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":65792,"completion_ratio":3.5,"frt":8785,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
298	1	1794078182	2		admin	harness2	deepseek-v4.1-flash	496	69830	2495	15	t	1	\N	3	default		202611071902471852637538268d9d65bzxgkJP		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":15794,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":69632,"completion_ratio":3.5,"frt":6046,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
299	1	1794078271	2		admin	harness2	deepseek-v4.1-flash	787	17254	695	7	f	1	\N	3	default		202611071904241240304468268d9d6WiLCToF3		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":4,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7156,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
300	1	1794078273	2		admin	harness2	deepseek-v4.1-flash	817	17286	898	9	f	1	\N	3	default		202611071904241247512218268d9d6te3jWBhO		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9131,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
301	1	1794078274	2		admin	harness2	deepseek-v4.1-flash	777	17283	609	10	f	1	\N	3	default		202611071904241245530378268d9d6G4VBMGd6		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10010,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
302	1	1794078274	2		admin	harness2	deepseek-v4.1-flash	836	17291	1028	10	f	1	\N	3	default		202611071904241248045638268d9d6uDt10W34		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":10725,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
303	1	1794078276	2		admin	harness2	deepseek-v4.1-flash	859	17274	1203	12	f	1	\N	3	default		202611071904241237761818268d9d6GPs4QNgv		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":12432,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
304	1	1794078277	2		admin	harness2	deepseek-v4.1-flash	797	17282	756	13	f	1	\N	3	default		202611071904241236728368268d9d6RZ0g4lVh		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":13657,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
305	1	1794078278	2		admin	harness2	deepseek-v4.1-flash	755	17253	462	5	f	1	\N	3	default		202611071904332766703058268d9d6AtdOp7vg		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":5045,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
306	1	1794078280	2		admin	harness2	deepseek-v4.1-flash	953	17258	1879	16	f	1	\N	3	default		202611071904241243053948268d9d6RZjiWJvc		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":3,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":16082,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
307	1	1794078280	2		admin	harness2	deepseek-v4.1-flash	847	17244	1120	9	f	1	\N	3	default		202611071904313048736118268d9d61c9pzRlM		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":9190,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
308	1	1794078281	2		admin	harness2	deepseek-v4.1-flash	979	17253	2063	17	f	1	\N	3	default		202611071904241250177398268d9d6WcfkVWVK		{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":17199,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.05,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"reasoning_effort":"low","request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash","upstream_model":"deepseek-v4.1-flash","returned_model":"deepseek/deepseek-v4.1-flash"},"user_group_ratio":-1}
311	0	1794139185	1	Administrator completed the order, amount added: ＄0.000000, payment amount: 0.000000				0	0	0	0	f	0	\N	0		172.22.0.1	202611081159459749229298268d9d6WfbbsS2t		{"admin_info":{"callback_payment_method":"admin","caller_ip":"172.22.0.1","node_name":"dgai-node-1","payment_method":"","server_ip":"172.22.0.2","version":"v1.0.0-dgai"},"content_parts":[{"key":"Administrator completed the order, amount added: {{quota}}, payment amount: {{amount}}","params":{"amount":"0.000000","quota":"＄0.000000"}}]}
312	1	1794140550	1	Administrator completed the order, amount added: ＄1.000000, payment amount: 1.000000	admin			0	0	0	0	f	0	\N	0		172.22.0.1	202611081222306274411308268d9d6N2uvQ5NS		{"admin_info":{"callback_payment_method":"admin","caller_ip":"172.22.0.1","node_name":"dgai-node-1","payment_method":"vietqr","server_ip":"172.22.0.2","version":"v1.0.0-dgai"},"content_parts":[{"key":"Administrator completed the order, amount added: {{quota}}, payment amount: {{amount}}","params":{"amount":"1.000000","quota":"＄1.000000"}}]}
313	1	1794140656	1	Administrator completed the order, amount added: ＄1.000000, payment amount: 1.000000	admin			0	0	0	0	f	0	\N	0		172.22.0.1	202611081224161548674768268d9d6ckHvUkQL		{"admin_info":{"callback_payment_method":"admin","caller_ip":"172.22.0.1","node_name":"dgai-node-1","payment_method":"vietqr","server_ip":"172.22.0.2","version":"v1.0.0-dgai"},"content_parts":[{"key":"Administrator completed the order, amount added: {{quota}}, payment amount: {{amount}}","params":{"amount":"1.000000","quota":"＄1.000000"}}]}
314	1	1794231921	2		admin	cache-test	claude-opus-5-5	1	3	1	2	f	2	\N	2	default		202611091345190502795528268d9d6YPOJOGbE		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1990,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"reasoning_effort":"medium","request_conversion":["Claude Messages","OpenAI Compatible"],"request_path":"/v1/messages","user_group_ratio":-1}
315	1	1794231933	2		admin	cache-test	gpt-6.1-sol	29	1505	5	2	f	3	\N	2	default		202611091345310542851138268d9d6i0fis9wj		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":8,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":2839,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["3"]},"billing_source":"wallet","cache_ratio":0.1,"cache_tokens":1280,"completion_ratio":6,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"request_conversion":["OpenAI Responses"],"request_path":"/v1/responses","user_group_ratio":-1}
316	1	1794232961	2		admin	cache-test	claude-opus-5-5	3650	24107	45	9	t	2	\N	2	default		202611091402326944166968268d9d67ShO6vi1		{"admin_info":{"channel_affinity":{"key_fp":"f2d569ce","key_key":"","key_path":"metadata.user_id","key_source":"gjson","model":"claude-opus-5-5","override_template":{"applied":true,"param_override_keys":1,"rule_name":"claude cli trace"},"reason":"claude cli trace","request_path":"/v1/messages","rule_name":"claude cli trace","using_group":"default"},"request_policy":[{"attempt":0,"rule":"claude cli trace","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":2,"group":"default","rule":"claude cli trace","elapsed_ms":6,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","rule":"claude cli trace","elapsed_ms":8720,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"frt":7385,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"reasoning_effort":"medium","request_conversion":["Claude Messages","OpenAI Compatible"],"request_path":"/v1/messages","stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
317	1	1794232989	2		admin	cache-test	claude-opus-5-5	1927	18511	54	7	t	2	\N	2	default		202611091403026058597978268d9d69ezRQxaP		{"admin_info":{"channel_affinity":{"key_fp":"fbf783b4","key_key":"","key_path":"metadata.user_id","key_source":"gjson","model":"claude-opus-5-5","override_template":{"applied":true,"param_override_keys":1,"rule_name":"claude cli trace"},"reason":"claude cli trace","request_path":"/v1/messages","rule_name":"claude cli trace","using_group":"default"},"request_policy":[{"attempt":0,"rule":"claude cli trace","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":2,"group":"default","rule":"claude cli trace","elapsed_ms":2,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","rule":"claude cli trace","elapsed_ms":6878,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":11866,"completion_ratio":5,"frt":6291,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"reasoning_effort":"medium","request_conversion":["Claude Messages","OpenAI Compatible"],"request_path":"/v1/messages","stream_status":{"end_reason":"done","response_status":"completed","status":"ok"},"user_group_ratio":-1}
318	1	1794233709	2		admin	cache-test	gpt-6.1-sol	1004	13358	5	4	t	3	\N	2	default		202611091415059044366638268d9d6kn32bt6g		{"admin_info":{"channel_affinity":{"key_fp":"7f078e9f","key_key":"","key_path":"prompt_cache_key","key_source":"gjson","model":"gpt-6.1-sol","override_template":{"applied":true,"param_override_keys":1,"rule_name":"codex cli trace"},"reason":"codex cli trace","request_path":"/v1/responses","rule_name":"codex cli trace","using_group":"default"},"request_policy":[{"attempt":0,"rule":"codex cli trace","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":3,"group":"default","rule":"codex cli trace","elapsed_ms":12,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":3,"group":"default","rule":"codex cli trace","elapsed_ms":3126,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["3"]},"billing_source":"wallet","cache_ratio":0.1,"cache_tokens":0,"completion_ratio":6,"frt":3027,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"reasoning_effort":"low","request_conversion":["OpenAI Responses"],"request_path":"/v1/responses","stream_status":{"end_reason":"eof","response_status":"completed","status":"ok"},"user_group_ratio":-1}
319	1	1794235869	5	status_code=403, Please subscribe to model in the API Key: deepseek-v4.1-flash	admin	cache-test	deepseek-v4.1-flash	0	0	0	0	f	1	\N	2	default		202611091451084331836108268d9d6JKTOaX4i		{"admin_info":{"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":7,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":403,"error_code":"FORBIDDEN","error_source":"upstream","elapsed_ms":793,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","status":403,"error_code":"FORBIDDEN","error_source":"upstream","elapsed_ms":793,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["1"]},"error_code":"FORBIDDEN","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":403}
320	1	1794235872	2		admin	cache-test	claude-opus-5-5	1	3	1	3	f	2	\N	2	default		202611091451093091616518268d9d6CRmMJVzT		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":2947,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"reasoning_effort":"medium","request_conversion":["Claude Messages","OpenAI Compatible"],"request_path":"/v1/messages","user_group_ratio":-1}
321	1	1794235901	2		admin	cache-test	deepseek-v4.1-flash-1017	3	57	2	3	f	1	\N	2	default		202611091451384914019068268d9d6dsNjhZNf	202611091451393558479548268d9d68bP8Z4wn	{"admin_info":{"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":1,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2552,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.4,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"deepseek-v4.1-flash"},"user_group_ratio":-1}
322	1	1794235912	2		admin	cache-test	deepseek-v4.1-flash-1017	4	56	16	2	f	1	\N	2	default		202611091451504074498428268d9d60VFpJJQV	202611091451516487866828268d9d6PmGhGMEQ	{"admin_info":{"channel_affinity":{"channel_id":1,"key_fp":"356a192b","key_key":"id","key_path":"","key_source":"context_int","model":"deepseek-v4.1-flash-1017","reason":"dgai deepseek sticky","request_path":"/v1/chat/completions","rule_name":"dgai deepseek sticky","selected_group":"default","using_group":"default"},"request_policy":[{"attempt":0,"rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"match","reason":"session_rule_matched","source":"session_rule"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","rule":"dgai deepseek sticky","elapsed_ms":2505,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0.4,"cache_tokens":0,"completion_ratio":3.5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"deepseek-v4.1-flash"},"user_group_ratio":-1}
323	1	1794235914	2		admin	cache-test	cnb/deepseek-pro-v4	1500	68	16	2	f	1	\N	2	default		202611091451529913786648268d9d6ISIymuXo		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":1,"group":"default","elapsed_ms":1446,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["1"]},"billing_source":"wallet","cache_ratio":0,"cache_tokens":0,"completion_ratio":0,"frt":-1000,"group_ratio":1,"model_price":0.003,"model_ratio":0,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"cnb/deepseek-pro-v4","upstream_model":"cnb/deepseek-pro-v4","returned_model":"deepseek-pro-v4"},"user_group_ratio":-1}
324	1	1794235917	2		admin	cache-test	gpt-6.1-sol	118	1504	12	3	f	3	\N	2	default		202611091451545155253938268d9d6gwjif6De		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":16,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":3,"group":"default","elapsed_ms":2808,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["3"]},"billing_source":"wallet","cache_ratio":0.1,"cache_tokens":0,"completion_ratio":6,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
325	1	1794235921	2		admin	cache-test	claude-opus-5-5	36	1	48	4	f	2	\N	2	default		202611091451574033763718268d9d6OATwIhNg		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":2,"group":"default","elapsed_ms":4383,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"usage_billing_path":"upstream","use_channel":["2"]},"billing_source":"wallet","cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
326	1	1794235977	2	Model test	admin	Model test	deepseek-v4.1-flash-1017	4	56	12	1	f	1	\N	0	default		202611091452579443775368268d9d6kvMjX2p2	202611091452570087736748268d9d6RsCXz30Q	{"admin_info":{"request_policy":[{"attempt":0,"channel_id":1,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.4,"cache_tokens":0,"completion_ratio":3.5,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.04,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","response_model":{"requested_model":"deepseek-v4.1-flash-1017","upstream_model":"deepseek-v4.1-flash-1017","returned_model":"deepseek-v4.1-flash"},"user_group_ratio":-1}
327	1	1794235981	2	Model test	admin	Model test	claude-opus-5-5	11	1	14	3	f	2	\N	0	default		202611091453012545512958268d9d6Qe1wDG5U		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":2,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.5,"cache_tokens":0,"completion_ratio":5,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.15,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
328	1	1794235983	2	Model test	admin	Model test	gpt-6.1-sol	118	1504	11	2	f	3	\N	0	default		202611091453037809676868268d9d6ZqQK1UaA		{"admin_info":{"request_policy":[{"attempt":0,"channel_id":3,"elapsed_ms":0,"decision":{"action":"success","reason":"request_completed","source":"upstream"}}],"use_channel":null},"cache_ratio":0.1,"cache_tokens":1280,"completion_ratio":6,"content_parts":[{"key":"Model test"}],"frt":-1000,"group_ratio":1,"model_price":-1,"model_ratio":0.075,"request_conversion":["OpenAI Compatible"],"request_path":"/v1/chat/completions","user_group_ratio":-1}
329	1	1794236007	5	status_code=200, The upstream provider is overloaded or had an internal error. This is usually transient; please retry.	admin	cache-test	slow/agy/gemini-3.8-flash-medium	0	0	0	85	f	4	\N	2	default		202611091452018634873528268d9d6scWUJAod		{"admin_info":{"request_policy":[{"attempt":1,"channel_id":4,"group":"default","elapsed_ms":0,"decision":{"action":"attempt","reason":"channel_selected","source":"routing"}},{"attempt":1,"channel_id":4,"group":"default","status":200,"error_code":"unknown_error","error_source":"upstream","elapsed_ms":85421,"decision":{"action":"failure","reason":"upstream_failure","source":"upstream"}},{"attempt":1,"channel_id":4,"group":"default","status":200,"error_code":"unknown_error","error_source":"upstream","elapsed_ms":85421,"decision":{"action":"stop","reason":"attempt_budget_exhausted","source":"global"},"health":"unchanged"}],"use_channel":["4"]},"error_code":"unknown_error","error_type":"openai_error","request_path":"/v1/chat/completions","status_code":200}
\.


--
-- Data for Name: midjourneys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.midjourneys (id, code, user_id, action, mj_id, prompt, prompt_en, description, state, submit_time, start_time, finish_time, image_url, video_url, video_urls, status, progress, fail_reason, channel_id, quota, buttons, properties, token_id, billing_channel_id) FROM stdin;
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.models (id, model_name, description, icon, tags, vendor_id, endpoints, status, sync_official, created_time, updated_time, deleted_at, name_rule) FROM stdin;
1	deepseek-v4.1-flash				0		0	1	1794081435	1794081435	2026-11-07 19:57:30.107804+00	0
\.


--
-- Data for Name: options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.options (key, value) FROM stdin;
LegacyAccessTokenRetireAt	1796655802
theme.frontend	default
SelfUseModeEnabled	false
DemoSiteEnabled	false
AudioCompletionRatio	{"gpt-4o-mini-realtime":2,"gpt-4o-mini-tts":1,"gpt-4o-realtime":2,"tts-1":0,"tts-1-1106":0,"tts-1-hd":0,"tts-1-hd-1106":0}
AudioRatio	{"gpt-4o-audio-preview":16,"gpt-4o-mini-audio-preview":66.67,"gpt-4o-mini-realtime-preview":16.67,"gpt-4o-mini-tts":25,"gpt-4o-realtime-preview":8}
CacheRatio	{"claude-3-5-haiku-20241022":0.1,"claude-3-5-sonnet-20240620":0.1,"claude-3-5-sonnet-20241022":0.1,"claude-3-7-sonnet-20250219":0.1,"claude-3-7-sonnet-20250219-thinking":0.1,"claude-3-haiku-20240307":0.1,"claude-3-opus-20240229":0.1,"claude-3-sonnet-20240229":0.1,"claude-haiku-4-5-20251001":0.1,"claude-opus-4-1-20250805":0.1,"claude-opus-4-1-20250805-thinking":0.1,"claude-opus-4-20250514":0.1,"claude-opus-4-20250514-thinking":0.1,"claude-opus-4-5-20251101":0.1,"claude-opus-4-5-20251101-thinking":0.1,"claude-opus-4-6":0.1,"claude-opus-4-6-high":0.1,"claude-opus-4-6-low":0.1,"claude-opus-4-6-max":0.1,"claude-opus-4-6-medium":0.1,"claude-opus-4-6-thinking":0.1,"claude-opus-4-7":0.1,"claude-opus-4-7-high":0.1,"claude-opus-4-7-low":0.1,"claude-opus-4-7-max":0.1,"claude-opus-4-7-medium":0.1,"claude-opus-4-7-thinking":0.1,"claude-opus-4-7-xhigh":0.1,"claude-opus-4-8":0.1,"claude-opus-4-8-high":0.1,"claude-opus-4-8-low":0.1,"claude-opus-4-8-max":0.1,"claude-opus-4-8-medium":0.1,"claude-opus-4-8-thinking":0.1,"claude-opus-4-8-xhigh":0.1,"claude-opus-5-5":0.5,"claude-sonnet-4-20250514":0.1,"claude-sonnet-4-20250514-thinking":0.1,"claude-sonnet-4-5-20250929":0.1,"claude-sonnet-4-5-20250929-thinking":0.1,"cx/gpt-6-luna":0.75,"deepseek-chat":0.25,"deepseek-coder":0.25,"deepseek-reasoner":0.25,"deepseek-v4.1-flash":0.05,"deepseek-v4.1-flash-1017":0.4,"gemini-3-flash-preview":0.1,"gemini-3-pro-preview":0.1,"gemini-3.1-pro-preview":0.1,"gpt-4":0.5,"gpt-4.1":0.25,"gpt-4.1-mini":0.25,"gpt-4.1-nano":0.25,"gpt-4.5-preview":0.5,"gpt-4.5-preview-2025-02-27":0.5,"gpt-4o":0.5,"gpt-4o-2024-08-06":0.5,"gpt-4o-2024-11-20":0.5,"gpt-4o-mini":0.5,"gpt-4o-mini-2024-07-18":0.5,"gpt-4o-mini-realtime-preview":0.5,"gpt-4o-realtime-preview":0.5,"gpt-5":0.1,"gpt-5-2025-08-07":0.1,"gpt-5-chat-latest":0.1,"gpt-5-mini":0.1,"gpt-5-mini-2025-08-07":0.1,"gpt-5-nano":0.1,"gpt-5-nano-2025-08-07":0.1,"gpt-6.1-sol":0.1,"o1":0.5,"o1-2024-12-17":0.5,"o1-mini":0.5,"o1-mini-2024-09-12":0.5,"o1-preview":0.5,"o1-preview-2024-09-12":0.5,"o3-mini":0.5,"o3-mini-2025-01-31":0.5}
CompletionRatio	{"claude-opus-5-5":5,"cx/gpt-6-luna":2,"deepseek-v4.1-flash":3.5,"deepseek-v4.1-flash-1017":3.5,"gpt-4-all":2,"gpt-4-gizmo-*":2,"gpt-4o-gizmo-*":3,"gpt-6.1-sol":6,"gpt-image-1":8}
ImageRatio	{"gpt-image-1":2}
ModelRatio	{"BLOOMZ-7B":0.273972602739726,"ERNIE-3.5-4K-0205":0.821917808219178,"ERNIE-3.5-8K":0.821917808219178,"ERNIE-3.5-8K-0205":1.643835616438356,"ERNIE-3.5-8K-1222":0.821917808219178,"ERNIE-4.0-8K":8.219178082191782,"ERNIE-Bot-8K":1.643835616438356,"ERNIE-Lite-8K-0308":0.2054794520547945,"ERNIE-Lite-8K-0922":0.547945205479452,"ERNIE-Speed-128K":0.273972602739726,"ERNIE-Speed-8K":0.273972602739726,"ERNIE-Tiny-8K":0.0684931506849315,"Embedding-V1":0.136986301369863,"NousResearch/Hermes-4-405B-FP8":0.8,"PaLM-2":1,"Qwen/Qwen3-235B-A22B-Instruct-2507":0.3,"Qwen/Qwen3-235B-A22B-Thinking-2507":0.6,"Qwen/Qwen3-Coder-480B-A35B-Instruct-FP8":0.8,"SparkDesk-v1.1":1.2858,"SparkDesk-v2.1":1.2858,"SparkDesk-v3.1":1.2858,"SparkDesk-v3.5":1.2858,"SparkDesk-v4.0":1.2858,"bge-large-en":0.136986301369863,"bge-large-zh":0.136986301369863,"chatglm_lite":0.1429,"chatglm_pro":0.7143,"chatglm_std":0.3572,"chatglm_turbo":0.3572,"chatgpt-4o-latest":2.5,"claude-3-5-haiku-20241022":0.5,"claude-3-5-sonnet-20240620":1.5,"claude-3-5-sonnet-20241022":1.5,"claude-3-7-sonnet-20250219":1.5,"claude-3-7-sonnet-20250219-thinking":1.5,"claude-3-haiku-20240307":0.125,"claude-3-opus-20240229":7.5,"claude-3-sonnet-20240229":1.5,"claude-haiku-4-5-20251001":0.5,"claude-opus-4-1-20250805":7.5,"claude-opus-4-20250514":7.5,"claude-opus-4-5-20251101":2.5,"claude-opus-4-6":2.5,"claude-opus-4-6-high":2.5,"claude-opus-4-6-low":2.5,"claude-opus-4-6-max":2.5,"claude-opus-4-6-medium":2.5,"claude-opus-4-7":2.5,"claude-opus-4-7-high":2.5,"claude-opus-4-7-low":2.5,"claude-opus-4-7-max":2.5,"claude-opus-4-7-medium":2.5,"claude-opus-4-7-xhigh":2.5,"claude-opus-4-8":2.5,"claude-opus-4-8-high":2.5,"claude-opus-4-8-low":2.5,"claude-opus-4-8-max":2.5,"claude-opus-4-8-medium":2.5,"claude-opus-4-8-xhigh":2.5,"claude-opus-5-5":0.15,"claude-sonnet-4-20250514":1.5,"claude-sonnet-4-5-20250929":1.5,"code-davinci-edit-001":10,"command":0.5,"command-light":0.5,"command-light-nightly":0.5,"command-nightly":0.5,"command-r":0.25,"command-r-08-2024":0.075,"command-r-plus":1.5,"command-r-plus-08-2024":1.25,"curie":10,"cx/gpt-6-luna":0.015,"davinci":10,"deepseek-ai/DeepSeek-R1":0.8,"deepseek-ai/DeepSeek-R1-0528":0.8,"deepseek-ai/DeepSeek-V3-0324":0.8,"deepseek-ai/DeepSeek-V3.1":0.8,"deepseek-chat":0.135,"deepseek-coder":0.135,"deepseek-reasoner":0.275,"deepseek-v4.1-flash":0.04,"deepseek-v4.1-flash-1017":0.04,"gemini-1.5-flash-latest":0.075,"gemini-1.5-pro-latest":1.25,"gemini-2.0-flash":0.05,"gemini-2.5-flash":0.15,"gemini-2.5-flash-lite-preview-06-17":0.05,"gemini-2.5-flash-lite-preview-thinking-*":0.05,"gemini-2.5-flash-preview-04-17":0.075,"gemini-2.5-flash-preview-04-17-thinking":0.075,"gemini-2.5-flash-preview-05-20":0.075,"gemini-2.5-flash-preview-05-20-thinking":0.075,"gemini-2.5-flash-thinking-*":0.075,"gemini-2.5-pro":0.625,"gemini-2.5-pro-exp-03-25":0.625,"gemini-2.5-pro-preview-03-25":0.625,"gemini-2.5-pro-thinking-*":0.625,"gemini-embedding-001":0.075,"gemini-robotics-er-1.5-preview":0.15,"glm-3-turbo":0.3572,"glm-4":7.143,"glm-4-0520":6.8493150684931505,"glm-4-air":0.0684931506849315,"glm-4-airx":0.684931506849315,"glm-4-alltools":6.8493150684931505,"glm-4-flash":0,"glm-4-long":0.0684931506849315,"glm-4-plus":3.4246575342465753,"glm-4v":3.4246575342465753,"glm-4v-plus":0.684931506849315,"gpt-3.5-turbo":0.25,"gpt-3.5-turbo-0125":0.25,"gpt-3.5-turbo-0613":0.75,"gpt-3.5-turbo-1106":0.5,"gpt-3.5-turbo-16k":1.5,"gpt-3.5-turbo-16k-0613":1.5,"gpt-3.5-turbo-instruct":0.75,"gpt-4":15,"gpt-4-0125-preview":5,"gpt-4-0613":15,"gpt-4-1106-preview":5,"gpt-4-1106-vision-preview":5,"gpt-4-32k":30,"gpt-4-32k-0613":30,"gpt-4-all":15,"gpt-4-gizmo-*":15,"gpt-4-turbo":5,"gpt-4-turbo-2024-04-09":5,"gpt-4-turbo-preview":5,"gpt-4-vision-preview":5,"gpt-4.1":1,"gpt-4.1-2025-04-14":1,"gpt-4.1-mini":0.2,"gpt-4.1-mini-2025-04-14":0.2,"gpt-4.1-nano":0.05,"gpt-4.1-nano-2025-04-14":0.05,"gpt-4.5-preview":37.5,"gpt-4.5-preview-2025-02-27":37.5,"gpt-4o":1.25,"gpt-4o-2024-05-13":2.5,"gpt-4o-2024-08-06":1.25,"gpt-4o-2024-11-20":1.25,"gpt-4o-all":15,"gpt-4o-audio-preview":1.25,"gpt-4o-audio-preview-2024-10-01":1.25,"gpt-4o-gizmo-*":2.5,"gpt-4o-mini":0.075,"gpt-4o-mini-2024-07-18":0.075,"gpt-4o-mini-realtime-preview":0.3,"gpt-4o-mini-realtime-preview-2024-12-17":0.3,"gpt-4o-realtime-preview":2.5,"gpt-4o-realtime-preview-2024-10-01":2.5,"gpt-4o-realtime-preview-2024-12-17":2.5,"gpt-5":0.625,"gpt-5-2025-08-07":0.625,"gpt-5-chat-latest":0.625,"gpt-5-mini":0.125,"gpt-5-mini-2025-08-07":0.125,"gpt-5-nano":0.025,"gpt-5-nano-2025-08-07":0.025,"gpt-5.5":2.5,"gpt-5.6-luna":0.5,"gpt-5.6-sol":2.5,"gpt-5.6-terra":1.25,"gpt-6.1-sol":0.075,"gpt-image-1":2.5,"grok-2":1,"grok-2-vision":1,"grok-3-beta":1.5,"grok-3-fast-beta":2.5,"grok-3-mini-beta":0.15,"grok-3-mini-fast-beta":0.3,"grok-beta":2.5,"grok-vision-beta":2.5,"hunyuan":7.143,"llama-3-sonar-large-32k-chat":0,"llama-3-sonar-large-32k-online":0,"llama-3-sonar-small-32k-chat":0.1,"llama-3-sonar-small-32k-online":0.1,"o1":7.5,"o1-2024-12-17":7.5,"o1-mini":0.55,"o1-mini-2024-09-12":0.55,"o1-preview":7.5,"o1-preview-2024-09-12":7.5,"o1-pro":75,"o1-pro-2025-03-19":75,"o3":1,"o3-2025-04-16":1,"o3-deep-research":5,"o3-deep-research-2025-06-26":5,"o3-mini":0.55,"o3-mini-2025-01-31":0.55,"o3-mini-2025-01-31-high":0.55,"o3-mini-2025-01-31-low":0.55,"o3-mini-2025-01-31-medium":0.55,"o3-mini-high":0.55,"o3-mini-low":0.55,"o3-mini-medium":0.55,"o3-pro":10,"o3-pro-2025-06-10":10,"o4-mini":0.55,"o4-mini-2025-04-16":0.55,"o4-mini-deep-research":1,"o4-mini-deep-research-2025-06-26":1,"openai/gpt-oss-120b":0.5,"qwen-plus":10,"qwen-turbo":0.8572,"tao-8k":0.136986301369863,"text-ada-001":0.2,"text-babbage-001":0.25,"text-curie-001":1,"text-davinci-edit-001":10,"text-embedding-004":0.001,"text-embedding-3-large":0.065,"text-embedding-3-small":0.01,"text-embedding-ada-002":0.05,"text-embedding-v1":0.05,"text-moderation-latest":0.1,"text-moderation-stable":0.1,"text-search-ada-doc-001":10,"tts-1":7.5,"tts-1-1106":7.5,"tts-1-hd":15,"tts-1-hd-1106":15,"whisper-1":15,"yi-34b-chat-0205":0.18,"yi-34b-chat-200k":0.864,"yi-large":1.36986301369863,"yi-large-preview":1.36986301369863,"yi-large-rag":1.7123287671232876,"yi-large-rag-preview":1.7123287671232876,"yi-large-turbo":0.821917808219178,"yi-medium":0.17123287671232876,"yi-medium-200k":0.821917808219178,"yi-spark":0.0684931506849315,"yi-vision":0.410958904109589,"yi-vl-plus":0.432,"zai-org/GLM-4.5-FP8":0.8}
billing_setting.billing_expr	{}
billing_setting.billing_mode	{}
billing_setting.plugin_billing_expr	{}
ModelPrice	{"black-forest-labs/flux-1.1-pro":0.04,"claude-fable-5.1-req":0.02,"claude-opus-4-8":0.008,"claude-opus-5.5":0.02,"cnb/deepseek-pro-v4":0.003,"dall-e-3":0.04,"gpt-4-gizmo-*":0.1,"gpt-4o-mini-tts":0.3,"imagen-3.0-generate-002":0.03,"mj_blend":0.1,"mj_custom_zoom":0,"mj_describe":0.05,"mj_edits":0.1,"mj_high_variation":0.1,"mj_imagine":0.1,"mj_inpaint":0,"mj_low_variation":0.1,"mj_modal":0.1,"mj_pan":0.1,"mj_reroll":0.1,"mj_shorten":0.1,"mj_upload":0.05,"mj_upscale":0.05,"mj_variation":0.1,"mj_video":0.8,"mj_zoom":0.1,"slow/agy/gemini-3.8-flash-medium":0.002,"sora-2":0.3,"sora-2-pro":0.5,"suno_lyrics":0.01,"suno_music":0.1,"swap_face":0.05,"veo-3.0-fast-generate-001":0.15,"veo-3.0-generate-001":0.4,"veo-3.1-fast-generate-preview":0.15,"veo-3.1-generate-preview":0.4}
SystemName	dgai
Footer	<p>dgai — API AI giá rẻ, thanh toán linh hoạt.</p>
payment_setting.compliance_confirmed	true
payment_setting.compliance_terms_version	v1
payment_setting.compliance_confirmed_at	1794066729
payment_setting.compliance_confirmed_by	1
payment_setting.compliance_confirmed_ip	172.22.0.1
MinTopUp	1
Price	1
USDExchangeRate	1
PayMethods	[{"name": "Chuy\\u1ec3n kho\\u1ea3n ng\\u00e2n h\\u00e0ng", "icon": "LuCreditCard", "type": "custom1", "min_topup": "1"}]
payment_setting.amount_options	[1, 5, 10, 20, 50, 100]
payment_setting.amount_discount	{}
QuotaDisplayType	USD
TopUpLink	https://img.vietqr.io/image/970436-0000000000-compact2.png?amount=1&addInfo=DGAI
general_setting.docs_link	/docs
channel_affinity_setting.rules	[{"name":"codex cli trace","model_regex":["^gpt-.*$"],"path_regex":["/v1/responses"],"key_sources":[{"type":"gjson","path":"prompt_cache_key"}],"value_regex":"","ttl_seconds":0,"param_override_template":{"operations":[{"keep_origin":true,"mode":"pass_headers","value":["Originator","Session_id","Thread_id","Session-Id","Thread-Id","X-Client-Request-Id","User-Agent","X-Codex-Beta-Features","X-Codex-Turn-State","X-Codex-Turn-Metadata","X-Codex-Window-Id","X-Codex-Parent-Thread-Id","X-OpenAI-Subagent","X-OpenAI-Memgen-Request","X-ResponsesAPI-Include-Timing-Metrics","X-OpenAI-Internal-Codex-Responses-Lite"]}]},"skip_retry_on_failure":true,"include_using_group":true,"include_model_name":false,"include_rule_name":true},{"name":"claude cli trace","model_regex":["^claude-.*$"],"path_regex":["/v1/messages"],"key_sources":[{"type":"gjson","path":"metadata.user_id"}],"value_regex":"","ttl_seconds":0,"param_override_template":{"operations":[{"keep_origin":true,"mode":"pass_headers","value":["X-Stainless-Arch","X-Stainless-Lang","X-Stainless-Os","X-Stainless-Package-Version","X-Stainless-Retry-Count","X-Stainless-Runtime","X-Stainless-Runtime-Version","X-Stainless-Timeout","User-Agent","X-App","Anthropic-Beta","Anthropic-Dangerous-Direct-Browser-Access","Anthropic-Version"]}]},"skip_retry_on_failure":true,"include_using_group":true,"include_model_name":false,"include_rule_name":true},{"name":"dgai deepseek sticky","model_regex":["^deepseek-.*$"],"path_regex":[],"key_sources":[{"type":"context_int","key":"id"}],"value_regex":"","ttl_seconds":3600,"skip_retry_on_failure":false,"session_mode":"prefer","include_using_group":true,"include_model_name":true,"include_rule_name":true}]
CreateCacheRatio	{"claude-3-5-haiku-20241022":1.25,"claude-3-5-sonnet-20240620":1.25,"claude-3-5-sonnet-20241022":1.25,"claude-3-7-sonnet-20250219":1.25,"claude-3-7-sonnet-20250219-thinking":1.25,"claude-3-haiku-20240307":1.25,"claude-3-opus-20240229":1.25,"claude-3-sonnet-20240229":1.25,"claude-haiku-4-5-20251001":1.25,"claude-opus-4-1-20250805":1.25,"claude-opus-4-1-20250805-thinking":1.25,"claude-opus-4-20250514":1.25,"claude-opus-4-20250514-thinking":1.25,"claude-opus-4-5-20251101":1.25,"claude-opus-4-5-20251101-thinking":1.25,"claude-opus-4-6":1.25,"claude-opus-4-6-high":1.25,"claude-opus-4-6-low":1.25,"claude-opus-4-6-max":1.25,"claude-opus-4-6-medium":1.25,"claude-opus-4-6-thinking":1.25,"claude-opus-4-7":1.25,"claude-opus-4-7-high":1.25,"claude-opus-4-7-low":1.25,"claude-opus-4-7-max":1.25,"claude-opus-4-7-medium":1.25,"claude-opus-4-7-thinking":1.25,"claude-opus-4-7-xhigh":1.25,"claude-opus-4-8":1.25,"claude-opus-4-8-high":1.25,"claude-opus-4-8-low":1.25,"claude-opus-4-8-max":1.25,"claude-opus-4-8-medium":1.25,"claude-opus-4-8-thinking":1.25,"claude-opus-4-8-xhigh":1.25,"claude-sonnet-4-20250514":1.25,"claude-sonnet-4-20250514-thinking":1.25,"claude-sonnet-4-5-20250929":1.25,"claude-sonnet-4-5-20250929-thinking":1.25,"gpt-5.6-luna":1.25,"gpt-5.6-sol":1.25,"gpt-5.6-terra":1.25}
metadata_sync_lock	
VietQREnabled	true
VietQRBankCode	TCB
VietQRBankAccount	0395185726
VietQRAccountName	
VietQRMinTopUp	1
VietQRSyncSecretKey	8f3a2c9d7e1b4a6f0c5d8e2b9a7f4c1d6e3b8a5f2c9d7e4b1a8f6c3d9e2b5a7
VietQRSyncUsername	0395185726
VietQRSyncPassword	Dgai@VietQR2026
ServerAddress	https://localhost
passkey.legacy_rp_ids	
passkey.origins	http://localhost:3000,https://localhost
passkey.rp_id	
\.


--
-- Data for Name: passkey_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.passkey_credentials (id, user_id, rp_id, credential_id, public_key, attestation_type, aa_guid, sign_count, clone_warning, user_present, user_verified, backup_eligible, backup_state, transports, attachment, last_used_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: perf_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.perf_metrics (id, model_name, "group", bucket_ts, request_count, success_count, total_latency_ms, ttft_sum_ms, ttft_count, output_tokens, generation_ms) FROM stdin;
1	deepseek-v4.1-flash	default	1794067200	6	6	21418	0	0	96	21418
2	deepseek-v4.1-flash	default	1794070800	1	1	2433	0	0	16	2433
3	deepseek-v4.1-flash	default	1794074400	252	246	2898692	1508867	246	214766	1332775
4	deepseek-v4.1-flash-1017	default	1794232800	2	2	5068	0	0	18	5068
5	claude-opus-5-5	default	1794232800	2	2	7338	0	0	49	7338
6	gpt-6.1-sol	default	1794232800	1	1	2810	0	0	12	2810
7	slow/agy/gemini-3.8-flash-medium	default	1794232800	1	0	85423	0	0	0	0
8	deepseek-v4.1-flash	default	1794232800	1	0	798	0	0	0	0
9	cnb/deepseek-pro-v4	default	1794232800	1	1	1449	0	0	16	1449
\.


--
-- Data for Name: prefill_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prefill_groups (id, name, type, items, description, created_time, updated_time, deleted_at) FROM stdin;
\.


--
-- Data for Name: quota_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quota_data (id, user_id, username, model_name, created_at, use_group, token_id, channel_id, node_name, token_used, count, quota, cache_read_tokens, cache_creation_tokens) FROM stdin;
1	1	admin	deepseek-v4.1-flash-1017	1794063600	default	1	1	dgai-node-1	39	1	2	0	0
2	1	admin	deepseek-v4.1-flash	1794063600	default	0	1	dgai-node-1	47	1	3	0	0
3	1	admin	deepseek-v4.1-flash	1794063600	default	1	1	dgai-node-1	47	1	3	0	0
4	1	admin	deepseek-v4.1-flash	1794067200	default	2	1	dgai-node-1	9648	6	144	6656	0
5	1	admin	deepseek-v4.1-flash-1017	1794070800	default	2	1	dgai-node-1	6390	3	160	4094	0
6	1	admin	cx/gpt-6-luna	1794070800	default	2	3	dgai-node-1	2492	1	37	0	0
7	1	admin	claude-opus-5.5	1794070800	default	2	2	dgai-node-1	68	1	10000	44	0
8	1	admin	claude-opus-4-8	1794070800	default	2	2	dgai-node-1	274	1	4000	0	0
9	1	admin	claude-opus-5-5	1794070800	default	0	2	dgai-node-1	15	1	11	0	0
10	1	admin	gpt-6.1-sol	1794070800	default	0	3	dgai-node-1	1517	1	119	0	0
11	1	admin	claude-opus-5-5	1794070800	default	2	2	dgai-node-1	4	1	1	0	0
12	1	admin	gpt-6.1-sol	1794070800	default	2	3	dgai-node-1	1510	1	29	1280	0
13	1	admin	claude-fable-5.1-req	1794070800	default	2	2	dgai-node-1	4	1	10000	0	0
14	1	admin	deepseek-v4.1-flash	1794070800	default	0	1	dgai-node-1	47	1	3	0	0
15	1	admin	slow/agy/gemini-3.8-flash-medium	1794070800	default	0	4	dgai-node-1	739	1	1000	0	0
16	1	admin	cnb/deepseek-pro-v4	1794070800	default	2	1	dgai-node-1	85	1	1500	0	0
17	1	admin	slow/agy/gemini-3.8-flash-medium	1794070800	default	2	4	dgai-node-1	656	1	1000	0	0
18	1	admin	deepseek-v4.1-flash	1794070800	default	2	1	dgai-node-1	48	1	4	0	0
19	1	admin	deepseek-v4.1-flash	1794074400	default	3	1	dgai-node-1	12368735	247	114150	10580992	0
20	1	admin	deepseek-v4.1-flash	1794078000	default	3	1	dgai-node-1	1375167	29	12332	1170176	0
21	1	admin	claude-opus-5-5	1794229200	default	2	2	dgai-node-1	4	1	1	0	0
22	1	admin	gpt-6.1-sol	1794229200	default	2	3	dgai-node-1	1510	1	29	1280	0
25	1	admin	claude-opus-5-5	1794232800	default	0	2	dgai-node-1	15	1	11	0	0
26	1	admin	gpt-6.1-sol	1794232800	default	0	3	dgai-node-1	1515	1	118	1280	0
23	1	admin	claude-opus-5-5	1794232800	default	2	2	dgai-node-1	42770	4	5614	11866	0
27	1	admin	deepseek-v4.1-flash-1017	1794232800	default	2	1	dgai-node-1	131	2	7	0	0
28	1	admin	cnb/deepseek-pro-v4	1794232800	default	2	1	dgai-node-1	84	1	1500	0	0
24	1	admin	gpt-6.1-sol	1794232800	default	2	3	dgai-node-1	14879	2	1122	0	0
29	1	admin	deepseek-v4.1-flash-1017	1794232800	default	0	1	dgai-node-1	68	1	4	0	0
\.


--
-- Data for Name: redemptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.redemptions (id, user_id, key, status, name, quota, created_time, redeemed_time, used_user_id, deleted_at, expired_time) FROM stdin;
1	1	a6b6dc9b109542619521e3197f111ea1	3	nap-1usd	500000	1794066800	1794066807	1	\N	0
\.


--
-- Data for Name: setups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.setups (id, version, initialized_at) FROM stdin;
1	v1.0.0-dgai	1794063838
\.


--
-- Data for Name: subscription_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_orders (id, user_id, plan_id, money, trade_no, payment_method, payment_provider, status, create_time, complete_time, provider_payload) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, title, subtitle, price_amount, currency, duration_unit, duration_value, custom_seconds, enabled, sort_order, allow_balance_pay, allow_wallet_overflow, stripe_price_id, creem_product_id, waffo_pancake_product_id, max_purchase_per_user, upgrade_group, downgrade_group, total_amount, quota_reset_period, quota_reset_custom_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_pre_consume_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_pre_consume_records (id, request_id, user_id, user_subscription_id, pre_consumed, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_instances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_instances (node_name, info, started_at, last_seen_at, created_at, updated_at) FROM stdin;
dgai-node-1	{"schema_version":1,"node":{"name":"dgai-node-1","source":"manual","manually_configured":true,"should_configure_manually":false},"role":{"is_master":true},"runtime":{"version":"v1.0.0-dgai","goos":"linux","goarch":"amd64","started_at":1794250290},"host":{"hostname":"b32376ed4a71"},"resources":{"cpu":{"usage_percent":0.6999300069992994},"memory":{"usage_percent":4.9711415392789},"storage":{"total_bytes":1081101176832,"used_bytes":43947106304,"free_bytes":982161715200,"used_percent":4.065031769994017}}}	1794250290	1794250352	1794063802	1794250352
\.


--
-- Data for Name: system_task_locks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_task_locks (type, task_id, locked_by, locked_until, updated_at) FROM stdin;
\.


--
-- Data for Name: system_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_tasks (id, task_id, type, status, active_key, payload, state, result, error, locked_by, created_at, updated_at) FROM stdin;
1	systask_5qYtnVTTOEbyF4CTFgjLIrVwQf69BcXr	model_update	succeeded	\N		{"total":0,"processed":0,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-tIcW6De9	1794063802	1794063802
2	systask_dCWlP47L45YfooNR9JAogiNJh6LA57Aq	model_update	succeeded	\N		{"total":1,"processed":1,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-izzmnaPR	1794066540	1794066540
18	systask_f1pVplzQZmvWgA9xmEBRFf681IXARN27	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-WmAQRtEK	1794233632	1794233632
3	systask_MsKaO8MMiSkEEhr3PnkPEGUAlDVNwgzy	model_update	succeeded	\N		{"total":1,"processed":1,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-fmtPzENg	1794068346	1794068346
8	systask_VQLvmSsFTJCRI1230NQx33pFwaBNMvL3	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-gXeUGQxl	1794077397	1794077397
4	systask_GRCUFFns3tJTjbHQR17hyp0eT73Q1nmi	model_update	succeeded	\N		{"total":1,"processed":1,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-Xv3nlsKL	1794070171	1794070171
12	systask_gU42vYstmM41uZMCz7ic0YchAPC7boBz	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-wTcc8jvx	1794140337	1794140337
5	systask_rxnyCR3HAwZq7YGFdUm3Ox4AEfL4mDpF	model_update	succeeded	\N		{"total":3,"processed":3,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-NNoIaIuH	1794071992	1794071992
9	systask_OJe6FqaKDzTsBv4DLUzJZennxywNzPmk	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-gXeUGQxl	1794079197	1794079197
6	systask_ME2ZRWtnqWOBGzBe6jFVOchdC4Gv1TCx	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-gXeUGQxl	1794073797	1794073797
15	systask_t7yrBwJk5KDNmqHZomwGz6inOt1Mzsuc	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-W9j0SQ6H	1794145764	1794145764
7	systask_jEuDdv1T5uVnAeA2jA32rAfFI7eNfZh5	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-gXeUGQxl	1794075597	1794075597
10	systask_IoXrlqs2bAXZBAPItUDvdRNtBaui93HG	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-ALeTr5Am	1794081019	1794081019
13	systask_Mx5v5Dr9NKBlK4lEf2IgPyaPK9WvvZtn	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-W9j0SQ6H	1794142164	1794142164
11	systask_85j4c45NnTQFJxs7FELp0v9g4WKSnUSy	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-YmUY3S5R	1794138525	1794138525
17	systask_vET849x214OuvFrkfipjAHPMyM2BDvop	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-OelM4gW1	1794231831	1794231831
14	systask_1Hh3E2XHoCyrY5BxFfQaOTqyxVf7xDuj	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-W9j0SQ6H	1794143964	1794143964
16	systask_nJeWcrlcB9SZzTi3czkHQ99AdYBuIANq	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-YJeB8MEv	1794165934	1794165934
19	systask_TVnxNhtylLkHoMYpqpEXyZdxTVkzIsUu	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-lS7gs3fP	1794235449	1794235449
20	systask_r9f0VV4zqr3QIqIq9pGs2xvxShug3vFk	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-oPefiAkf	1794237258	1794237258
21	systask_KpGuSoSUIbKrMpvdKNEp2CEb6h8S1Bi6	model_update	succeeded	\N		{"total":4,"processed":4,"progress":100}	{"checked_channels":0,"changed_channels":0,"detected_add_models":0,"detected_remove_models":0,"failed_channels":0,"auto_added_models":0}		dgai-node-1-myAczrhv	1794250292	1794250292
\.


--
-- Data for Name: task_plugins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_plugins (id, key, api_version, version, source, source_hash, icon, enabled, active, created_at, remark) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, created_at, updated_at, task_id, platform, user_id, "group", channel_id, quota, action, status, fail_reason, submit_time, start_time, finish_time, progress, properties, private_data, data) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, user_id, key, status, name, created_time, accessed_time, expired_time, remain_quota, unlimited_quota, model_limits_enabled, model_limits, allow_ips, used_quota, "group", cross_group_retry, auto_groups, deleted_at, allow_user_quota_query) FROM stdin;
1	1	8pUhrS7IIbNoDF11pqCpwAo2MQViMuo8gfIhKbNXf8yBFN62	1	dgai-test	1794063882	1794063897	-1	4999995	f	f			5		f		\N	t
3	1	zwEMDgRsrnvf6KO1W46oYDboZAdboy5avFxMnpifEdeI0RVy	1	harness2	1794074253	1794078284	-1	19873518	f	f			126482		f		\N	t
2	1	6jHcK3ii0dSAgtQFfnyzGZ7fw1GrtXgeiufIjgUCHHM8KsMq	1	cache-test	1794070157	1794236008	-1	4964852	f	f			35148		f		\N	t
\.


--
-- Data for Name: top_ups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.top_ups (id, user_id, amount, money, trade_no, payment_method, payment_provider, create_time, complete_time, status) FROM stdin;
1	1	5	5	VQR1MxG12B8G	vietqr	vietqr	1794139028	0	pending
2	1	5	5	VQR1x39F7Be2	vietqr	vietqr	1794139143	0	pending
3	1	2	2	VQR1SH2kZ63B	vietqr	vietqr	1794139178	1794139178	success
4	1	3	3	VQR1LpJfq2TW	vietqr	vietqr	1794139185	1794139185	success
5	1	10	10	VQR1k6Uvga9F	vietqr	vietqr	1794139186	0	pending
6	1	1	1	VQR1Y8jN7V9l	vietqr	vietqr	1794139376	0	pending
7	1	1	1	VQR13qfWMX6p	vietqr	vietqr	1794140550	1794140550	success
8	1	1	1	VQR1tiQN8U8D	vietqr	vietqr	1794140656	1794140656	success
\.


--
-- Data for Name: two_fa_backup_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_fa_backup_codes (id, user_id, code_hash, is_used, used_at, created_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: two_fas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_fas (id, user_id, secret, is_enabled, failed_attempts, locked_until, last_used_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_access_tokens (id, user_id, name, token_hash, token_hint, scopes, expires_at, last_used_at, last_used_ip, created_at) FROM stdin;
\.


--
-- Data for Name: user_oauth_bindings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_oauth_bindings (id, user_id, provider_id, provider_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_sessions (sid, user_id, version, user_auth_version, status, refresh_hash, previous_refresh_hash, previous_valid_until, login_method, ip, user_agent, created_at, last_active_at, expires_at, revoked_at, revoked_reason) FROM stdin;
10fb1b3d-0d5f-4110-9a9e-f2f94ebafc0c	1	2	2	active	16f358cf0ab2652758ccf60c75388b537bea848c331fba80ec0d734dc32e3d81		0	password	172.22.0.1	curl/8.21.0	1794066601	1794066624	1796658601	0	
949292f3-dc1d-4d73-b51d-639c77fa01e0	1	1	1	revoked	c2ca37dbae9305ab8937dbf2992de8d808618c9d69f7fda9bf141f1139d7ce31		0	password	172.22.0.1	curl/8.21.0	1794063838	1794063838	1796655838	1794066624	password_changed
abef8b6e-e6a5-4a23-ae8a-561a8b9cf7dd	1	1	1	revoked	578f9c9ad91583d4985e8f832c28573dece3603791ae87fdfd3a6b5493d64ca0		0	password	172.22.0.1	curl/8.21.0	1794063842	1794063842	1796655842	1794066624	password_changed
7d5f4ed9-6b9f-4ff3-9f6e-8eea769eed5a	1	1	1	revoked	d330561b2330647b43c3609e996f2cd237ff3e1af6cef6237e7fa1fdd5c30732		0	password	172.22.0.1	curl/8.21.0	1794063936	1794063936	1796655936	1794066624	password_changed
86bcab3f-0439-4f95-90f0-1c25d7bdce92	1	1	2	active	19bf0472faa48b15588929a8b99005ee6d6d450a3dbbe9fe8f82cb3913a12fcf		0	password	172.22.0.1	curl/8.21.0	1794066634	1794066634	1796658634	0	
55b2cee5-fda5-410d-93d9-5d0c921de4c8	1	1	2	active	33680817fc373ed0a647cd2aa09d8e4445b84fc2d023e83a6b7fd41c20c8655b		0	password	172.22.0.1	curl/8.21.0	1794066729	1794066729	1796658729	0	
8440c63f-c6f4-4e67-8cfa-cd8c2b6a9c68	1	1	2	active	968d68a345e5650df6ce73847aeb1a147a67972e87435672e7062e464b066882		0	password	172.22.0.1	curl/8.21.0	1794068183	1794068183	1796660183	0	
beb9d564-cc19-4ef0-9278-4783d7a7a155	1	1	2	active	3898b084829901a33cc1db45ea3c37ff0a63f21e103c1ba711a91f2cbc4bcd75		0	password	172.22.0.1	curl/8.21.0	1794070085	1794070085	1796662085	0	
98dd66bd-7a9d-402c-a999-c289eddf0717	1	1	2	active	68a43f1828ed67ba1a0c4838e25b584f34e297ef7f7ea116721c63b1f7b0c4ec		0	password	172.22.0.1	curl/8.21.0	1794070940	1794070940	1796662940	0	
61b41a61-dbd6-4286-b4f6-400e1a5619cf	1	1	2	active	639a2e238f9a91f1d1469bda6b416b80186a0999d8f5fe6ec0cec1d4b26cb76b		0	password	172.22.0.1	curl/8.21.0	1794071130	1794071130	1796663130	0	
bbf1a2ea-b8a6-448a-be12-1640ac284036	1	1	2	active	45c974a43ba6cd75ea735d861b86e7c5fd3a482fc1e6c88a2e0ea80738a7e818		0	password	172.22.0.1	curl/8.21.0	1794071170	1794071170	1796663170	0	
3397565f-0931-4619-a384-8e3078e44331	1	1	2	active	bd5f8abfc7c8d16d39b07f61c341600c7b2df821e900bdb2abd5689b79b05f1f		0	password	172.22.0.1	curl/8.21.0	1794071786	1794071786	1796663786	0	
14ae85ab-f18d-44d5-aaa6-923d38f31474	1	1	2	active	b96ca7685e784ec4f11b07ef777d1488dbc4f66a13e343e1050c77b78ea49daf		0	password	172.22.0.1	curl/8.21.0	1794075242	1794075242	1796667242	0	
70c607a4-10af-4086-984a-de0b02469eb0	1	1	2	active	a2439a3ac3b989365315d473f1d1cce7a650c810bc1dc16bf2432eaf353232c2		0	password	172.22.0.1	curl/8.21.0	1794071911	1794071911	1796663911	0	
554aab76-dea7-4d1d-8433-337a823471c9	1	1	2	active	72513d6caddd47f78346396f29d532c92c2e338000deffe0c2d7c6f97b922079		0	password	172.22.0.1	curl/8.21.0	1794075333	1794075333	1796667333	0	
d870eef7-f785-49cc-b9d4-c395c2c37450	1	1	2	active	a2cd62ba20fa030afd89b0cbdc72f5646a031a1133b5b7112cbc0c528585c1f5		0	password	172.22.0.1	curl/8.21.0	1794072472	1794072472	1796664472	0	
41138cf2-bb91-44d3-868b-2cf9bee1f686	1	1	2	active	79e73af865d26fe034a2e2a9a1c1ed2142c3529ebeb9ef076d76a8212f714fc6		0	password	172.22.0.1	curl/8.21.0	1794072968	1794072968	1796664968	0	
faae86c1-aa18-4d73-b147-2739f505c8ab	1	1	2	active	ed0ff8f4d1f2105dceb281380929a1b9db1819765980f59475ab444e190655d4		0	password	172.22.0.1	curl/8.21.0	1794073200	1794073200	1796665200	0	
3b6d3c14-46c3-4a6a-add5-5f1a9e96fa95	1	1	2	active	5ab20d0224c960b57a42459e2725227a645fe65bca3519545217c175824e88a2		0	password	172.22.0.1	curl/8.21.0	1794073666	1794073666	1796665666	0	
54c96310-0438-4fab-b9df-bd5516c36055	1	1	2	active	079f4b71d0692af97c989ea127050c71c833b6e73a8a05af13799ecfd98f6054		0	password	172.22.0.1	curl/8.21.0	1794074252	1794074252	1796666252	0	
67b5aac4-ce04-4a97-8b75-24ff0d172159	1	1	2	active	c8cf20ba268a7e4debfc4ce82f7cfc6086f7c5d228a85313b651c7d84d78900f		0	password	172.22.0.1	curl/8.21.0	1794074261	1794074261	1796666261	0	
59b6ca4d-c8ba-478d-9ea5-8625d5a87081	1	1	2	active	8eba3944db26531508730143666d5c2d8df9d679054ada14b24394e26ee19389		0	password	172.22.0.1	curl/8.21.0	1794074274	1794074274	1796666274	0	
6b87b469-903f-45b7-ab82-6eafb429d4ed	1	1	2	active	7565dd909a725a581ac4775fe4273d7663eac891f393eacf342dc75a762922a5		0	password	172.22.0.1	curl/8.21.0	1794075928	1794075928	1796667928	0	
67c18886-db8f-4af9-bd70-e4be65eab45d	1	1	2	active	323c804e83a9bb35cb447697c19a26a581167b8dc0e7f1d573c00f3506e09720		0	password	172.22.0.1	curl/8.21.0	1794075953	1794075953	1796667953	0	
98491411-607b-4bda-a089-0afb8e04af9d	1	1	2	active	fb53d52f145003fe4e6ee5da0259745c37923991e862da7ada4596a76248c34f		0	password	172.22.0.1	curl/8.21.0	1794076125	1794076125	1796668125	0	
576da495-7f59-4b86-85e2-a5c6d2809afb	1	1	2	active	7123210ee6a1e217456e9077c037fb0617cdd6284973bf9b2c5244e01dd3ffdd		0	password	172.22.0.1	curl/8.21.0	1794076176	1794076176	1796668176	0	
3caa9f04-c945-491b-9e61-b56c42eb0782	1	1	2	active	3f786a09acfd6cf97e11d1c0fd01417c513b49c539fd9aa131ed0983e9ca9b33		0	password	172.22.0.1	curl/8.21.0	1794076578	1794076578	1796668578	0	
79c6a2e9-497a-4e3b-bb3f-0ff4fe5129f9	1	1	2	active	88bf37b9970394fcc2b46454c62750f26763fd758cf0a5d44054b857eba5d06f		0	password	172.22.0.1	curl/8.21.0	1794077030	1794077030	1796669030	0	
35a388be-d42c-4461-ae8c-731175924646	1	1	2	active	313c2ed83c4d5b7807fbb3d69a0b94ba1384a87c002cfa7254dfcdbdb18ce7e7		0	password	172.22.0.1	curl/8.21.0	1794077118	1794077118	1796669118	0	
b5823596-ba7d-4f53-a5c6-878b913d7dad	1	1	2	active	2db24ac8ffa029b2c21079149f65c8f1db62f938ac0b457c1e9cee03a6722a45		0	password	172.22.0.1	curl/8.21.0	1794077215	1794077215	1796669215	0	
d1e9ceaf-a514-4ab9-8185-f3610f40324b	1	1	2	active	69bfc01edcd89019164767fb1eab38d26e8446353bb44a781f644c9e51302aff		0	password	172.22.0.1	curl/8.21.0	1794077348	1794077348	1796669348	0	
1ee93ac8-33f4-4f98-a903-9fe1995255f6	1	1	2	active	b998ab4c957a98fe7da0efd6184f3d06251a5f8ebf5a61784c3ed56a56194d8a		0	password	172.22.0.1	curl/8.21.0	1794077698	1794077698	1796669698	0	
c5fd8a14-ee1a-419c-b59a-6b87bd5cd43f	1	1	2	active	2a5d475c5e35cbe13e2a11b95c5b364002e4016f5a73a81273072ebb42681fa7		0	password	172.22.0.1	curl/8.21.0	1794077891	1794077891	1796669891	0	
bc24b958-e41e-46b1-bc66-8e7e60d03f58	1	1	2	active	4440b5594d2735f3d15107e222c6094a5c544ad0e16c01fb6a039b58d5bacd76		0	password	172.22.0.1	curl/8.21.0	1794078206	1794078206	1796670206	0	
a590bc8b-4b94-4970-9a49-b7b9cec28756	1	1	2	active	fadd3f5223a25ea8c9f481f1c58c2db1993e307dd5802cbee1132189ad3ce977	e73d21ee4fd083efc87c875369e9404c54186b4cfa6fe3263ace9e0aa9fc9090	1794081385	password	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	1794066989	1794081355	1796658989	0	
758a30f6-581f-41d5-bc81-83f181db5665	1	1	2	active	44475c8e25a85d335ca0b924f6f1ca2906b9ee0e3f5d888ece970634fcf934a9		0	password	172.22.0.1	curl/8.21.0	1794139021	1794139021	1796731021	0	
1295c891-faed-47d7-ba6a-35e1ff1c5231	1	1	2	active	101330c90f2c5e303da3080bbcfb86e05e7676a2a6d0bb2ec53333cc655c6602		0	password	172.22.0.1	curl/8.21.0	1794139143	1794139143	1796731143	0	
006f2a03-5afc-40af-b762-d51f27db504f	1	1	2	active	bcc260cd49f28cd1f2bbdc9365f27a4948b932908b2c476089d51e6fe9ab4739		0	password	172.22.0.1	curl/8.21.0	1794140550	1794140550	1796732550	0	
fdeb2770-308f-4e12-9820-fb64714aa461	1	1	2	active	67061e2d835956e26388724287b273e6c8662408b1b51b25c302ebbee47c6058		0	password	172.22.0.1	curl/8.21.0	1794231918	1794231918	1796823918	0	
5ebe7ae3-e5bd-479a-b7f9-aa44f2d1b5cf	1	1	2	active	f168756ea6e8b16d021ed73826f22a16599896c20cb5732aaa03eb0a81fd4d71		0	password	172.22.0.1	curl/8.21.0	1794232188	1794232188	1796824188	0	
51cdf1b1-7487-42c4-974d-505c74391400	1	1	2	active	d7deeb84a228200b3097abc3699b60b12694ea7041c2f267baea9551a5db0acb		0	password	172.22.0.1	curl/8.21.0	1794232935	1794232935	1796824935	0	
e3557981-8d0d-4703-8459-c2f386f2d8fa	1	1	2	active	8778c61b79a3ea397ff2d15fa82101efa7d6bd17dcc44340ab33cc85d6a569d8		0	password	172.22.0.1	curl/8.21.0	1794233721	1794233721	1796825721	0	
db323efb-2c7c-4321-8bae-03770085a33c	1	1	2	active	b1131ba11a557033a3fc3224fd8017e279ef8fdbb6d66398efb4de6e3d92bf96	78ac14b0660c2f8567fd7ba800208fb623e3559c92915f65622fc0efac6574e0	1794234429	password	172.22.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36	1794139215	1794234399	1796731215	0	
6d012c1d-0e4c-4f75-aa0b-ff4418bcff22	1	1	2	active	1cb1e4beeaf5d11ea2bc483ceb3a22a6223232997e8aee77352e9505545a0f52		0	password	172.22.0.1	curl/8.21.0	1794235842	1794235842	1796827842	0	
\.


--
-- Data for Name: user_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_subscriptions (id, user_id, plan_id, amount_total, amount_used, start_time, end_time, status, source, last_reset_time, next_reset_time, upgrade_group, prev_user_group, downgrade_group, allow_wallet_overflow, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password, display_name, role, status, email, github_id, discord_id, oidc_id, wechat_id, telegram_id, access_token, access_token_created_at, quota, used_quota, request_count, "group", aff_code, aff_count, aff_quota, aff_history, inviter_id, deleted_at, linux_do_id, setting, remark, stripe_customer, created_at, last_login_at, auth_version) FROM stdin;
1	admin	$argon2id$v=19$m=19456,t=2,p=1$RHxOWwIHQwCcS60sEmLqFw$gtBdWMaDu94SN3CVetIPaGDUCvWTZAcYEOGGgNEvZBM	Root User	100	1							\N	\N	103838365	161635	307	default	SnAN	0	0	0	0	\N					1794063838	1794235842	2
\.


--
-- Data for Name: vendors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vendors (id, name, description, icon, status, created_time, updated_time, deleted_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 113, true);


--
-- Name: auth_flows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_flows_id_seq', 2, true);


--
-- Name: authz_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.authz_roles_id_seq', 81, true);


--
-- Name: casbin_rule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.casbin_rule_id_seq', 105, true);


--
-- Name: channels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.channels_id_seq', 4, true);


--
-- Name: checkins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.checkins_id_seq', 1, false);


--
-- Name: custom_oauth_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_oauth_providers_id_seq', 1, false);


--
-- Name: external_identity_claims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.external_identity_claims_id_seq', 1, false);


--
-- Name: login_encryption_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.login_encryption_keys_id_seq', 1, false);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.logs_id_seq', 329, true);


--
-- Name: midjourneys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.midjourneys_id_seq', 1, false);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.models_id_seq', 1, true);


--
-- Name: passkey_credentials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.passkey_credentials_id_seq', 1, false);


--
-- Name: perf_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.perf_metrics_id_seq', 9, true);


--
-- Name: prefill_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prefill_groups_id_seq', 1, false);


--
-- Name: quota_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.quota_data_id_seq', 29, true);


--
-- Name: redemptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.redemptions_id_seq', 1, true);


--
-- Name: setups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.setups_id_seq', 1, true);


--
-- Name: subscription_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_orders_id_seq', 1, false);


--
-- Name: subscription_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_plans_id_seq', 1, false);


--
-- Name: subscription_pre_consume_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subscription_pre_consume_records_id_seq', 1, false);


--
-- Name: system_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_tasks_id_seq', 21, true);


--
-- Name: task_plugins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_plugins_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 3, true);


--
-- Name: top_ups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.top_ups_id_seq', 8, true);


--
-- Name: two_fa_backup_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.two_fa_backup_codes_id_seq', 1, false);


--
-- Name: two_fas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.two_fas_id_seq', 1, false);


--
-- Name: user_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_access_tokens_id_seq', 1, false);


--
-- Name: user_oauth_bindings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_oauth_bindings_id_seq', 1, false);


--
-- Name: user_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_subscriptions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: vendors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vendors_id_seq', 1, false);


--
-- Name: abilities abilities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.abilities
    ADD CONSTRAINT abilities_pkey PRIMARY KEY ("group", model, channel_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_flows auth_flows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_flows
    ADD CONSTRAINT auth_flows_pkey PRIMARY KEY (id);


--
-- Name: authz_roles authz_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authz_roles
    ADD CONSTRAINT authz_roles_pkey PRIMARY KEY (id);


--
-- Name: casbin_rule casbin_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.casbin_rule
    ADD CONSTRAINT casbin_rule_pkey PRIMARY KEY (id);


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: checkins checkins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checkins
    ADD CONSTRAINT checkins_pkey PRIMARY KEY (id);


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_oauth_providers
    ADD CONSTRAINT custom_oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: external_identity_claims external_identity_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_identity_claims
    ADD CONSTRAINT external_identity_claims_pkey PRIMARY KEY (id);


--
-- Name: login_encryption_keys login_encryption_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.login_encryption_keys
    ADD CONSTRAINT login_encryption_keys_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: midjourneys midjourneys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.midjourneys
    ADD CONSTRAINT midjourneys_pkey PRIMARY KEY (id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: options options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_pkey PRIMARY KEY (key);


--
-- Name: passkey_credentials passkey_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.passkey_credentials
    ADD CONSTRAINT passkey_credentials_pkey PRIMARY KEY (id);


--
-- Name: perf_metrics perf_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.perf_metrics
    ADD CONSTRAINT perf_metrics_pkey PRIMARY KEY (id);


--
-- Name: prefill_groups prefill_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prefill_groups
    ADD CONSTRAINT prefill_groups_pkey PRIMARY KEY (id);


--
-- Name: quota_data quota_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quota_data
    ADD CONSTRAINT quota_data_pkey PRIMARY KEY (id);


--
-- Name: redemptions redemptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redemptions
    ADD CONSTRAINT redemptions_pkey PRIMARY KEY (id);


--
-- Name: setups setups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.setups
    ADD CONSTRAINT setups_pkey PRIMARY KEY (id);


--
-- Name: subscription_orders subscription_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_orders
    ADD CONSTRAINT subscription_orders_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_pre_consume_records subscription_pre_consume_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_pre_consume_records
    ADD CONSTRAINT subscription_pre_consume_records_pkey PRIMARY KEY (id);


--
-- Name: system_instances system_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_instances
    ADD CONSTRAINT system_instances_pkey PRIMARY KEY (node_name);


--
-- Name: system_task_locks system_task_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_task_locks
    ADD CONSTRAINT system_task_locks_pkey PRIMARY KEY (type);


--
-- Name: system_tasks system_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_tasks
    ADD CONSTRAINT system_tasks_pkey PRIMARY KEY (id);


--
-- Name: task_plugins task_plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_plugins
    ADD CONSTRAINT task_plugins_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: top_ups top_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.top_ups
    ADD CONSTRAINT top_ups_pkey PRIMARY KEY (id);


--
-- Name: two_fa_backup_codes two_fa_backup_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_fa_backup_codes
    ADD CONSTRAINT two_fa_backup_codes_pkey PRIMARY KEY (id);


--
-- Name: two_fas two_fas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_fas
    ADD CONSTRAINT two_fas_pkey PRIMARY KEY (id);


--
-- Name: subscription_orders uni_subscription_orders_trade_no; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_orders
    ADD CONSTRAINT uni_subscription_orders_trade_no UNIQUE (trade_no);


--
-- Name: top_ups uni_top_ups_trade_no; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.top_ups
    ADD CONSTRAINT uni_top_ups_trade_no UNIQUE (trade_no);


--
-- Name: two_fas uni_two_fas_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_fas
    ADD CONSTRAINT uni_two_fas_user_id UNIQUE (user_id);


--
-- Name: users uni_users_username; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uni_users_username UNIQUE (username);


--
-- Name: user_access_tokens user_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_access_tokens
    ADD CONSTRAINT user_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: user_oauth_bindings user_oauth_bindings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_oauth_bindings
    ADD CONSTRAINT user_oauth_bindings_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (sid);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vendors vendors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vendors
    ADD CONSTRAINT vendors_pkey PRIMARY KEY (id);


--
-- Name: idx_abilities_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abilities_channel_id ON public.abilities USING btree (channel_id);


--
-- Name: idx_abilities_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abilities_priority ON public.abilities USING btree (priority);


--
-- Name: idx_abilities_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abilities_tag ON public.abilities USING btree (tag);


--
-- Name: idx_abilities_weight; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_abilities_weight ON public.abilities USING btree (weight);


--
-- Name: idx_audit_logs_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_category ON public.audit_logs USING btree (category);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_event_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_audit_logs_event_id ON public.audit_logs USING btree (event_id);


--
-- Name: idx_audit_logs_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_request_id ON public.audit_logs USING btree (request_id);


--
-- Name: idx_audit_logs_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_username ON public.audit_logs USING btree (username);


--
-- Name: idx_audit_time_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_time_event ON public.audit_logs USING btree (created_at, event_id);


--
-- Name: idx_audit_token_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_token_time ON public.audit_logs USING btree (token_ref, created_at);


--
-- Name: idx_audit_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_user_time ON public.audit_logs USING btree (user_id, created_at);


--
-- Name: idx_auth_flow_purpose_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flow_purpose_expiry ON public.auth_flows USING btree (purpose, expires_at);


--
-- Name: idx_auth_flows_consumed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flows_consumed_at ON public.auth_flows USING btree (consumed_at);


--
-- Name: idx_auth_flows_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flows_session_id ON public.auth_flows USING btree (session_id);


--
-- Name: idx_auth_flows_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_auth_flows_token_hash ON public.auth_flows USING btree (token_hash);


--
-- Name: idx_auth_flows_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_flows_user_id ON public.auth_flows USING btree (user_id);


--
-- Name: idx_authz_roles_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_authz_roles_key ON public.authz_roles USING btree (key);


--
-- Name: idx_casbin_rule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_casbin_rule ON public.casbin_rule USING btree (ptype, v0, v1, v2, v3, v4, v5);


--
-- Name: idx_casbin_rule_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_casbin_rule_unique ON public.casbin_rule USING btree (ptype, v0, v1, v2, v3, v4, v5);


--
-- Name: idx_channels_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_channels_name ON public.channels USING btree (name);


--
-- Name: idx_channels_tag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_channels_tag ON public.channels USING btree (tag);


--
-- Name: idx_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_created_at_id ON public.logs USING btree (created_at, id);


--
-- Name: idx_created_at_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_created_at_type ON public.logs USING btree (created_at, type);


--
-- Name: idx_custom_oauth_providers_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_custom_oauth_providers_slug ON public.custom_oauth_providers USING btree (slug);


--
-- Name: idx_external_identity_claims_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_external_identity_claims_user_id ON public.external_identity_claims USING btree (user_id);


--
-- Name: idx_external_identity_subject; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_external_identity_subject ON public.external_identity_claims USING btree (provider, subject);


--
-- Name: idx_external_identity_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_external_identity_user ON public.external_identity_claims USING btree (provider, user_id);


--
-- Name: idx_login_encryption_keys_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_login_encryption_keys_slot ON public.login_encryption_keys USING btree (slot);


--
-- Name: idx_logs_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_channel_id ON public.logs USING btree (channel_id);


--
-- Name: idx_logs_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_group ON public.logs USING btree ("group");


--
-- Name: idx_logs_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_ip ON public.logs USING btree (ip);


--
-- Name: idx_logs_model_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_model_name ON public.logs USING btree (model_name);


--
-- Name: idx_logs_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_request_id ON public.logs USING btree (request_id);


--
-- Name: idx_logs_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_token_id ON public.logs USING btree (token_id);


--
-- Name: idx_logs_token_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_token_name ON public.logs USING btree (token_name);


--
-- Name: idx_logs_upstream_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_upstream_request_id ON public.logs USING btree (upstream_request_id);


--
-- Name: idx_logs_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_user_id ON public.logs USING btree (user_id);


--
-- Name: idx_logs_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_logs_username ON public.logs USING btree (username);


--
-- Name: idx_midjourneys_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_action ON public.midjourneys USING btree (action);


--
-- Name: idx_midjourneys_finish_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_finish_time ON public.midjourneys USING btree (finish_time);


--
-- Name: idx_midjourneys_mj_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_mj_id ON public.midjourneys USING btree (mj_id);


--
-- Name: idx_midjourneys_progress; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_progress ON public.midjourneys USING btree (progress);


--
-- Name: idx_midjourneys_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_start_time ON public.midjourneys USING btree (start_time);


--
-- Name: idx_midjourneys_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_status ON public.midjourneys USING btree (status);


--
-- Name: idx_midjourneys_submit_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_submit_time ON public.midjourneys USING btree (submit_time);


--
-- Name: idx_midjourneys_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_midjourneys_user_id ON public.midjourneys USING btree (user_id);


--
-- Name: idx_models_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_models_deleted_at ON public.models USING btree (deleted_at);


--
-- Name: idx_models_vendor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_models_vendor_id ON public.models USING btree (vendor_id);


--
-- Name: idx_passkey_credentials_credential_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_passkey_credentials_credential_id ON public.passkey_credentials USING btree (credential_id);


--
-- Name: idx_passkey_credentials_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_passkey_credentials_deleted_at ON public.passkey_credentials USING btree (deleted_at);


--
-- Name: idx_passkey_credentials_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_passkey_credentials_user_id ON public.passkey_credentials USING btree (user_id);


--
-- Name: idx_perf_bucket_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_perf_bucket_ts ON public.perf_metrics USING btree (bucket_ts);


--
-- Name: idx_perf_model_group_bucket; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_perf_model_group_bucket ON public.perf_metrics USING btree (model_name, "group", bucket_ts);


--
-- Name: idx_prefill_groups_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prefill_groups_deleted_at ON public.prefill_groups USING btree (deleted_at);


--
-- Name: idx_prefill_groups_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_prefill_groups_type ON public.prefill_groups USING btree (type);


--
-- Name: idx_qdt_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qdt_created_at ON public.quota_data USING btree (created_at);


--
-- Name: idx_qdt_model_user_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_qdt_model_user_name ON public.quota_data USING btree (model_name, username);


--
-- Name: idx_quota_data_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quota_data_channel_id ON public.quota_data USING btree (channel_id);


--
-- Name: idx_quota_data_node_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quota_data_node_name ON public.quota_data USING btree (node_name);


--
-- Name: idx_quota_data_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quota_data_token_id ON public.quota_data USING btree (token_id);


--
-- Name: idx_quota_data_use_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quota_data_use_group ON public.quota_data USING btree (use_group);


--
-- Name: idx_quota_data_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_quota_data_user_id ON public.quota_data USING btree (user_id);


--
-- Name: idx_redemptions_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_redemptions_deleted_at ON public.redemptions USING btree (deleted_at);


--
-- Name: idx_redemptions_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_redemptions_key ON public.redemptions USING btree (key);


--
-- Name: idx_redemptions_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_redemptions_name ON public.redemptions USING btree (name);


--
-- Name: idx_subscription_orders_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_orders_plan_id ON public.subscription_orders USING btree (plan_id);


--
-- Name: idx_subscription_orders_trade_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_orders_trade_no ON public.subscription_orders USING btree (trade_no);


--
-- Name: idx_subscription_orders_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_orders_user_id ON public.subscription_orders USING btree (user_id);


--
-- Name: idx_subscription_pre_consume_records_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_subscription_pre_consume_records_request_id ON public.subscription_pre_consume_records USING btree (request_id);


--
-- Name: idx_subscription_pre_consume_records_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_pre_consume_records_status ON public.subscription_pre_consume_records USING btree (status);


--
-- Name: idx_subscription_pre_consume_records_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_pre_consume_records_updated_at ON public.subscription_pre_consume_records USING btree (updated_at);


--
-- Name: idx_subscription_pre_consume_records_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_pre_consume_records_user_id ON public.subscription_pre_consume_records USING btree (user_id);


--
-- Name: idx_subscription_pre_consume_records_user_subscription_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_subscription_pre_consume_records_user_subscription_id ON public.subscription_pre_consume_records USING btree (user_subscription_id);


--
-- Name: idx_system_instances_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_instances_created_at ON public.system_instances USING btree (created_at);


--
-- Name: idx_system_instances_last_seen_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_instances_last_seen_at ON public.system_instances USING btree (last_seen_at);


--
-- Name: idx_system_instances_started_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_instances_started_at ON public.system_instances USING btree (started_at);


--
-- Name: idx_system_instances_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_instances_updated_at ON public.system_instances USING btree (updated_at);


--
-- Name: idx_system_task_locks_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_task_locks_locked_by ON public.system_task_locks USING btree (locked_by);


--
-- Name: idx_system_task_locks_locked_until; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_task_locks_locked_until ON public.system_task_locks USING btree (locked_until);


--
-- Name: idx_system_task_locks_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_task_locks_task_id ON public.system_task_locks USING btree (task_id);


--
-- Name: idx_system_task_locks_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_task_locks_updated_at ON public.system_task_locks USING btree (updated_at);


--
-- Name: idx_system_tasks_active_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_system_tasks_active_key ON public.system_tasks USING btree (active_key);


--
-- Name: idx_system_tasks_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_tasks_created_at ON public.system_tasks USING btree (created_at);


--
-- Name: idx_system_tasks_locked_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_tasks_locked_by ON public.system_tasks USING btree (locked_by);


--
-- Name: idx_system_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_tasks_status ON public.system_tasks USING btree (status);


--
-- Name: idx_system_tasks_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_system_tasks_task_id ON public.system_tasks USING btree (task_id);


--
-- Name: idx_system_tasks_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_tasks_type ON public.system_tasks USING btree (type);


--
-- Name: idx_system_tasks_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_system_tasks_updated_at ON public.system_tasks USING btree (updated_at);


--
-- Name: idx_task_plugins_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_task_plugins_active ON public.task_plugins USING btree (active);


--
-- Name: idx_tasks_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_action ON public.tasks USING btree (action);


--
-- Name: idx_tasks_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_channel_id ON public.tasks USING btree (channel_id);


--
-- Name: idx_tasks_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: idx_tasks_finish_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_finish_time ON public.tasks USING btree (finish_time);


--
-- Name: idx_tasks_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_platform ON public.tasks USING btree (platform);


--
-- Name: idx_tasks_progress; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_progress ON public.tasks USING btree (progress);


--
-- Name: idx_tasks_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_start_time ON public.tasks USING btree (start_time);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (status);


--
-- Name: idx_tasks_submit_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_submit_time ON public.tasks USING btree (submit_time);


--
-- Name: idx_tasks_task_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_task_id ON public.tasks USING btree (task_id);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: idx_tokens_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tokens_deleted_at ON public.tokens USING btree (deleted_at);


--
-- Name: idx_tokens_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_tokens_key ON public.tokens USING btree (key);


--
-- Name: idx_tokens_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tokens_name ON public.tokens USING btree (name);


--
-- Name: idx_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tokens_user_id ON public.tokens USING btree (user_id);


--
-- Name: idx_top_ups_trade_no; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_top_ups_trade_no ON public.top_ups USING btree (trade_no);


--
-- Name: idx_top_ups_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_top_ups_user_id ON public.top_ups USING btree (user_id);


--
-- Name: idx_two_fa_backup_codes_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_two_fa_backup_codes_deleted_at ON public.two_fa_backup_codes USING btree (deleted_at);


--
-- Name: idx_two_fa_backup_codes_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_two_fa_backup_codes_user_id ON public.two_fa_backup_codes USING btree (user_id);


--
-- Name: idx_two_fas_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_two_fas_deleted_at ON public.two_fas USING btree (deleted_at);


--
-- Name: idx_two_fas_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_two_fas_user_id ON public.two_fas USING btree (user_id);


--
-- Name: idx_user_access_tokens_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_access_tokens_expires_at ON public.user_access_tokens USING btree (expires_at);


--
-- Name: idx_user_access_tokens_token_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_access_tokens_token_hash ON public.user_access_tokens USING btree (token_hash);


--
-- Name: idx_user_access_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_access_tokens_user_id ON public.user_access_tokens USING btree (user_id);


--
-- Name: idx_user_checkin_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_user_checkin_date ON public.checkins USING btree (user_id, checkin_date);


--
-- Name: idx_user_id_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_id_id ON public.logs USING btree (user_id, id);


--
-- Name: idx_user_sessions_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_expires_at ON public.user_sessions USING btree (expires_at);


--
-- Name: idx_user_sessions_status_revoked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_status_revoked ON public.user_sessions USING btree (status, revoked_at);


--
-- Name: idx_user_sessions_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user_created ON public.user_sessions USING btree (user_id, created_at);


--
-- Name: idx_user_sessions_user_status_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sessions_user_status_expiry ON public.user_sessions USING btree (user_id, status, expires_at);


--
-- Name: idx_user_sub_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_sub_active ON public.user_subscriptions USING btree (user_id, status, end_time);


--
-- Name: idx_user_subscriptions_end_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_subscriptions_end_time ON public.user_subscriptions USING btree (end_time);


--
-- Name: idx_user_subscriptions_next_reset_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_subscriptions_next_reset_time ON public.user_subscriptions USING btree (next_reset_time);


--
-- Name: idx_user_subscriptions_plan_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_subscriptions_plan_id ON public.user_subscriptions USING btree (plan_id);


--
-- Name: idx_user_subscriptions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_subscriptions_status ON public.user_subscriptions USING btree (status);


--
-- Name: idx_user_subscriptions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_subscriptions_user_id ON public.user_subscriptions USING btree (user_id);


--
-- Name: idx_users_access_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_access_token ON public.users USING btree (access_token);


--
-- Name: idx_users_aff_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_users_aff_code ON public.users USING btree (aff_code);


--
-- Name: idx_users_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_deleted_at ON public.users USING btree (deleted_at);


--
-- Name: idx_users_discord_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_discord_id ON public.users USING btree (discord_id);


--
-- Name: idx_users_display_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_display_name ON public.users USING btree (display_name);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_git_hub_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_git_hub_id ON public.users USING btree (github_id);


--
-- Name: idx_users_inviter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_inviter_id ON public.users USING btree (inviter_id);


--
-- Name: idx_users_linux_do_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_linux_do_id ON public.users USING btree (linux_do_id);


--
-- Name: idx_users_oidc_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_oidc_id ON public.users USING btree (oidc_id);


--
-- Name: idx_users_stripe_customer; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_stripe_customer ON public.users USING btree (stripe_customer);


--
-- Name: idx_users_telegram_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_telegram_id ON public.users USING btree (telegram_id);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_users_we_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_we_chat_id ON public.users USING btree (wechat_id);


--
-- Name: idx_vendors_deleted_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_vendors_deleted_at ON public.vendors USING btree (deleted_at);


--
-- Name: index_username_model_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_username_model_name ON public.logs USING btree (model_name, username);


--
-- Name: uk_model_name_delete_at; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_model_name_delete_at ON public.models USING btree (model_name, deleted_at);


--
-- Name: uk_prefill_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_prefill_name ON public.prefill_groups USING btree (name) WHERE (deleted_at IS NULL);


--
-- Name: uk_task_plugin_key_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_task_plugin_key_version ON public.task_plugins USING btree (key, version);


--
-- Name: uk_vendor_name_delete_at; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uk_vendor_name_delete_at ON public.vendors USING btree (name, deleted_at);


--
-- Name: ux_provider_userid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_provider_userid ON public.user_oauth_bindings USING btree (provider_id, provider_user_id);


--
-- Name: ux_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_user_provider ON public.user_oauth_bindings USING btree (user_id, provider_id);


--
-- PostgreSQL database dump complete
--

\unrestrict paPbvHrd4s5uEPHeCHHhxhZ3AHmbwRbKQ0XT7dDRCabD56hJD9k2yDUSeJN7fk5

